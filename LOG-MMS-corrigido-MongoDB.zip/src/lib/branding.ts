export const BRAND_ASSETS = {
  coverImage: '/assets/aistudio/WhatsApp_Image_2026-10-20_at_20.14.56__1__b41e1bbd.jpeg',
  appName: 'LOG MMS',
  movementName: 'Mission Movement',
  tagline: 'Gestão, Logística e Rastreio',
  themeMilitary: {
    primary: '#284231', // Deep military olive forest
    dark: '#1b2d22',
    accent: '#44644e',
    light: '#eff3ee',
    border: '#d4ded2',
  },
};
