import { api } from './api';

const STORAGE_KEY = 'log_mms_offline_cache';

export interface LocalVault {
  timestamp: string;
  alunos: any[];
  viagens: any[];
  obreiros: any[];
  settings?: any;
}

export function getLocalVault(): LocalVault {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { timestamp: new Date().toISOString(), alunos: [], viagens: [], obreiros: [] };
    const parsed = JSON.parse(raw);
    return {
      timestamp: parsed.timestamp || new Date().toISOString(),
      alunos: Array.isArray(parsed.alunos) ? parsed.alunos : [],
      viagens: Array.isArray(parsed.viagens) ? parsed.viagens : [],
      obreiros: Array.isArray(parsed.obreiros) ? parsed.obreiros : [],
      settings: parsed.settings,
    };
  } catch {
    return { timestamp: new Date().toISOString(), alunos: [], viagens: [], obreiros: [] };
  }
}

export function saveLocalVault(vault: Partial<LocalVault>): void {
  try {
    const current = getLocalVault();
    const updated: LocalVault = {
      timestamp: new Date().toISOString(),
      alunos: vault.alunos !== undefined ? vault.alunos : current.alunos,
      viagens: vault.viagens !== undefined ? vault.viagens : current.viagens,
      obreiros: vault.obreiros !== undefined ? vault.obreiros : current.obreiros,
      settings: vault.settings !== undefined ? vault.settings : current.settings,
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch (e) {
    console.error('[Sync] Erro ao gravar snapshot local:', e);
  }
}

/**
 * Update a specific collection in the local persistent vault
 */
export function saveLocalSnapshot(type: 'alunos' | 'viagens' | 'obreiros', items: any[]): void {
  saveLocalVault({ [type]: items });
}

export function clearLocalCache(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch {
    // Ignore error
  }
}

/**
 * Bi-directional self-healing synchronization:
 * 1. Reads the browser's persistent storage vault.
 * 2. Fetches authoritative records from the server.
 * 3. If the server restarted or scaled to 0 and lost user-created items,
 *    it sends the missing local items to /api/backup/sync to rehydrate the server.
 * 4. Merges server items with local items (using the newest updatedAt timestamp).
 * 5. Saves the consolidated merged state to both the server and the browser vault.
 */
export async function syncDatabaseWithLocalStorage(): Promise<{ restored: number; total: number }> {
  try {
    const localVault = getLocalVault();

    // 1. Fetch server state
    const [alunosRes, viagensRes, obreirosRes, dashRes] = await Promise.all([
      api.get('/alunos'),
      api.get('/viagens', { params: { limit: 500 } }),
      api.get('/obreiros'),
      api.get('/dashboard').catch(() => ({ data: {} })),
    ]);

    const serverAlunos: any[] = alunosRes.data || [];
    const serverViagens: any[] = viagensRes.data?.items || viagensRes.data || [];
    const serverObreiros: any[] = obreirosRes.data || [];
    const serverSettings = dashRes.data?.dataLimitePassagem
      ? { dataLimitePassagem: dashRes.data.dataLimitePassagem, updatedAt: new Date().toISOString() }
      : undefined;

    // Detect items that exist in the browser's local vault but are missing on the server
    const serverAlunoIds = new Set(serverAlunos.map((a) => a.id));
    const serverViagemIds = new Set(serverViagens.map((v) => v.id));
    const serverObreiroIds = new Set(serverObreiros.map((o) => o.id));

    const missingOnServerAlunos = localVault.alunos.filter((a) => a && a.id && !serverAlunoIds.has(a.id));
    const missingOnServerViagens = localVault.viagens.filter((v) => v && v.id && !serverViagemIds.has(v.id));
    const missingOnServerObreiros = localVault.obreiros.filter((o) => o && o.id && !serverObreiroIds.has(o.id));

    let restoredCount = 0;

    // 2. If server was wiped or restarted and lost items, rehydrate the server immediately!
    if (
      missingOnServerAlunos.length > 0 ||
      missingOnServerViagens.length > 0 ||
      missingOnServerObreiros.length > 0
    ) {
      console.log(
        `[AutoHealing] Restaurando dados do cofre local no servidor: ${missingOnServerAlunos.length} alunos, ${missingOnServerViagens.length} viagens, ${missingOnServerObreiros.length} obreiros.`
      );
      try {
        const syncRes = await api.post('/backup/sync', {
          alunos: missingOnServerAlunos,
          viagens: missingOnServerViagens,
          obreiros: missingOnServerObreiros,
          settings: localVault.settings,
        });
        restoredCount =
          (syncRes.data?.restored?.alunos || 0) +
          (syncRes.data?.restored?.viagens || 0) +
          (syncRes.data?.restored?.obreiros || 0);
      } catch (err) {
        console.warn('[AutoHealing] Erro ao sincronizar itens do cofre local com servidor:', err);
      }
    }

    // 3. Merge server and local records (union by ID, newer timestamp wins)
    const mergeMap = <T extends { id: string; updatedAt?: string }>(localList: T[], serverList: T[]): T[] => {
      const map = new Map<string, T>();
      for (const item of localList) {
        if (item && item.id) map.set(item.id, item);
      }
      for (const item of serverList) {
        if (!item || !item.id) continue;
        const existing = map.get(item.id);
        if (!existing) {
          map.set(item.id, item);
        } else {
          const localTime = new Date(existing.updatedAt || 0).getTime();
          const serverTime = new Date(item.updatedAt || 0).getTime();
          if (serverTime >= localTime) {
            map.set(item.id, item);
          }
        }
      }
      return Array.from(map.values());
    };

    const finalAlunos = mergeMap(localVault.alunos, serverAlunos);
    const finalViagens = mergeMap(localVault.viagens, serverViagens);
    const finalObreiros = mergeMap(localVault.obreiros, serverObreiros);

    // 4. Save consolidated state in persistent local vault
    saveLocalVault({
      alunos: finalAlunos,
      viagens: finalViagens,
      obreiros: finalObreiros,
      settings: serverSettings || localVault.settings,
    });

    return {
      restored: restoredCount,
      total: finalAlunos.length + finalViagens.length + finalObreiros.length,
    };
  } catch (err) {
    console.warn('[Sync] Falha durante sincronização com servidor:', err);
    return { restored: 0, total: 0 };
  }
}
