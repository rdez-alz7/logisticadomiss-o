import React, { useState, useEffect } from 'react';
import { NavLink, Outlet, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  Users,
  Compass,
  FileText,
  BarChart3,
  Settings,
  LogOut,
  Menu,
  X,
  UserCircle,
  Shield,
  Sparkles,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Logo } from './Logo';
import { PWAInstallButton } from './PWAInstallButton';
import { OfflineIndicator } from './OfflineIndicator';
import { syncDatabaseWithLocalStorage } from '../lib/sync';
import { BRAND_ASSETS } from '../lib/branding';

export const Layout: React.FC = () => {
  const { user, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    syncDatabaseWithLocalStorage();
  }, []);

  const navigation = [
    { name: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
    { name: 'Alunos', href: '/alunos', icon: Users },
    { name: 'Obreiros', href: '/obreiros', icon: UserCircle },
    { name: 'Viagens', href: '/viagens', icon: Compass },
    { name: 'Documentos', href: '/documentos', icon: FileText },
    { name: 'Relatórios', href: '/relatorios', icon: BarChart3 },
    { name: 'Configurações', href: '/configuracoes', icon: Settings },
  ];

  const roleLabels: Record<string, { label: string; color: string }> = {
    ADMIN_HOST: { label: 'Admin Host', color: 'bg-[#2a4431] text-[#d6e7d8] border-[#446b4f]' },
    ADMIN: { label: 'Administrador', color: 'bg-[#314a38] text-[#e0ede2] border-[#4b7156]' },
    GESTOR: { label: 'Gestor', color: 'bg-[#273a2c] text-[#cbe0cf] border-[#3f5f48]' },
    VISUALIZADOR: { label: 'Visualizador', color: 'bg-[#212f24] text-[#a9baa9] border-[#344a39]' },
  };

  const currentRole = user?.role
    ? roleLabels[user.role]
    : { label: 'Usuário', color: 'bg-[#212f24] text-[#a9baa9] border-[#344a39]' };

  return (
    <div className="min-h-screen bg-[#f3f6f2] flex flex-col md:flex-row antialiased font-sans text-[#18261b]">
      {/* Mobile Top Header */}
      <div className="md:hidden flex items-center justify-between px-4 py-3 bg-[#ffffff] border-b border-[#d8e2d7] sticky top-0 z-30 shadow-xs">
        <Logo size="sm" showSubtitle={false} />
        <div className="flex items-center gap-2">
          <PWAInstallButton compact />
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-[#2e4534] hover:text-[#18261b] rounded-lg hover:bg-[#edf3ed] focus:outline-none"
            aria-label="Abrir menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Sidebar Backdrop & Drawer */}
      {mobileMenuOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-xs md:hidden"
          onClick={() => setMobileMenuOpen(false)}
        >
          <div
            className="w-72 max-w-[80vw] h-full bg-[#182a1d] text-white p-5 flex flex-col justify-between shadow-2xl border-r border-[#2d4633]"
            onClick={(e) => e.stopPropagation()}
          >
            <div>
              <div className="pb-4 border-b border-[#2d4633] flex items-center justify-between">
                <Logo size="md" variant="white" />
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-1 text-[#8fa792] hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Cover Banner in Mobile */}
              <div className="mt-4 rounded-xl overflow-hidden border border-[#3b5943]/60 bg-[#1d3323] relative h-24">
                <img
                  src={BRAND_ASSETS.coverImage}
                  alt="Mission Movement"
                  className="w-full h-full object-cover filter brightness-95"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#142317] via-transparent to-transparent flex items-end p-2">
                  <span className="text-[10px] font-bold tracking-wider text-[#d3e3d5] uppercase">
                    Mission Movement • MMS
                  </span>
                </div>
              </div>

              {/* User profile brief */}
              <div className="mt-4 p-3 rounded-xl bg-[#203525] border border-[#33533b] flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#2e4e37] flex items-center justify-center font-bold text-white text-base border border-[#446d4e]">
                  {user?.name?.charAt(0) || 'U'}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-white truncate">{user?.name}</p>
                  <span
                    className={`inline-block text-[10px] font-bold px-2 py-0.5 rounded-md border mt-0.5 ${currentRole.color}`}
                  >
                    {currentRole.label}
                  </span>
                </div>
              </div>

              {/* Nav links */}
              <nav className="mt-5 space-y-1">
                {navigation.map((item) => {
                  const Icon = item.icon;
                  const isActive = location.pathname.startsWith(item.href);
                  return (
                    <NavLink
                      key={item.name}
                      to={item.href}
                      onClick={() => setMobileMenuOpen(false)}
                      className={`flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition ${
                        isActive
                          ? 'bg-[#2b4733] text-white border border-[#446d4e] shadow-md shadow-[#111e14]/50'
                          : 'text-[#a9baa9] hover:bg-[#203525] hover:text-white'
                      }`}
                    >
                      <Icon className="w-5 h-5 text-[#8fa892]" />
                      <span>{item.name}</span>
                    </NavLink>
                  );
                })}
              </nav>
            </div>

            <div className="pt-4 border-t border-[#2d4633]">
              <button
                onClick={logout}
                className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium text-rose-300 hover:bg-rose-950/40 hover:text-rose-100 transition border border-rose-900/30"
              >
                <LogOut className="w-5 h-5" />
                <span>Sair do sistema</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Desktop Permanent Sidebar */}
      <aside className="hidden md:flex md:w-64 lg:w-72 flex-col justify-between bg-[#182a1d] text-white p-5 border-r border-[#2a4330] flex-shrink-0 sticky top-0 h-screen select-none">
        <div className="flex-1 overflow-y-auto pr-1">
          {/* Logo Area */}
          <div className="pb-4 border-b border-[#2a4330]">
            <Logo size="lg" variant="white" />
          </div>

          {/* Mission Movement Cover Card in Sidebar */}
          <div className="mt-4 rounded-2xl overflow-hidden border border-[#3b5943]/60 bg-[#16271b] shadow-md relative group">
            <div className="h-24 w-full overflow-hidden relative">
              <img
                src={BRAND_ASSETS.coverImage}
                alt="Mission Movement Cover"
                className="w-full h-full object-cover filter brightness-95 group-hover:scale-105 transition duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#142317] via-[#142317]/40 to-transparent" />
            </div>
            <div className="p-2.5 bg-[#172b1d] flex items-center justify-between text-[11px] border-t border-[#2d4934]">
              <span className="font-bold text-[#d2e4d4] flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-[#a1c4a3]" />
                <span>Mission Movement</span>
              </span>
              <span className="text-[10px] text-[#86a289] font-mono">OFICIAL</span>
            </div>
          </div>

          {/* User profile card in Sidebar */}
          <div className="mt-3.5 p-3 rounded-xl bg-[#203625] border border-[#33533b] flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#30533a] to-[#1c3323] flex items-center justify-center font-bold text-white shadow-xs border border-[#446d4e]">
              {user?.name?.charAt(0) || 'U'}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-white truncate" title={user?.name}>
                {user?.name}
              </p>
              <div className="flex items-center gap-1.5 mt-0.5">
                <Shield className="w-3 h-3 text-[#8fa892]" />
                <span className="text-[11px] font-medium text-[#c6dac9] truncate">
                  {currentRole.label}
                </span>
              </div>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="mt-5 space-y-1">
            {navigation.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname.startsWith(item.href);
              return (
                <NavLink
                  key={item.name}
                  to={item.href}
                  className={`flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition ${
                    isActive
                      ? 'bg-[#2a4532] text-white font-bold border border-[#436c4e] shadow-md shadow-[#0f1b12]/50'
                      : 'text-[#a4b7a4] hover:bg-[#1f3424] hover:text-white'
                  }`}
                >
                  <Icon className="w-4 h-4 flex-shrink-0 text-[#8aa48d]" />
                  <span>{item.name}</span>
                </NavLink>
              );
            })}
          </nav>
        </div>

        {/* Sidebar Footer */}
        <div className="pt-4 border-t border-[#2a4330] space-y-2.5">
          <PWAInstallButton />

          <button
            onClick={logout}
            className="w-full flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl text-sm font-medium text-rose-300 hover:bg-rose-950/40 hover:text-rose-100 transition border border-rose-900/30 cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            <span>Sair da conta</span>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-w-0 overflow-y-auto">
        {/* Desktop Top Header Bar */}
        <header className="hidden md:flex items-center justify-between px-8 py-3.5 bg-[#ffffff] border-b border-[#d8e2d7] sticky top-0 z-20 shadow-2xs">
          <div className="flex items-center gap-3">
            <span className="text-xs font-bold px-3 py-1 rounded-lg bg-[#edf3ed] text-[#243c2c] border border-[#c8d8c9] uppercase tracking-wider flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#3d6247] animate-pulse"></span>
              <span>MISSION MOVEMENT • LOG MMS</span>
            </span>
          </div>

          <div className="flex items-center gap-4">
            <PWAInstallButton compact />
            <div className="flex items-center gap-2.5 pl-3 border-l border-[#d8e2d7] text-sm">
              <UserCircle className="w-5 h-5 text-[#6c8670]" />
              <span className="font-bold text-[#1b2a1e]">{user?.name}</span>
              <span
                className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${currentRole.color}`}
              >
                {currentRole.label}
              </span>
            </div>
          </div>
        </header>

        {/* Page Content Viewport */}
        <div className="p-4 sm:p-6 lg:p-8 flex-1 max-w-7xl w-full mx-auto">
          <Outlet />
        </div>
      </main>

      <OfflineIndicator />
    </div>
  );
};
