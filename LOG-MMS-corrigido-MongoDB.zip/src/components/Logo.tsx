import React from 'react';
import { BRAND_ASSETS } from '../lib/branding';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  variant?: 'light' | 'dark' | 'white';
  showSubtitle?: boolean;
  useImage?: boolean;
}

export const Logo: React.FC<LogoProps> = ({
  size = 'md',
  variant = 'dark',
  showSubtitle = true,
  useImage = true,
}) => {
  const sizeClasses = {
    sm: {
      box: 'w-7 h-7 rounded-lg',
      title: 'text-sm font-black',
      subtitle: 'text-[9px]',
    },
    md: {
      box: 'w-9 h-9 rounded-xl',
      title: 'text-base font-black',
      subtitle: 'text-[10px]',
    },
    lg: {
      box: 'w-12 h-12 rounded-2xl',
      title: 'text-xl font-black',
      subtitle: 'text-xs',
    },
    xl: {
      box: 'w-16 h-16 rounded-2xl',
      title: 'text-2xl font-black',
      subtitle: 'text-sm',
    },
  };

  const currentSize = sizeClasses[size];

  const titleColors = {
    dark: 'text-[#1c2e22]',
    light: 'text-[#243c2c]',
    white: 'text-white',
  };

  const subtitleColors = {
    dark: 'text-[#44624d]',
    light: 'text-[#3e5a46]',
    white: 'text-[#c6d7cb]',
  };

  return (
    <div className="flex items-center gap-3 select-none">
      <div
        className={`${currentSize.box} relative overflow-hidden bg-[#26402e] border border-[#3b5943]/60 shadow-md shadow-[#1c2d20]/25 flex-shrink-0 flex items-center justify-center`}
      >
        {useImage ? (
          <img
            src={BRAND_ASSETS.coverImage}
            alt="Mission Movement"
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full bg-[#26402e] flex items-center justify-center text-white font-serif font-black text-xs">
            MM
          </div>
        )}
      </div>

      <div className="flex flex-col">
        <span
          className={`tracking-wider leading-none font-sans ${currentSize.title} ${titleColors[variant]}`}
        >
          LOG <span className="text-[#3b5943] font-black">MMS</span>
        </span>
        {showSubtitle && (
          <span
            className={`font-semibold tracking-wider uppercase mt-1 ${currentSize.subtitle} ${subtitleColors[variant]}`}
          >
            Mission Movement
          </span>
        )}
      </div>
    </div>
  );
};
