import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Users,
  Compass,
  FileText,
  UserCheck,
  Mail,
  ArrowRight,
  TrendingUp,
  AlertCircle,
  Clock,
  ShieldCheck,
  Database,
  Building,
  Calendar,
  CheckCircle,
  AlertTriangle,
  Edit3,
  X,
  UserCircle,
  Sparkles,
} from 'lucide-react';
import { api } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import { Viagem, Documento, PassagemStatus } from '../types';
import { BRAND_ASSETS } from '../lib/branding';

interface AlunoStatusItem {
  id: string;
  nome: string;
  obreiroNome: string;
  obreiroNomes?: string[];
  status: string;
  passagemStatus: PassagemStatus;
  temPassagem: boolean;
}

interface DashboardData {
  cards: {
    totalAlunos: number;
    alunosAtivos: number;
    totalObreiros: number;
    totalViagens: number;
    totalDocumentos: number;
    convitesPendentes?: number;
    totalComprados: number;
    totalEmRisco: number;
    totalUrgencia: number;
    totalNoPrazo: number;
  };
  dataLimitePassagem: string;
  alunosPorObreiro: Array<{
    obreiroId: string;
    obreiroNome: string;
    funcao: string;
    quantidadeAlunos: number;
    comprados: number;
    pendentes: number;
  }>;
  alunosStatusList: AlunoStatusItem[];
  alunosFaltandoComprar: AlunoStatusItem[];
  recentViagens: Viagem[];
  recentDocumentos: Documento[];
  dbStatus: {
    engine: string;
    connected: boolean;
  };
}

export const DashboardPage: React.FC = () => {
  const { user, hasRole } = useAuth();
  const canEdit = hasRole('ADMIN_HOST', 'ADMIN', 'GESTOR');
  const [data, setData] = useState<DashboardData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Edit deadline modal state
  const [isEditingDeadline, setIsEditingDeadline] = useState(false);
  const [newDeadline, setNewDeadline] = useState('');
  const [isSavingDeadline, setIsSavingDeadline] = useState(false);

  // Filter students by ticket status in dashboard table
  const [statusFilter, setStatusFilter] = useState<string>('TODOS');
  const [studentSearch, setStudentSearch] = useState('');

  const fetchDashboardData = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await api.get('/dashboard');
      setData(res.data);
      setNewDeadline(res.data.dataLimitePassagem || '');
    } catch (err: any) {
      setError(err.response?.data?.message || 'Erro ao carregar dados do dashboard.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const handleUpdateDeadline = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDeadline) return;
    setIsSavingDeadline(true);
    try {
      await api.put('/settings/data-limite', { dataLimitePassagem: newDeadline });
      setIsEditingDeadline(false);
      fetchDashboardData();
    } catch (err) {
      alert('Erro ao atualizar data limite.');
    } finally {
      setIsSavingDeadline(false);
    }
  };

  // Calculate days remaining to deadline
  const calculateDaysRemaining = (dateStr: string) => {
    if (!dateStr) return { days: 0, text: 'Sem data', isPast: false };
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const target = new Date(dateStr);
    target.setHours(0, 0, 0, 0);
    const diff = target.getTime() - today.getTime();
    const days = Math.ceil(diff / (1000 * 60 * 60 * 24));
    if (days < 0) return { days: Math.abs(days), text: `${Math.abs(days)} dia(s) atrás (Expirado)`, isPast: true };
    if (days === 0) return { days: 0, text: 'Hoje é a data limite!', isPast: false };
    return { days, text: `${days} dia(s) restantes`, isPast: false };
  };

  if (isLoading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="h-8 bg-slate-200 rounded-lg w-48 mb-2"></div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="h-28 bg-white border border-slate-200 rounded-2xl p-4"></div>
          ))}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="h-72 bg-white border border-slate-200 rounded-2xl"></div>
          <div className="h-72 bg-white border border-slate-200 rounded-2xl"></div>
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="p-8 bg-white rounded-2xl border border-rose-200 text-center max-w-lg mx-auto mt-12 shadow-sm">
        <AlertCircle className="w-12 h-12 text-rose-500 mx-auto mb-3" />
        <h3 className="text-lg font-bold text-slate-800">Falha ao carregar métricas</h3>
        <p className="text-sm text-slate-600 mt-1">{error}</p>
        <button
          onClick={fetchDashboardData}
          className="mt-4 px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-sm font-semibold transition"
        >
          Tentar Novamente
        </button>
      </div>
    );
  }

  const { cards, alunosPorObreiro, recentViagens, recentDocumentos, dbStatus } = data;

  return (
    <div className="space-y-8">
      {/* Mission Movement Hero Banner with Cover Image */}
      <div className="relative rounded-3xl overflow-hidden bg-[#243c2c] border border-[#375640] shadow-xl text-white">
        <div className="absolute inset-0 z-0">
          <img
            src={BRAND_ASSETS.coverImage}
            alt="Mission Movement Cover"
            className="w-full h-full object-cover object-center filter brightness-90 contrast-105"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#14261a] via-[#1a3321]/92 to-[#14261a]/65" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#112016] via-transparent to-transparent" />
        </div>

        <div className="relative z-10 p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="max-w-xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-[#0e1a12]/80 backdrop-blur-md border border-[#3f654b] text-[11px] font-bold tracking-wider text-[#d3e5d5] uppercase mb-3">
              <Sparkles className="w-3.5 h-3.5 text-[#9ac69c]" />
              <span>Base Oficial • Mission Movement</span>
            </div>
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight text-white font-sans drop-shadow-sm">
              LOG <span className="text-[#a5cfa7]">MMS</span>
            </h1>
            <p className="mt-2 text-sm sm:text-base text-[#cddfc0] leading-relaxed max-w-lg">
              Sistema completo de gestão, rastreio de passagens e logística de viagens missionárias em tempo real.
            </p>

            <div className="mt-4 flex flex-wrap items-center gap-2.5 text-xs text-[#dbe8dc]">
              <span className="px-3 py-1.5 rounded-lg bg-[#112015]/85 border border-[#385b41] font-semibold flex items-center gap-1.5">
                Alunos: <strong className="text-white font-bold">{cards.totalAlunos}</strong>
              </span>
              <span className="px-3 py-1.5 rounded-lg bg-[#112015]/85 border border-[#385b41] font-semibold flex items-center gap-1.5">
                Passagens Compradas: <strong className="text-white font-bold">{cards.totalComprados}</strong>
              </span>
              <span className="px-3 py-1.5 rounded-lg bg-[#112015]/85 border border-[#385b41] font-semibold flex items-center gap-1.5">
                <Database className="w-3 h-3 text-[#9ac69c]" />
                <span>Base: <strong className="text-white font-bold">{dbStatus.engine}</strong></span>
              </span>
            </div>
          </div>

          <div className="flex flex-wrap sm:flex-nowrap md:flex-col gap-2.5 flex-shrink-0">
            <Link
              to="/viagens"
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-white hover:bg-[#edf4ee] text-[#1a2c1f] font-bold text-xs rounded-xl shadow-md transition active:scale-95"
            >
              <Compass className="w-4 h-4 text-[#2f4f37]" />
              <span>Monitor de Embarques</span>
            </Link>
            <Link
              to="/alunos"
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-[#25412d]/90 hover:bg-[#2e5037] text-white font-bold text-xs rounded-xl border border-[#4d7557] backdrop-blur-sm transition active:scale-95"
            >
              <Users className="w-4 h-4 text-[#a5cfa7]" />
              <span>Gerenciar Alunos</span>
            </Link>
          </div>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
        {/* Total Alunos */}
        <Link
          to="/alunos"
          className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs hover:border-emerald-500/50 hover:shadow-md transition flex flex-col justify-between group"
        >
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase tracking-wider">Total Alunos</span>
            <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center group-hover:bg-emerald-600 group-hover:text-white transition">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl font-black text-slate-900">{cards.totalAlunos}</span>
          </div>
        </Link>

        {/* Alunos Ativos */}
        <Link
          to="/alunos"
          className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs hover:border-emerald-500/50 hover:shadow-md transition flex flex-col justify-between group"
        >
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase tracking-wider">Ativos</span>
            <div className="w-8 h-8 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center group-hover:bg-teal-600 group-hover:text-white transition">
              <UserCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl font-black text-emerald-700">{cards.alunosAtivos}</span>
          </div>
        </Link>

        {/* Total Obreiros */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase tracking-wider">Obreiros</span>
            <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center">
              <Building className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl font-black text-slate-900">{cards.totalObreiros}</span>
          </div>
        </div>

        {/* Total Viagens */}
        <Link
          to="/viagens"
          className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs hover:border-emerald-500/50 hover:shadow-md transition flex flex-col justify-between group"
        >
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase tracking-wider">Viagens</span>
            <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-700 flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition">
              <Compass className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl font-black text-slate-900">{cards.totalViagens}</span>
          </div>
        </Link>

        {/* Total Documentos */}
        <Link
          to="/documentos"
          className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs hover:border-emerald-500/50 hover:shadow-md transition flex flex-col justify-between group"
        >
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase tracking-wider">Documentos</span>
            <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center group-hover:bg-amber-600 group-hover:text-white transition">
              <FileText className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl font-black text-slate-900">{cards.totalDocumentos}</span>
          </div>
        </Link>

        {/* Convites Pendentes */}
        {cards.convitesPendentes !== undefined && (
          <Link
            to="/configuracoes"
            className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs hover:border-emerald-500/50 hover:shadow-md transition flex flex-col justify-between group"
          >
            <div className="flex items-center justify-between text-slate-500">
              <span className="text-xs font-semibold uppercase tracking-wider">Convites</span>
              <div className="w-8 h-8 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center group-hover:bg-purple-600 group-hover:text-white transition">
                <Mail className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-3">
              <span className="text-2xl font-black text-purple-700">{cards.convitesPendentes}</span>
            </div>
          </Link>
        )}
      </div>

      {/* CONTADOR DE DATA LIMITE PARA COMPRA DA PASSAGEM & STATUS DOS ALUNOS */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-950 rounded-3xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden border border-slate-700/80">
        <div className="absolute right-0 top-0 -mt-10 -mr-10 w-72 h-72 rounded-full bg-emerald-500/10 blur-3xl pointer-events-none"></div>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-slate-700/80">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/30 mb-2">
              <Calendar className="w-3.5 h-3.5" />
              <span>CONTROLE DE PRAZO DE PASSAGENS</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-white flex items-center gap-3">
              <span>Data Limite para Compra:</span>
              <span className="text-emerald-400 font-mono underline decoration-emerald-500/50">
                {new Date(data.dataLimitePassagem + 'T00:00:00').toLocaleDateString('pt-BR')}
              </span>
            </h2>
            <p className="text-sm text-slate-300 mt-1">
              Contador regressivo para os alunos garantirem a compra da passagem dentro do prazo.
            </p>
          </div>

          <div className="flex items-center gap-3 flex-wrap">
            {/* Days Counter Pill */}
            <div className="px-5 py-3 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 text-center min-w-[140px]">
              <span className="block text-2xl sm:text-3xl font-black text-white font-mono">
                {calculateDaysRemaining(data.dataLimitePassagem).days}
              </span>
              <span className="text-[11px] font-semibold text-emerald-300 uppercase tracking-wider">
                {calculateDaysRemaining(data.dataLimitePassagem).isPast ? 'Dias em Atraso' : 'Dias Restantes'}
              </span>
            </div>

            {canEdit && (
              <button
                onClick={() => setIsEditingDeadline(true)}
                className="inline-flex items-center gap-2 px-4 py-3 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-bold rounded-2xl text-xs transition shadow-lg"
              >
                <Edit3 className="w-4 h-4" />
                <span>Editar Data Limite</span>
              </button>
            )}
          </div>
        </div>

        {/* 4 Ticket Status Summary Boxes */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
          {/* COMPRADO: C (Verde) */}
          <div
            onClick={() => setStatusFilter(statusFilter === 'COMPRADO' ? 'TODOS' : 'COMPRADO')}
            className={`p-4 rounded-2xl border transition cursor-pointer ${
              statusFilter === 'COMPRADO'
                ? 'bg-emerald-500/20 border-emerald-400 shadow-md ring-2 ring-emerald-400/50'
                : 'bg-white/5 border-white/10 hover:bg-white/10'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-300">COMPRADO</span>
              <span className="w-6 h-6 rounded-md bg-emerald-500 text-white font-black text-xs flex items-center justify-center border border-emerald-400">
                C
              </span>
            </div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="text-2xl font-black text-emerald-400">{cards.totalComprados}</span>
              <span className="text-xs text-slate-300">passagens cadastradas</span>
            </div>
          </div>

          {/* EM RISCO: ER (Amarelo - faltando 1 mês) */}
          <div
            onClick={() => setStatusFilter(statusFilter === 'EM_RISCO' ? 'TODOS' : 'EM_RISCO')}
            className={`p-4 rounded-2xl border transition cursor-pointer ${
              statusFilter === 'EM_RISCO'
                ? 'bg-amber-500/20 border-amber-400 shadow-md ring-2 ring-amber-400/50'
                : 'bg-white/5 border-white/10 hover:bg-white/10'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-300">EM RISCO (1 Mês)</span>
              <span className="w-6 h-6 rounded-md bg-amber-400 text-slate-950 font-black text-xs flex items-center justify-center border border-amber-300">
                ER
              </span>
            </div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="text-2xl font-black text-amber-300">{cards.totalEmRisco}</span>
              <span className="text-xs text-slate-300">faltando 1 mês</span>
            </div>
          </div>

          {/* URGENCIA: U (Vermelho - mês da data limite) */}
          <div
            onClick={() => setStatusFilter(statusFilter === 'URGENCIA' ? 'TODOS' : 'URGENCIA')}
            className={`p-4 rounded-2xl border transition cursor-pointer ${
              statusFilter === 'URGENCIA'
                ? 'bg-rose-500/20 border-rose-400 shadow-md ring-2 ring-rose-400/50'
                : 'bg-white/5 border-white/10 hover:bg-white/10'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-300">URGÊNCIA (Mês Limite)</span>
              <span className="w-6 h-6 rounded-md bg-rose-600 text-white font-black text-xs flex items-center justify-center border border-rose-500">
                U
              </span>
            </div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="text-2xl font-black text-rose-400">{cards.totalUrgencia}</span>
              <span className="text-xs text-rose-200">contatar imediatamente!</span>
            </div>
          </div>

          {/* NO PRAZO: NP (Azul - inicial no prazo) */}
          <div
            onClick={() => setStatusFilter(statusFilter === 'NO_PRAZO' ? 'TODOS' : 'NO_PRAZO')}
            className={`p-4 rounded-2xl border transition cursor-pointer ${
              statusFilter === 'NO_PRAZO'
                ? 'bg-blue-500/20 border-blue-400 shadow-md ring-2 ring-blue-400/50'
                : 'bg-white/5 border-white/10 hover:bg-white/10'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-300">NO PRAZO</span>
              <span className="w-6 h-6 rounded-md bg-blue-500 text-white font-black text-xs flex items-center justify-center border border-blue-400">
                NP
              </span>
            </div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="text-2xl font-black text-blue-400">{cards.totalNoPrazo}</span>
              <span className="text-xs text-slate-300">dentro do cronograma</span>
            </div>
          </div>
        </div>

        {/* Dynamic Students Table with Passagem Status & Responsible Obreiro */}
        <div className="mt-6 bg-slate-900/80 rounded-2xl p-4 sm:p-5 border border-slate-700/60">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Users className="w-4 h-4 text-emerald-400" />
              <span>Alunos e Status da Passagem (Junto com Obreiro Responsável)</span>
            </h3>

            <div className="flex items-center gap-2">
              <input
                type="text"
                value={studentSearch}
                onChange={(e) => setStudentSearch(e.target.value)}
                placeholder="Filtrar aluno ou obreiro..."
                className="px-3 py-1.5 bg-slate-800 text-xs text-white border border-slate-700 rounded-lg outline-none focus:border-emerald-500"
              />
              {statusFilter !== 'TODOS' && (
                <button
                  onClick={() => setStatusFilter('TODOS')}
                  className="text-xs text-emerald-300 hover:underline font-semibold"
                >
                  Limpar ({statusFilter})
                </button>
              )}
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-700 text-slate-400 uppercase tracking-wider">
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3">Aluno</th>
                  <th className="py-2.5 px-3">Obreiro(s) Responsável(eis)</th>
                  <th className="py-2.5 px-3">Passagem</th>
                  <th className="py-2.5 px-3 text-right">Ação</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 text-slate-300">
                {data.alunosStatusList
                  .filter((a) => (statusFilter === 'TODOS' ? true : a.passagemStatus === statusFilter))
                  .filter(
                    (a) =>
                      !studentSearch ||
                      a.nome.toLowerCase().includes(studentSearch.toLowerCase()) ||
                      a.obreiroNome.toLowerCase().includes(studentSearch.toLowerCase())
                  )
                  .map((aluno) => {
                    const badgeStyles: Record<string, { sigla: string; bg: string; text: string; label: string }> = {
                      COMPRADO: { sigla: 'C', bg: 'bg-emerald-500', text: 'text-white', label: 'Comprado' },
                      EM_RISCO: { sigla: 'ER', bg: 'bg-amber-400', text: 'text-slate-950', label: 'Em Risco' },
                      URGENCIA: { sigla: 'U', bg: 'bg-rose-600', text: 'text-white', label: 'URGENTE (Entrar em Contato!)' },
                      NO_PRAZO: { sigla: 'NP', bg: 'bg-blue-500', text: 'text-white', label: 'No Prazo' },
                    };
                    const b = badgeStyles[aluno.passagemStatus] || badgeStyles.NO_PRAZO;

                    return (
                      <tr key={aluno.id} className="hover:bg-slate-800/50">
                        {/* Status Square */}
                        <td className="py-2.5 px-3">
                          <span
                            title={b.label}
                            className={`w-6 h-6 rounded-md flex items-center justify-center font-black text-xs ${b.bg} ${b.text}`}
                          >
                            {b.sigla}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 font-semibold text-white">
                          <Link to={`/alunos/${aluno.id}`} className="hover:text-emerald-400 hover:underline">
                            {aluno.nome}
                          </Link>
                        </td>
                        <td className="py-2.5 px-3 text-slate-300 font-medium">
                          {aluno.obreiroNome}
                        </td>
                        <td className="py-2.5 px-3">
                          <span className="font-semibold">{b.label}</span>
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          <Link
                            to={`/alunos/${aluno.id}`}
                            className="text-emerald-400 hover:underline font-semibold"
                          >
                            Ver Aluno &rarr;
                          </Link>
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* MODAL: EDITAR DATA LIMITE */}
      {isEditingDeadline && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-base">Editar Data Limite de Compra</h3>
              <button onClick={() => setIsEditingDeadline(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleUpdateDeadline} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Nova Data Limite
                </label>
                <input
                  type="date"
                  required
                  value={newDeadline}
                  onChange={(e) => setNewDeadline(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-500"
                />
                <p className="text-[11px] text-slate-500 mt-1">
                  O sistema recalcula automaticamente os status de quem está no prazo, em risco (1 mês) ou em urgência.
                </p>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsEditingDeadline(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSavingDeadline}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-semibold"
                >
                  {isSavingDeadline ? 'Salvando...' : 'Atualizar Data'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Main Grid: Alunos por Obreiro + Viagens Recentes */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Section: Alunos por Obreiro */}
        <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200/80 shadow-xs p-6">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-emerald-50 text-emerald-700">
                <TrendingUp className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-base font-bold text-slate-900">Alunos por Obreiro</h2>
                <p className="text-xs text-slate-500">Distribuição de alunos sob tutela</p>
              </div>
            </div>
          </div>

          <div className="mt-5 space-y-3">
            {alunosPorObreiro.length === 0 ? (
              <div className="py-8 text-center text-slate-400 text-sm">
                Nenhum obreiro ou aluno cadastrado.
              </div>
            ) : (
              alunosPorObreiro.map((item) => {
                const percentage =
                  cards.totalAlunos > 0
                    ? Math.round((item.quantidadeAlunos / cards.totalAlunos) * 100)
                    : 0;

                return (
                  <div
                    key={item.obreiroId}
                    className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/70 hover:bg-emerald-50/40 transition"
                  >
                    <div className="flex items-center justify-between text-sm">
                      <div>
                        <p className="font-semibold text-slate-800">{item.obreiroNome}</p>
                        <p className="text-[11px] text-slate-500">{item.funcao}</p>
                      </div>
                      <div className="text-right">
                        <span className="font-bold text-slate-900 text-base">
                          {item.quantidadeAlunos}
                        </span>
                        <span className="text-xs text-slate-500 ml-1">aluno(s)</span>
                      </div>
                    </div>

                    <div className="mt-2.5 w-full bg-slate-200 rounded-full h-1.5 overflow-hidden">
                      <div
                        className="bg-emerald-600 h-1.5 rounded-full transition-all duration-500"
                        style={{ width: `${percentage}%` }}
                      ></div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Section: Viagens Recentes */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200/80 shadow-xs p-6">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-indigo-50 text-indigo-700">
                <Compass className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-base font-bold text-slate-900">Viagens Recentes</h2>
                <p className="text-xs text-slate-500">Últimos itinerários e rastreios</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Link
                to="/viagens"
                className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 hover:underline"
              >
                <span>Ver todas</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>

          <div className="mt-5 space-y-3">
            {recentViagens.length === 0 ? (
              <div className="py-8 text-center text-slate-400 text-sm">
                Nenhuma viagem registrada ainda.
              </div>
            ) : (
              recentViagens.map((viagem) => {
                const statusStyles: Record<string, string> = {
                  PLANEJADA: 'bg-blue-100 text-blue-800 border-blue-200',
                  EM_ANDAMENTO: 'bg-emerald-100 text-emerald-800 border-emerald-300 animate-pulse',
                  CONCLUÍDA: 'bg-slate-100 text-slate-700 border-slate-200',
                  CANCELADA: 'bg-rose-100 text-rose-800 border-rose-200',
                };

                return (
                  <div
                    key={viagem.id}
                    className="p-4 rounded-xl border border-slate-200/80 hover:border-slate-300 transition flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 text-sm">
                          {viagem.alunoNome}
                        </span>
                        <span className="text-xs text-slate-400">•</span>
                        <span className="text-xs font-medium text-slate-600">
                          Obr. {viagem.obreiroNome}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 mt-1 flex items-center gap-1">
                        <span>{viagem.origem}</span>
                        <span className="text-slate-400 font-bold">→</span>
                        <span>{viagem.destino}</span>
                      </p>
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="text-right text-xs">
                        <p className="font-semibold text-slate-800">{viagem.dataSaida}</p>
                        <p className="text-slate-500">{viagem.horarioSaida}</p>
                      </div>
                      <span
                        className={`text-[10px] font-bold px-2.5 py-1 rounded-full border uppercase tracking-wider ${
                          statusStyles[viagem.status] || 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {viagem.status.replace('_', ' ')}
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>

      {/* Section: Documentos Recentes */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-6">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-50 text-amber-700">
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">Documentos Recentes</h2>
              <p className="text-xs text-slate-500">Últimos documentos cadastrados no repositório</p>
            </div>
          </div>
          <Link
            to="/documentos"
            className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 hover:underline"
          >
            <span>Gerenciar documentos</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="mt-5 overflow-x-auto">
          {recentDocumentos.length === 0 ? (
            <div className="py-8 text-center text-slate-400 text-sm">
              Nenhum documento anexado.
            </div>
          ) : (
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-slate-400 text-[11px] uppercase tracking-wider font-semibold">
                  <th className="pb-3">Título</th>
                  <th className="pb-3">Tipo</th>
                  <th className="pb-3">Aluno Vinculado</th>
                  <th className="pb-3">Data de Envio</th>
                  <th className="pb-3">Status da Análise</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {recentDocumentos.map((doc) => (
                  <tr key={doc.id} className="hover:bg-slate-50/70">
                    <td className="py-3 font-semibold text-slate-900">{doc.titulo}</td>
                    <td className="py-3">
                      <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 text-xs font-medium">
                        {doc.tipo}
                      </span>
                    </td>
                    <td className="py-3 text-slate-600">
                      {doc.alunoNome || <span className="text-slate-400 italic">Sem vínculo</span>}
                    </td>
                    <td className="py-3 text-slate-500 text-xs">
                      {new Date(doc.createdAt).toLocaleDateString('pt-BR')}
                    </td>
                    <td className="py-3">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                          doc.analiseStatus === 'ANALISADO'
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                            : doc.analiseStatus === 'ERRO'
                            ? 'bg-rose-50 text-rose-700 border-rose-200'
                            : 'bg-slate-100 text-slate-600 border-slate-200'
                        }`}
                      >
                        {doc.analiseStatus === 'NAO_ANALISADO' ? 'Não analisado' : doc.analiseStatus}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};
