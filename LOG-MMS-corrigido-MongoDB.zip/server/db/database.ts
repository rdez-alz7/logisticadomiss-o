import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import { MongoClient, Db } from 'mongodb';
import { User, Aluno, Obreiro, Viagem, Documento, UserInvitation, AuditLog, SystemSettings } from '../types/index.js';

interface DatabaseSchema {
  users: User[];
  alunos: Aluno[];
  obreiros: Obreiro[];
  viagens: Viagem[];
  documentos: Documento[];
  user_invitations: UserInvitation[];
  auditoria: AuditLog[];
  settings?: SystemSettings;
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DATA_FILE = path.join(DATA_DIR, 'database.json');

let mongoClient: MongoClient | null = null;
let mongoDb: Db | null = null;
let useMongo = false;

// Default target deadline for ticket purchase: 45 days from today
const defaultDeadline = new Date(Date.now() + 45 * 24 * 3600 * 1000).toISOString().split('T')[0];

// In-memory cache + persistent file sync
let memoryDb: DatabaseSchema = {
  users: [],
  alunos: [],
  obreiros: [],
  viagens: [],
  documentos: [],
  user_invitations: [],
  auditoria: [],
  settings: {
    dataLimitePassagem: defaultDeadline,
    updatedAt: new Date().toISOString(),
  },
};

function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

let lastDiskMtime = 0;

export function syncFromDiskIfNeeded(): void {
  ensureDataDir();
  if (fs.existsSync(DATA_FILE)) {
    try {
      const stats = fs.statSync(DATA_FILE);
      // Reload from disk only if memoryDb is cold/uninitialized or file was touched externally
      if (memoryDb.users.length === 0 || stats.mtimeMs > lastDiskMtime + 200) {
        const content = fs.readFileSync(DATA_FILE, 'utf-8');
        const parsed = JSON.parse(content);
        memoryDb = {
          users: Array.isArray(parsed.users) ? parsed.users : [],
          alunos: Array.isArray(parsed.alunos) ? parsed.alunos : [],
          obreiros: Array.isArray(parsed.obreiros) ? parsed.obreiros : [],
          viagens: Array.isArray(parsed.viagens) ? parsed.viagens : [],
          documentos: Array.isArray(parsed.documentos) ? parsed.documentos : [],
          user_invitations: Array.isArray(parsed.user_invitations) ? parsed.user_invitations : [],
          auditoria: Array.isArray(parsed.auditoria) ? parsed.auditoria : [],
          settings: parsed.settings || {
            dataLimitePassagem: defaultDeadline,
            hasInitializedSampleData: true,
            updatedAt: new Date().toISOString(),
          },
        };
        lastDiskMtime = stats.mtimeMs;
      }
    } catch (e) {
      console.error('[Database] Erro ao sincronizar database.json do disco:', e);
    }
  }
}

function loadLocalFile(): void {
  syncFromDiskIfNeeded();
}

export function saveLocalFile(): void {
  ensureDataDir();
  try {
    const json = JSON.stringify(memoryDb, null, 2);
    // Write synchronously to guarantee persistence across all operations
    fs.writeFileSync(DATA_FILE, json, 'utf-8');
    if (fs.existsSync(DATA_FILE)) {
      lastDiskMtime = fs.statSync(DATA_FILE).mtimeMs;
    }

    // Keep an automatic backup copy for recovery
    try {
      const backupPath = path.join(DATA_DIR, 'database.backup.json');
      fs.writeFileSync(backupPath, json, 'utf-8');
    } catch {
      // Non-critical safety copy
    }
  } catch (e) {
    console.error('[Database] Erro ao persistir database.json:', e);
  }
}

export async function initDatabase(): Promise<void> {
  const mongoUrl = process.env.MONGODB_URL?.trim();
  const dbName = process.env.MONGODB_DATABASE?.trim() || 'log_mms';

  loadLocalFile();

  if (mongoUrl) {
    try {
      mongoClient = new MongoClient(mongoUrl, { serverSelectionTimeoutMS: 10000 });
      await mongoClient.connect();
      mongoDb = mongoClient.db(dbName);
      await mongoDb.command({ ping: 1 });
      useMongo = true;
      console.log(`[Database] Conectado com sucesso ao MongoDB Atlas (banco: ${dbName}).`);

      const collectionNames = ['users', 'alunos', 'obreiros', 'viagens', 'documentos', 'user_invitations', 'auditoria', 'settings'];
      const counts = await Promise.all(collectionNames.map((name) => mongoDb!.collection(name).countDocuments()));
      const remoteHasData = counts.some((count) => count > 0);

      if (remoteHasData) {
        const [u, a, o, v, d, i, aud, settingsRows] = await Promise.all([
          mongoDb.collection<User>('users').find().toArray(),
          mongoDb.collection<Aluno>('alunos').find().toArray(),
          mongoDb.collection<Obreiro>('obreiros').find().toArray(),
          mongoDb.collection<Viagem>('viagens').find().toArray(),
          mongoDb.collection<Documento>('documentos').find().toArray(),
          mongoDb.collection<UserInvitation>('user_invitations').find().toArray(),
          mongoDb.collection<AuditLog>('auditoria').find().sort({ timestamp: -1 }).toArray(),
          (async () => { const row = await mongoDb!.collection('settings').findOne({ key: 'system' }) || await mongoDb!.collection('settings').findOne({}); return row ? [row] : []; })(),
        ]);
        const stripMongoId = (row: any) => {
          const { _id, ...rest } = row;
          return rest;
        };
        memoryDb = {
          users: u.map(stripMongoId),
          alunos: a.map(stripMongoId),
          obreiros: o.map(stripMongoId),
          viagens: v.map(stripMongoId),
          documentos: d.map(stripMongoId),
          user_invitations: i.map(stripMongoId),
          auditoria: aud.map(stripMongoId),
          settings: settingsRows.length ? stripMongoId(settingsRows[0]) : {
            dataLimitePassagem: defaultDeadline,
            hasInitializedSampleData: true,
            updatedAt: new Date().toISOString(),
          },
        };
        saveLocalFile();
        console.log('[Database] Dados carregados do MongoDB Atlas.');
      } else {
        console.log('[Database] Banco remoto vazio; os dados iniciais serão gravados no Atlas.');
      }
    } catch (err: any) {
      useMongo = false;
      mongoDb = null;
      if (mongoClient) {
        await mongoClient.close().catch(() => undefined);
        mongoClient = null;
      }
      console.error(`[Database] Falha ao conectar/sincronizar com MongoDB Atlas: ${err.message}`);
      throw new Error('Não foi possível conectar ao MongoDB Atlas. Confira MONGODB_URL e Network Access antes de iniciar o servidor.');
    }
  } else {
    useMongo = false;
    console.warn('[Database] MONGODB_URL não informada. Usando arquivo JSON local; esse modo não é indicado para hospedagem efêmera.');
  }

  await bootstrapAdminAndData();

  if (useMongo && mongoDb) {
    await persistAllToMongo();
    console.log('[Database] Dados iniciais e alterações sincronizados no MongoDB Atlas.');
  }
}

async function persistAllToMongo(): Promise<void> {
  if (!mongoDb) return;
  const collections: Array<[string, Array<{ id?: string; [key: string]: any }>]> = [
    ['users', memoryDb.users],
    ['alunos', memoryDb.alunos],
    ['obreiros', memoryDb.obreiros],
    ['viagens', memoryDb.viagens],
    ['documentos', memoryDb.documentos],
    ['user_invitations', memoryDb.user_invitations],
    ['auditoria', memoryDb.auditoria],
  ];

  for (const [name, records] of collections) {
    if (!records.length) continue;
    const operations = records.map((record) => ({
      replaceOne: {
        filter: { id: record.id },
        replacement: record,
        upsert: true,
      },
    }));
    await mongoDb.collection(name).bulkWrite(operations as any, { ordered: false });
  }

  if (memoryDb.settings) {
    await mongoDb.collection('settings').updateOne(
      { key: 'system' },
      { $set: { ...memoryDb.settings, key: 'system' } },
      { upsert: true }
    );
  }
}

export function isUsingMongo(): boolean {
  return useMongo;
}

export function getDbStatus(): { engine: string; connected: boolean; path?: string } {
  return {
    engine: useMongo ? 'MongoDB Atlas' : 'Arquivo JSON local (não compartilhado)',
    connected: useMongo ? Boolean(mongoDb) : false,
    path: useMongo ? process.env.MONGODB_DATABASE || 'log_mms' : DATA_FILE,
  };
}

async function bootstrapAdminAndData() {
  const adminEmail = (process.env.INITIAL_ADMIN_EMAIL || 'vitoraluizio151107vt@gmail.com').toLowerCase().trim();
  const adminUsername = (process.env.INITIAL_ADMIN_USERNAME || 'vitor').toLowerCase().trim();
  const adminName = process.env.INITIAL_ADMIN_NAME || 'Vitor';
  const rawPassword = process.env.INITIAL_ADMIN_PASSWORD || 'admin';

  // Check if admin already exists
  const existingAdmin = memoryDb.users.find(
    (u) => u.email.toLowerCase() === adminEmail || u.username.toLowerCase() === adminUsername
  );

  if (!existingAdmin) {
    const salt = bcrypt.genSaltSync(10);
    const passwordHash = bcrypt.hashSync(rawPassword, salt);
    const newAdmin: User = {
      id: 'usr_admin_initial',
      name: adminName,
      username: adminUsername,
      email: adminEmail,
      passwordHash,
      role: 'ADMIN_HOST',
      status: 'ATIVO',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    memoryDb.users.push(newAdmin);
    saveLocalFile();
    console.log(`[Bootstrap] Administrador inicial criado: ${adminUsername} (${adminEmail}) com role ADMIN_HOST`);

    // Audit initial setup
    memoryDb.auditoria.push({
      id: `aud_${Date.now()}`,
      userId: 'system',
      userName: 'Sistema',
      userRole: 'SISTEMA',
      acao: 'BOOTSTRAP_ADMIN',
      entidade: 'User',
      entidadeId: newAdmin.id,
      detalhes: `Administrador inicial ${adminUsername} configurado`,
      timestamp: new Date().toISOString(),
    });
  }

  // Seed default obreiros only on fresh first-time initialization
  if (!memoryDb.settings?.hasInitializedSampleData && memoryDb.obreiros.length === 0) {
    const initialObreiros: Obreiro[] = [
      {
        id: 'obr_1',
        nome: 'João Silva',
        email: 'joao.silva@mms.org',
        funcao: 'Pastor Regional',
        status: 'ATIVO',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: 'obr_2',
        nome: 'Marcos Oliveira',
        email: 'marcos.oliveira@mms.org',
        funcao: 'Missionário Coordenador',
        status: 'ATIVO',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: 'obr_3',
        nome: 'Lucas Santos',
        email: 'lucas.santos@mms.org',
        funcao: 'Obreiro de Apoio',
        status: 'ATIVO',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: 'obr_4',
        nome: 'Ana Paula Ferreira',
        email: 'ana.paula@mms.org',
        funcao: 'Supervisora de Polo',
        status: 'ATIVO',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
    ];
    memoryDb.obreiros = initialObreiros;
    saveLocalFile();
  }

  // Seed initial sample Alunos and Viagens only on fresh first-time initialization
  if (!memoryDb.settings?.hasInitializedSampleData && memoryDb.alunos.length === 0) {
    const initialAlunos: Aluno[] = [
      {
        id: 'aln_1',
        nome: 'Gabriel Pereira Rocha',
        obreiroId: 'obr_1',
        obreiroNome: 'João Silva',
        status: 'ATIVO',
        createdAt: new Date(Date.now() - 86400000 * 5).toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: 'aln_2',
        nome: 'Beatriz Cristina Mendes',
        obreiroId: 'obr_2',
        obreiroNome: 'Marcos Oliveira',
        status: 'ATIVO',
        createdAt: new Date(Date.now() - 86400000 * 4).toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: 'aln_3',
        nome: 'Matheus Henrique Alves',
        obreiroId: 'obr_3',
        obreiroNome: 'Lucas Santos',
        status: 'CONCLUÍDO',
        createdAt: new Date(Date.now() - 86400000 * 12).toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: 'aln_4',
        nome: 'Larissa Souza Lima',
        obreiroId: 'obr_1',
        obreiroNome: 'João Silva',
        status: 'ATIVO',
        createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
        updatedAt: new Date().toISOString(),
      },
    ];
    memoryDb.alunos = initialAlunos;

    const initialViagens: Viagem[] = [
      {
        id: 'vgm_1',
        alunoId: 'aln_1',
        alunoNome: 'Gabriel Pereira Rocha',
        obreiroNome: 'João Silva',
        origem: 'Belo Horizonte - MG',
        destino: 'São Paulo - SP',
        dataSaida: '2026-10-12',
        horarioSaida: '08:30',
        dataChegada: '2026-10-12',
        horarioChegada: '16:00',
        empresa: 'Viação Cometa',
        numeroLocalizador: 'CMT-884920',
        localEmbarque: 'Terminal Rodoviário Gov. Israel Pinheiro',
        localDesembarque: 'Terminal Rodoviário Tietê',
        status: 'EM_ANDAMENTO',
        observacoes: 'Viagem para módulo de estudos avançados.',
        createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: 'vgm_2',
        alunoId: 'aln_2',
        alunoNome: 'Beatriz Cristina Mendes',
        obreiroNome: 'Marcos Oliveira',
        origem: 'Campinas - SP',
        destino: 'Curitiba - PR',
        dataSaida: '2026-10-15',
        horarioSaida: '22:00',
        dataChegada: '2026-10-16',
        horarioChegada: '06:30',
        empresa: 'Auto Viação Catarinense',
        numeroLocalizador: 'CAT-19402',
        localEmbarque: 'Rodoviária de Campinas',
        localDesembarque: 'Rodoferroviária de Curitiba',
        status: 'PLANEJADA',
        observacoes: 'Apresentação no pólo sul.',
        createdAt: new Date(Date.now() - 86400000).toISOString(),
        updatedAt: new Date().toISOString(),
      },
    ];
    memoryDb.viagens = initialViagens;
  }

  // Mark bootstrap initialization as completed
  if (!memoryDb.settings) {
    memoryDb.settings = {
      dataLimitePassagem: defaultDeadline,
      hasInitializedSampleData: true,
      updatedAt: new Date().toISOString(),
    };
  } else {
    memoryDb.settings.hasInitializedSampleData = true;
  }
  saveLocalFile();
}

// Persist each mutation to MongoDB before returning success to the API.
async function mongoSync(collection: string, operation: (col: any) => Promise<any>): Promise<void> {
  if (!useMongo || !mongoDb) return;
  const col = mongoDb.collection(collection);
  await operation(col);
}

// Database generic accessors
export const db = {
  users: {
    find: async () => {
      syncFromDiskIfNeeded();
      return memoryDb.users;
    },
    findById: async (id: string) => {
      syncFromDiskIfNeeded();
      return memoryDb.users.find((u) => u.id === id) || null;
    },
    findByEmailOrUsername: async (identifier: string) => {
      syncFromDiskIfNeeded();
      const clean = identifier.toLowerCase().trim();
      return (
        memoryDb.users.find(
          (u) => u.email.toLowerCase() === clean || u.username.toLowerCase() === clean
        ) || null
      );
    },
    insertOne: async (user: User) => {
      syncFromDiskIfNeeded();
      memoryDb.users.push(user);
      saveLocalFile();
      await mongoSync('users', (col) => col.insertOne(user));
      return user;
    },
    updateOne: async (id: string, updates: Partial<User>) => {
      syncFromDiskIfNeeded();
      const idx = memoryDb.users.findIndex((u) => u.id === id);
      if (idx !== -1) {
        memoryDb.users[idx] = { ...memoryDb.users[idx], ...updates, updatedAt: new Date().toISOString() };
        saveLocalFile();
        await mongoSync('users', (col) => col.updateOne({ id }, { $set: memoryDb.users[idx] }));
        return memoryDb.users[idx];
      }
      return null;
    },
    deleteOne: async (id: string) => {
      syncFromDiskIfNeeded();
      const idx = memoryDb.users.findIndex((u) => u.id === id);
      if (idx !== -1) {
        memoryDb.users.splice(idx, 1);
        saveLocalFile();
        await mongoSync('users', (col) => col.deleteOne({ id }));
        return true;
      }
      return false;
    },
    count: async () => {
      syncFromDiskIfNeeded();
      return memoryDb.users.length;
    },
  },

  obreiros: {
    find: async () => {
      syncFromDiskIfNeeded();
      return memoryDb.obreiros;
    },
    findById: async (id: string) => {
      syncFromDiskIfNeeded();
      return memoryDb.obreiros.find((o) => o.id === id) || null;
    },
    insertOne: async (obreiro: Obreiro) => {
      syncFromDiskIfNeeded();
      memoryDb.obreiros.push(obreiro);
      saveLocalFile();
      await mongoSync('obreiros', (col) => col.insertOne(obreiro));
      return obreiro;
    },
    updateOne: async (id: string, updates: Partial<Obreiro>) => {
      syncFromDiskIfNeeded();
      const idx = memoryDb.obreiros.findIndex((o) => o.id === id);
      if (idx !== -1) {
        memoryDb.obreiros[idx] = { ...memoryDb.obreiros[idx], ...updates, updatedAt: new Date().toISOString() };
        saveLocalFile();
        await mongoSync('obreiros', (col) => col.updateOne({ id }, { $set: memoryDb.obreiros[idx] }));
        return memoryDb.obreiros[idx];
      }
      return null;
    },
    deleteOne: async (id: string) => {
      syncFromDiskIfNeeded();
      const idx = memoryDb.obreiros.findIndex((o) => o.id === id);
      if (idx !== -1) {
        memoryDb.obreiros.splice(idx, 1);
        saveLocalFile();
        await mongoSync('obreiros', (col) => col.deleteOne({ id }));
        return true;
      }
      return false;
    },
    count: async () => {
      syncFromDiskIfNeeded();
      return memoryDb.obreiros.length;
    },
  },

  alunos: {
    find: async (filter?: { search?: string; obreiroId?: string; status?: string }) => {
      syncFromDiskIfNeeded();
      let list = [...memoryDb.alunos];
      if (filter?.search) {
        const q = filter.search.toLowerCase().trim();
        list = list.filter((a) => a.nome.toLowerCase().includes(q));
      }
      if (filter?.obreiroId) {
        list = list.filter((a) => a.obreiroId === filter.obreiroId);
      }
      if (filter?.status) {
        list = list.filter((a) => a.status === filter.status);
      }
      return list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    },
    findById: async (id: string) => {
      syncFromDiskIfNeeded();
      return memoryDb.alunos.find((a) => a.id === id) || null;
    },
    insertOne: async (aluno: Aluno) => {
      syncFromDiskIfNeeded();
      memoryDb.alunos.push(aluno);
      saveLocalFile();
      await mongoSync('alunos', (col) => col.insertOne(aluno));
      return aluno;
    },
    updateOne: async (id: string, updates: Partial<Aluno>) => {
      syncFromDiskIfNeeded();
      const idx = memoryDb.alunos.findIndex((a) => a.id === id);
      if (idx !== -1) {
        memoryDb.alunos[idx] = { ...memoryDb.alunos[idx], ...updates, updatedAt: new Date().toISOString() };
        saveLocalFile();
        await mongoSync('alunos', (col) => col.updateOne({ id }, { $set: memoryDb.alunos[idx] }));
        return memoryDb.alunos[idx];
      }
      return null;
    },
    deleteOne: async (id: string) => {
      syncFromDiskIfNeeded();
      const idx = memoryDb.alunos.findIndex((a) => a.id === id);
      if (idx !== -1) {
        memoryDb.alunos.splice(idx, 1);
        saveLocalFile();
        await mongoSync('alunos', (col) => col.deleteOne({ id }));
        return true;
      }
      return false;
    },
    count: async (status?: string) => {
      syncFromDiskIfNeeded();
      if (!status) return memoryDb.alunos.length;
      return memoryDb.alunos.filter((a) => a.status === status).length;
    },
  },

  viagens: {
    find: async (filter?: { alunoId?: string; status?: string; search?: string }) => {
      syncFromDiskIfNeeded();
      let list = [...memoryDb.viagens];
      if (filter?.alunoId) {
        list = list.filter((v) => v.alunoId === filter.alunoId);
      }
      if (filter?.status) {
        list = list.filter((v) => v.status === filter.status);
      }
      if (filter?.search) {
        const q = filter.search.toLowerCase().trim();
        list = list.filter(
          (v) =>
            v.alunoNome.toLowerCase().includes(q) ||
            v.origem.toLowerCase().includes(q) ||
            v.destino.toLowerCase().includes(q) ||
            v.empresa.toLowerCase().includes(q) ||
            v.numeroLocalizador.toLowerCase().includes(q)
        );
      }
      return list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    },
    findById: async (id: string) => {
      syncFromDiskIfNeeded();
      return memoryDb.viagens.find((v) => v.id === id) || null;
    },
    insertOne: async (viagem: Viagem) => {
      syncFromDiskIfNeeded();
      memoryDb.viagens.push(viagem);
      saveLocalFile();
      await mongoSync('viagens', (col) => col.insertOne(viagem));
      return viagem;
    },
    updateOne: async (id: string, updates: Partial<Viagem>) => {
      syncFromDiskIfNeeded();
      const idx = memoryDb.viagens.findIndex((v) => v.id === id);
      if (idx !== -1) {
        memoryDb.viagens[idx] = { ...memoryDb.viagens[idx], ...updates, updatedAt: new Date().toISOString() };
        saveLocalFile();
        await mongoSync('viagens', (col) => col.updateOne({ id }, { $set: memoryDb.viagens[idx] }));
        return memoryDb.viagens[idx];
      }
      return null;
    },
    deleteOne: async (id: string) => {
      syncFromDiskIfNeeded();
      const idx = memoryDb.viagens.findIndex((v) => v.id === id);
      if (idx !== -1) {
        memoryDb.viagens.splice(idx, 1);
        saveLocalFile();
        await mongoSync('viagens', (col) => col.deleteOne({ id }));
        return true;
      }
      return false;
    },
    count: async () => {
      syncFromDiskIfNeeded();
      return memoryDb.viagens.length;
    },
  },

  documentos: {
    find: async (filter?: { alunoId?: string; viagemId?: string; tipo?: string; search?: string }) => {
      syncFromDiskIfNeeded();
      let list = [...memoryDb.documentos];
      if (filter?.alunoId) {
        list = list.filter((d) => d.alunoId === filter.alunoId);
      }
      if (filter?.viagemId) {
        list = list.filter((d) => d.viagemId === filter.viagemId);
      }
      if (filter?.tipo) {
        list = list.filter((d) => d.tipo === filter.tipo);
      }
      if (filter?.search) {
        const q = filter.search.toLowerCase().trim();
        list = list.filter(
          (d) =>
            d.titulo.toLowerCase().includes(q) ||
            d.filename.toLowerCase().includes(q) ||
            (d.alunoNome && d.alunoNome.toLowerCase().includes(q))
        );
      }
      return list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    },
    findById: async (id: string) => {
      syncFromDiskIfNeeded();
      return memoryDb.documentos.find((d) => d.id === id) || null;
    },
    insertOne: async (doc: Documento) => {
      syncFromDiskIfNeeded();
      memoryDb.documentos.push(doc);
      saveLocalFile();
      await mongoSync('documentos', (col) => col.insertOne(doc));
      return doc;
    },
    updateOne: async (id: string, updates: Partial<Documento>) => {
      syncFromDiskIfNeeded();
      const idx = memoryDb.documentos.findIndex((d) => d.id === id);
      if (idx !== -1) {
        memoryDb.documentos[idx] = { ...memoryDb.documentos[idx], ...updates, updatedAt: new Date().toISOString() };
        saveLocalFile();
        await mongoSync('documentos', (col) => col.updateOne({ id }, { $set: memoryDb.documentos[idx] }));
        return memoryDb.documentos[idx];
      }
      return null;
    },
    deleteOne: async (id: string) => {
      syncFromDiskIfNeeded();
      const idx = memoryDb.documentos.findIndex((d) => d.id === id);
      if (idx !== -1) {
        memoryDb.documentos.splice(idx, 1);
        saveLocalFile();
        await mongoSync('documentos', (col) => col.deleteOne({ id }));
        return true;
      }
      return false;
    },
    count: async () => {
      syncFromDiskIfNeeded();
      return memoryDb.documentos.length;
    },
  },

  user_invitations: {
    find: async () => {
      syncFromDiskIfNeeded();
      return memoryDb.user_invitations.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    },
    findById: async (id: string) => {
      syncFromDiskIfNeeded();
      return memoryDb.user_invitations.find((i) => i.id === id) || null;
    },
    findByToken: async (token: string) => {
      syncFromDiskIfNeeded();
      return memoryDb.user_invitations.find((i) => i.token === token) || null;
    },
    insertOne: async (inv: UserInvitation) => {
      syncFromDiskIfNeeded();
      memoryDb.user_invitations.push(inv);
      saveLocalFile();
      await mongoSync('user_invitations', (col) => col.insertOne(inv));
      return inv;
    },
    updateOne: async (id: string, updates: Partial<UserInvitation>) => {
      syncFromDiskIfNeeded();
      const idx = memoryDb.user_invitations.findIndex((i) => i.id === id);
      if (idx !== -1) {
        memoryDb.user_invitations[idx] = { ...memoryDb.user_invitations[idx], ...updates };
        saveLocalFile();
        await mongoSync('user_invitations', (col) => col.updateOne({ id }, { $set: memoryDb.user_invitations[idx] }));
        return memoryDb.user_invitations[idx];
      }
      return null;
    },
    deleteOne: async (id: string) => {
      syncFromDiskIfNeeded();
      const idx = memoryDb.user_invitations.findIndex((i) => i.id === id);
      if (idx !== -1) {
        memoryDb.user_invitations.splice(idx, 1);
        saveLocalFile();
        await mongoSync('user_invitations', (col) => col.deleteOne({ id }));
        return true;
      }
      return false;
    },
    countPending: async () => {
      syncFromDiskIfNeeded();
      const now = new Date().toISOString();
      return memoryDb.user_invitations.filter((i) => i.status === 'PENDENTE' && i.expiresAt > now).length;
    },
  },

  auditoria: {
    find: async (limit = 100) => {
      syncFromDiskIfNeeded();
      return [...memoryDb.auditoria].sort((a, b) => b.timestamp.localeCompare(a.timestamp)).slice(0, limit);
    },
    insertOne: async (log: AuditLog) => {
      syncFromDiskIfNeeded();
      memoryDb.auditoria.push(log);
      saveLocalFile();
      await mongoSync('auditoria', (col) => col.insertOne(log));
      return log;
    },
  },

  settings: {
    get: async (): Promise<SystemSettings> => {
      syncFromDiskIfNeeded();
      if (!memoryDb.settings) {
        memoryDb.settings = {
          dataLimitePassagem: defaultDeadline,
          updatedAt: new Date().toISOString(),
        };
        saveLocalFile();
      }
      return memoryDb.settings;
    },
    update: async (dataLimitePassagem: string): Promise<SystemSettings> => {
      syncFromDiskIfNeeded();
      memoryDb.settings = {
        dataLimitePassagem,
        updatedAt: new Date().toISOString(),
      };
      saveLocalFile();
      await mongoSync('settings', (col) => col.updateOne({ key: 'system' }, { $set: { ...memoryDb.settings, key: 'system' } }, { upsert: true }));
      return memoryDb.settings;
    },
  },
};

