import { Router, Request, Response } from 'express';
import { db } from '../db/database.js';
import { authenticateToken, requireRoles } from '../services/authService.js';
import { logAudit } from '../services/auditService.js';
import { Aluno, AlunoStatus } from '../types/index.js';

export const alunosRouter = Router();

// GET /api/alunos
alunosRouter.get('/alunos', authenticateToken, async (req: Request, res: Response) => {
  try {
    const { search, obreiroId, status } = req.query;
    const filter = {
      search: typeof search === 'string' ? search : undefined,
      obreiroId: typeof obreiroId === 'string' && obreiroId ? obreiroId : undefined,
      status: typeof status === 'string' && status ? status : undefined,
    };

    const alunos = await db.alunos.find(filter);
    res.json(alunos);
  } catch (error: any) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: 'Erro ao listar alunos.' });
  }
});

// GET /api/alunos/:id
alunosRouter.get('/alunos/:id', authenticateToken, async (req: Request, res: Response) => {
  try {
    const aluno = await db.alunos.findById(req.params.id);
    if (!aluno) {
      res.status(404).json({ error: 'NOT_FOUND', message: 'Aluno não encontrado.' });
      return;
    }
    res.json(aluno);
  } catch (error: any) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: 'Erro ao buscar aluno.' });
  }
});

// POST /api/alunos
alunosRouter.post(
  '/alunos',
  authenticateToken,
  requireRoles('ADMIN_HOST', 'ADMIN', 'GESTOR'),
  async (req: Request, res: Response) => {
    try {
      const { nome, obreiroId, obreiroIds, status, passagemStatusManual } = req.body;

      // Strict validation: Nome is required
      if (!nome || !nome.trim()) {
        res.status(400).json({ error: 'BAD_REQUEST', message: 'O nome do aluno é obrigatório.' });
        return;
      }

      // Collect obreiro IDs
      let targetObreiroIds: string[] = [];
      if (Array.isArray(obreiroIds) && obreiroIds.length > 0) {
        targetObreiroIds = obreiroIds.filter(Boolean);
      } else if (obreiroId) {
        targetObreiroIds = [obreiroId];
      }

      if (targetObreiroIds.length === 0) {
        res.status(400).json({ error: 'BAD_REQUEST', message: 'Selecione ao menos um obreiro responsável.' });
        return;
      }

      const allObreiros = await db.obreiros.find();
      const matchedObreiros = allObreiros.filter((o) => targetObreiroIds.includes(o.id));

      if (matchedObreiros.length === 0) {
        res.status(400).json({ error: 'BAD_REQUEST', message: 'Nenhum obreiro válido foi encontrado.' });
        return;
      }

      const obreiroNames = matchedObreiros.map((o) => o.nome);
      const primaryObreiro = matchedObreiros[0];

      const validStatus: AlunoStatus[] = ['ATIVO', 'INATIVO', 'CONCLUÍDO', 'SUSPENSO'];
      const alunoStatus: AlunoStatus = validStatus.includes(status) ? status : 'ATIVO';

      const newAluno: Aluno = {
        id: `aln_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        nome: nome.trim(),
        obreiroId: primaryObreiro.id,
        obreiroNome: obreiroNames.join(', '),
        obreiroIds: matchedObreiros.map((o) => o.id),
        obreiroNomes: obreiroNames,
        status: alunoStatus,
        passagemStatusManual: passagemStatusManual || undefined,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      await db.alunos.insertOne(newAluno);

      await logAudit(req, {
        acao: 'CRIACAO_ALUNO',
        entidade: 'Aluno',
        entidadeId: newAluno.id,
        detalhes: `Aluno cadastrado: ${newAluno.nome} com obreiro(s) ${obreiroNames.join(', ')}`,
      });

      res.status(201).json(newAluno);
    } catch (error: any) {
      res.status(500).json({ error: 'INTERNAL_ERROR', message: 'Erro ao cadastrar aluno.' });
    }
  }
);

// PUT /api/alunos/:id
alunosRouter.put(
  '/alunos/:id',
  authenticateToken,
  requireRoles('ADMIN_HOST', 'ADMIN', 'GESTOR'),
  async (req: Request, res: Response) => {
    try {
      const existing = await db.alunos.findById(req.params.id);
      if (!existing) {
        res.status(404).json({ error: 'NOT_FOUND', message: 'Aluno não encontrado.' });
        return;
      }

      const { nome, obreiroId, obreiroIds, status, passagemStatusManual } = req.body;
      const updates: Partial<Aluno> = {};

      if (nome !== undefined) {
        if (!nome.trim()) {
          res.status(400).json({ error: 'BAD_REQUEST', message: 'O nome do aluno não pode ser vazio.' });
          return;
        }
        updates.nome = nome.trim();
      }

      let targetObreiroIds: string[] | null = null;
      if (Array.isArray(obreiroIds)) {
        targetObreiroIds = obreiroIds.filter(Boolean);
      } else if (obreiroId !== undefined) {
        targetObreiroIds = obreiroId ? [obreiroId] : [];
      }

      if (targetObreiroIds !== null) {
        const allObreiros = await db.obreiros.find();
        const matchedObreiros = allObreiros.filter((o) => targetObreiroIds!.includes(o.id));
        if (matchedObreiros.length > 0) {
          const names = matchedObreiros.map((o) => o.nome);
          updates.obreiroIds = matchedObreiros.map((o) => o.id);
          updates.obreiroNomes = names;
          updates.obreiroId = matchedObreiros[0].id;
          updates.obreiroNome = names.join(', ');
        }
      }

      if (status !== undefined) {
        const validStatus: AlunoStatus[] = ['ATIVO', 'INATIVO', 'CONCLUÍDO', 'SUSPENSO'];
        if (validStatus.includes(status)) {
          updates.status = status;
        }
      }

      if (passagemStatusManual !== undefined) {
        updates.passagemStatusManual = passagemStatusManual || undefined;
      }

      const updated = await db.alunos.updateOne(req.params.id, updates);

      // Also sync student name and obreiro in related viagens and documentos if changed
      if (updates.nome || updates.obreiroNome) {
        const viagens = await db.viagens.find({ alunoId: existing.id });
        for (const v of viagens) {
          await db.viagens.updateOne(v.id, {
            alunoNome: updates.nome || v.alunoNome,
            obreiroNome: updates.obreiroNome || v.obreiroNome,
          });
        }
        const docs = await db.documentos.find({ alunoId: existing.id });
        for (const d of docs) {
          await db.documentos.updateOne(d.id, {
            alunoNome: updates.nome || d.alunoNome,
          });
        }
      }

      await logAudit(req, {
        acao: 'EDICAO_ALUNO',
        entidade: 'Aluno',
        entidadeId: existing.id,
        detalhes: `Aluno atualizado: ${existing.nome}`,
      });

      res.json(updated);
    } catch (error: any) {
      res.status(500).json({ error: 'INTERNAL_ERROR', message: 'Erro ao atualizar aluno.' });
    }
  }
);

// DELETE /api/alunos/:id
alunosRouter.delete(
  '/alunos/:id',
  authenticateToken,
  requireRoles('ADMIN_HOST', 'ADMIN'),
  async (req: Request, res: Response) => {
    try {
      const existing = await db.alunos.findById(req.params.id);
      if (!existing) {
        res.status(404).json({ error: 'NOT_FOUND', message: 'Aluno não encontrado.' });
        return;
      }

      await db.alunos.deleteOne(req.params.id);

      await logAudit(req, {
        acao: 'EXCLUSAO_ALUNO',
        entidade: 'Aluno',
        entidadeId: existing.id,
        detalhes: `Aluno excluído: ${existing.nome}`,
      });

      res.json({ message: 'Aluno excluído com sucesso.' });
    } catch (error: any) {
      res.status(500).json({ error: 'INTERNAL_ERROR', message: 'Erro ao excluir aluno.' });
    }
  }
);

// POST /api/alunos/batch
// Bulk actions on multiple students (change ticket status, assign obreiros, change enrollment status, delete)
alunosRouter.post(
  '/alunos/batch',
  authenticateToken,
  requireRoles('ADMIN_HOST', 'ADMIN', 'GESTOR'),
  async (req: Request, res: Response) => {
    try {
      const { action, alunoIds, data } = req.body;

      if (!Array.isArray(alunoIds) || alunoIds.length === 0) {
        res.status(400).json({ error: 'BAD_REQUEST', message: 'Selecione ao menos um aluno.' });
        return;
      }

      let affectedCount = 0;

      if (action === 'UPDATE_PASSAGEM_STATUS') {
        const manualStatus = data?.passagemStatusManual || undefined;
        for (const id of alunoIds) {
          const updated = await db.alunos.updateOne(id, {
            passagemStatusManual: manualStatus,
          });
          if (updated) affectedCount++;
        }
      } else if (action === 'UPDATE_OBREIROS') {
        const targetObreiroIds: string[] = Array.isArray(data?.obreiroIds) ? data.obreiroIds.filter(Boolean) : [];
        if (targetObreiroIds.length === 0) {
          res.status(400).json({ error: 'BAD_REQUEST', message: 'Selecione ao menos um obreiro.' });
          return;
        }

        const allObreiros = await db.obreiros.find();
        const matched = allObreiros.filter((o) => targetObreiroIds.includes(o.id));
        const names = matched.map((o) => o.nome);

        for (const id of alunoIds) {
          const updated = await db.alunos.updateOne(id, {
            obreiroIds: matched.map((o) => o.id),
            obreiroNomes: names,
            obreiroId: matched[0]?.id || '',
            obreiroNome: names.join(', '),
          });
          if (updated) affectedCount++;
        }
      } else if (action === 'UPDATE_STATUS') {
        const validStatus: AlunoStatus[] = ['ATIVO', 'INATIVO', 'CONCLUÍDO', 'SUSPENSO'];
        if (!validStatus.includes(data?.status)) {
          res.status(400).json({ error: 'BAD_REQUEST', message: 'Status de matrícula inválido.' });
          return;
        }
        for (const id of alunoIds) {
          const updated = await db.alunos.updateOne(id, { status: data.status });
          if (updated) affectedCount++;
        }
      } else if (action === 'DELETE') {
        for (const id of alunoIds) {
          const deleted = await db.alunos.deleteOne(id);
          if (deleted) affectedCount++;
        }
      } else {
        res.status(400).json({ error: 'BAD_REQUEST', message: 'Ação em lote desconhecida.' });
        return;
      }

      await logAudit(req, {
        acao: `LOTE_${action}`,
        entidade: 'Aluno',
        detalhes: `Ação em lote ${action} executada com sucesso em ${affectedCount} aluno(s).`,
      });

      res.json({
        success: true,
        action,
        count: affectedCount,
        message: `${affectedCount} aluno(s) atualizado(s) em lote com sucesso.`,
      });
    } catch (error: any) {
      res.status(500).json({ error: 'INTERNAL_ERROR', message: 'Erro ao executar ação em lote.' });
    }
  }
);

// POST /api/alunos/import-document
// Reads text/list from document, parses students and assigns obreiros
alunosRouter.post(
  '/alunos/import-document',
  authenticateToken,
  requireRoles('ADMIN_HOST', 'ADMIN', 'GESTOR'),
  async (req: Request, res: Response) => {
    try {
      const { text, defaultObreiroId, items } = req.body;

      const allObreiros = await db.obreiros.find();
      const createdAlunos: Aluno[] = [];

      // If structured items provided directly:
      if (Array.isArray(items) && items.length > 0) {
        for (const item of items) {
          if (!item.nome || !item.nome.trim()) continue;
          const obId = item.obreiroId || defaultObreiroId || (allObreiros[0]?.id || '');
          const obreiro = allObreiros.find((o) => o.id === obId) || allObreiros[0];

          const newAluno: Aluno = {
            id: `aln_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
            nome: item.nome.trim(),
            obreiroId: obreiro?.id || '',
            obreiroNome: obreiro?.nome || 'Não vinculado',
            obreiroIds: obreiro ? [obreiro.id] : [],
            obreiroNomes: obreiro ? [obreiro.nome] : [],
            status: 'ATIVO',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          };
          await db.alunos.insertOne(newAluno);
          createdAlunos.push(newAluno);
        }
      } else if (typeof text === 'string' && text.trim()) {
        // Parse line by line
        const lines = text.split('\n').map((l) => l.trim()).filter((l) => l.length > 0);
        for (const line of lines) {
          // Check for separator like "-" or ":" or ";" or tab
          // e.g., "Gabriel Rocha - Marcos Oliveira" or "Gabriel Rocha, Marcos"
          let alunoName = line;
          let obreiroMatch: any = null;

          if (line.includes(' - ')) {
            const parts = line.split(' - ');
            alunoName = parts[0].trim();
            const obName = parts[1].trim().toLowerCase();
            obreiroMatch = allObreiros.find((o) => o.nome.toLowerCase().includes(obName) || obName.includes(o.nome.toLowerCase()));
          } else if (line.includes(';')) {
            const parts = line.split(';');
            alunoName = parts[0].trim();
            const obName = parts[1].trim().toLowerCase();
            obreiroMatch = allObreiros.find((o) => o.nome.toLowerCase().includes(obName));
          } else if (line.includes('\t')) {
            const parts = line.split('\t');
            alunoName = parts[0].trim();
            const obName = parts[1].trim().toLowerCase();
            obreiroMatch = allObreiros.find((o) => o.nome.toLowerCase().includes(obName));
          }

          // Strip numbers if numbered list (e.g., "1. Gabriel Rocha" or "1 - Gabriel")
          alunoName = alunoName.replace(/^\d+[\.\-\)]\s*/, '').trim();
          if (!alunoName) continue;

          const finalObreiro = obreiroMatch || allObreiros.find((o) => o.id === defaultObreiroId) || allObreiros[0];

          const newAluno: Aluno = {
            id: `aln_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
            nome: alunoName,
            obreiroId: finalObreiro?.id || '',
            obreiroNome: finalObreiro?.nome || 'Não vinculado',
            obreiroIds: finalObreiro ? [finalObreiro.id] : [],
            obreiroNomes: finalObreiro ? [finalObreiro.nome] : [],
            status: 'ATIVO',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          };
          await db.alunos.insertOne(newAluno);
          createdAlunos.push(newAluno);
        }
      }

      await logAudit(req, {
        acao: 'IMPORTACAO_ALUNOS_DOCUMENTO',
        entidade: 'Aluno',
        detalhes: `${createdAlunos.length} aluno(s) cadastrado(s) automaticamente a partir de documento/lista.`,
      });

      res.status(201).json({
        message: `${createdAlunos.length} aluno(s) cadastrado(s) com sucesso.`,
        total: createdAlunos.length,
        alunos: createdAlunos,
      });
    } catch (error: any) {
      res.status(500).json({ error: 'INTERNAL_ERROR', message: 'Erro ao importar alunos do documento.' });
    }
  }
);

