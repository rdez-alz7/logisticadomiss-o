import { Router, Request, Response } from 'express';
import { db, getDbStatus } from '../db/database.js';
import { authenticateToken, requireRoles } from '../services/authService.js';
import { logAudit } from '../services/auditService.js';
import { PassagemStatus } from '../types/index.js';

export const dashboardRouter = Router();

// Helper to determine ticket status for an aluno
export function getAlunoPassagemStatus(
  alunoId: string,
  alunoManualStatus: PassagemStatus | undefined,
  viagensAluno: any[],
  dataLimitePassagem: string
): PassagemStatus {
  // If manual override set, prioritize it
  if (alunoManualStatus) {
    return alunoManualStatus;
  }

  // 1. If has registered trip, status is COMPRADO
  if (viagensAluno && viagensAluno.length > 0) {
    return 'COMPRADO';
  }

  // 2. Compare today with deadline
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const limitDate = new Date(dataLimitePassagem);
  limitDate.setHours(0, 0, 0, 0);

  const diffMs = limitDate.getTime() - today.getTime();
  const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

  // If in same month of deadline (or passed deadline): URGENCIA
  const isSameMonthAndYear =
    today.getFullYear() === limitDate.getFullYear() &&
    today.getMonth() === limitDate.getMonth();

  if (diffDays <= 0 || isSameMonthAndYear) {
    return 'URGENCIA';
  }

  // If missing 1 month (approx <= 30 days) before deadline: EM_RISCO
  if (diffDays <= 30) {
    return 'EM_RISCO';
  }

  // Initially in deadline window: NO_PRAZO (Blue)
  return 'NO_PRAZO';
}

dashboardRouter.get('/dashboard', authenticateToken, async (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const canViewInvites = user.role === 'ADMIN_HOST' || user.role === 'ADMIN';

    const [
      totalAlunos,
      alunosAtivos,
      totalObreiros,
      totalViagens,
      totalDocumentos,
      convitesPendentes,
      obreirosList,
      alunosList,
      viagensList,
      recentDocs,
      settings,
    ] = await Promise.all([
      db.alunos.count(),
      db.alunos.count('ATIVO'),
      db.obreiros.count(),
      db.viagens.count(),
      db.documentos.count(),
      canViewInvites ? db.user_invitations.countPending() : Promise.resolve(0),
      db.obreiros.find(),
      db.alunos.find(),
      db.viagens.find(),
      db.documentos.find(),
      db.settings.get(),
    ]);

    // Map aluno viagens for quick lookup
    const viagensByAluno: Record<string, any[]> = {};
    for (const v of viagensList) {
      if (!viagensByAluno[v.alunoId]) viagensByAluno[v.alunoId] = [];
      viagensByAluno[v.alunoId].push(v);
    }

    // Compute status for all students
    let totalComprados = 0;
    let totalEmRisco = 0;
    let totalUrgencia = 0;
    let totalNoPrazo = 0;

    const alunosComStatus = alunosList.map((aluno) => {
      const studentTrips = viagensByAluno[aluno.id] || [];
      const passagemStatus = getAlunoPassagemStatus(
        aluno.id,
        aluno.passagemStatusManual,
        studentTrips,
        settings.dataLimitePassagem
      );

      if (passagemStatus === 'COMPRADO') totalComprados++;
      else if (passagemStatus === 'EM_RISCO') totalEmRisco++;
      else if (passagemStatus === 'URGENCIA') totalUrgencia++;
      else totalNoPrazo++;

      return {
        id: aluno.id,
        nome: aluno.nome,
        obreiroNome: aluno.obreiroNome || (aluno.obreiroNomes && aluno.obreiroNomes.join(', ')) || 'Não vinculado',
        obreiroNomes: aluno.obreiroNomes || (aluno.obreiroNome ? [aluno.obreiroNome] : []),
        obreiroIds: aluno.obreiroIds || (aluno.obreiroId ? [aluno.obreiroId] : []),
        status: aluno.status,
        passagemStatus,
        temPassagem: studentTrips.length > 0,
      };
    });

    // Calculate "Alunos por obreiro" with exact counts and responsible lists
    const alunosPorObreiro = obreirosList.map((obr) => {
      const respAlunos = alunosComStatus.filter(
        (a) =>
          (a.obreiroIds && a.obreiroIds.includes(obr.id)) ||
          a.obreiroNome.includes(obr.nome)
      );

      return {
        obreiroId: obr.id,
        obreiroNome: obr.nome,
        funcao: obr.funcao,
        quantidadeAlunos: respAlunos.length,
        alunos: respAlunos,
        comprados: respAlunos.filter((a) => a.passagemStatus === 'COMPRADO').length,
        pendentes: respAlunos.filter((a) => a.passagemStatus !== 'COMPRADO').length,
      };
    }).sort((a, b) => b.quantidadeAlunos - a.quantidadeAlunos);

    // Recent 5 viagens
    const topViagens = viagensList.slice(0, 5);

    // Recent 5 documents without heavy payloads
    const topDocs = recentDocs.slice(0, 5).map(({ dataBase64, ...rest }) => rest);

    // List of students lacking tickets (for deadline countdown modal/widget)
    const alunosFaltandoComprar = alunosComStatus.filter((a) => a.passagemStatus !== 'COMPRADO');

    res.json({
      cards: {
        totalAlunos,
        alunosAtivos,
        totalObreiros,
        totalViagens,
        totalDocumentos,
        convitesPendentes: canViewInvites ? convitesPendentes : undefined,
        totalComprados,
        totalEmRisco,
        totalUrgencia,
        totalNoPrazo,
      },
      dataLimitePassagem: settings.dataLimitePassagem,
      alunosPorObreiro,
      alunosStatusList: alunosComStatus,
      alunosFaltandoComprar,
      recentViagens: topViagens,
      recentDocumentos: topDocs,
      dbStatus: getDbStatus(),
    });
  } catch (error: any) {
    console.error('Erro ao carregar dashboard:', error);
    res.status(500).json({ error: 'INTERNAL_ERROR', message: 'Erro ao carregar métricas do dashboard.' });
  }
});

// GET /api/settings
dashboardRouter.get('/settings', authenticateToken, async (_req: Request, res: Response) => {
  try {
    const settings = await db.settings.get();
    res.json(settings);
  } catch (error: any) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: 'Erro ao buscar configurações.' });
  }
});

// PUT /api/settings/data-limite
dashboardRouter.put(
  '/settings/data-limite',
  authenticateToken,
  requireRoles('ADMIN_HOST', 'ADMIN', 'GESTOR'),
  async (req: Request, res: Response) => {
    try {
      const { dataLimitePassagem } = req.body;
      if (!dataLimitePassagem) {
        res.status(400).json({ error: 'BAD_REQUEST', message: 'Informe a data limite.' });
        return;
      }

      const updated = await db.settings.update(dataLimitePassagem);

      await logAudit(req, {
        acao: 'ATUALIZAR_DATA_LIMITE_PASSAGEM',
        entidade: 'SystemSettings',
        detalhes: `Data limite de passagens alterada para ${dataLimitePassagem}`,
      });

      res.json(updated);
    } catch (error: any) {
      res.status(500).json({ error: 'INTERNAL_ERROR', message: 'Erro ao atualizar data limite.' });
    }
  }
);

