import React, { useState } from 'react';
import {
  X,
  Share2,
  Copy,
  Check,
  Printer,
  Compass,
  Bus,
  Plane,
  Car,
  Ship,
  Train,
  Building,
  User,
  Calendar,
  Clock,
  MapPin,
  Ticket,
  ExternalLink,
} from 'lucide-react';
import { Viagem, MeioTransporte } from '../types';

interface ViagemShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  viagem: Viagem | null;
}

export const ViagemShareModal: React.FC<ViagemShareModalProps> = ({
  isOpen,
  onClose,
  viagem,
}) => {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [copied, setCopied] = useState(false);

  if (!isOpen || !viagem) return null;

  const getTransportLabel = (meio?: MeioTransporte) => {
    switch (meio) {
      case 'AVIAO':
        return '✈️ Avião';
      case 'CARRO':
        return '🚗 Carro';
      case 'BARCO':
        return '🚢 Barco';
      case 'TREM':
        return '🚆 Trem';
      case 'VAN':
        return '🚐 Van';
      case 'ONIBUS':
      default:
        return '🚍 Ônibus';
    }
  };

  const formattedDate = (d?: string) => {
    if (!d) return '-';
    try {
      const [year, month, day] = d.split('-');
      if (year && month && day) return `${day}/${month}/${year}`;
    } catch {}
    return d;
  };

  const messageText = `📋 *LOG MMS — ITINERÁRIO DE VIAGEM*
━━━━━━━━━━━━━━━━━━━━━━
👤 *Aluno:* ${viagem.alunoNome}
⛪ *Obreiro(a) Resp.:* ${viagem.obreiroNome || 'Não informado'}
${getTransportLabel(viagem.meioTransporte)} ${viagem.empresa ? `(${viagem.empresa})` : ''}

📍 *Origem:* ${viagem.origem}${viagem.localEmbarque ? ` - Local: ${viagem.localEmbarque}` : ''}
🏁 *Destino:* ${viagem.destino}${viagem.localDesembarque ? ` - Local: ${viagem.localDesembarque}` : ''}

📅 *Partida:* ${formattedDate(viagem.dataSaida)} às ${viagem.horarioSaida || '00:00'}
🏁 *Chegada Prevista:* ${formattedDate(viagem.dataChegada || viagem.dataSaida)} às ${viagem.horarioChegada || '00:00'}

🎫 *Nº Localizador / Bilhete:* ${viagem.numeroLocalizador || 'Em confirmação'}
📌 *Status:* ${viagem.status}${viagem.tipo ? ` (${viagem.tipo})` : ''}
${viagem.observacoes ? `\n📝 *Observações:* ${viagem.observacoes}` : ''}
━━━━━━━━━━━━━━━━━━━━━━
_LOG MMS — Sistema de Gestão e Logística_`;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(messageText);
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    } catch {
      // Fallback
      const textArea = document.createElement('textarea');
      textArea.value = messageText;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    }
  };

  const handleOpenWhatsApp = () => {
    const encoded = encodeURIComponent(messageText);
    const cleanPhone = phoneNumber.replace(/\D/g, '');
    let url = `https://api.whatsapp.com/send?text=${encoded}`;
    if (cleanPhone) {
      // if Brazilian number without country code, prepend 55
      const finalPhone = cleanPhone.length <= 11 ? `55${cleanPhone}` : cleanPhone;
      url = `https://api.whatsapp.com/send?phone=${finalPhone}&text=${encoded}`;
    }
    window.open(url, '_blank');
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-xl w-full shadow-2xl border border-slate-200 overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-800 to-teal-800 text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center text-emerald-300">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base leading-tight">Compartilhar Itinerário de Viagem</h3>
              <p className="text-xs text-emerald-200">Envio para WhatsApp, cópia de texto e ficha de embarque</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-white/70 hover:text-white rounded-lg hover:bg-white/10 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {/* Visual Travel Ticket Card */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 relative overflow-hidden print:border-black print:bg-white">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200/80">
              <div className="flex items-center gap-2">
                <span className="font-black text-slate-800 text-sm tracking-wide">LOG MMS</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold border border-emerald-200">
                  {viagem.tipo || 'VIAGEM'}
                </span>
              </div>
              <div className="text-xs font-semibold text-slate-500">
                Localizador: <span className="font-mono font-bold text-slate-800">{viagem.numeroLocalizador || 'N/A'}</span>
              </div>
            </div>

            <div className="mt-3 grid grid-cols-2 gap-3 text-xs">
              <div>
                <span className="text-slate-400 block font-medium">Aluno(a)</span>
                <span className="font-bold text-slate-900 text-sm block mt-0.5">{viagem.alunoNome}</span>
              </div>
              <div>
                <span className="text-slate-400 block font-medium">Obreiro(a) Responsável</span>
                <span className="font-semibold text-slate-800 block mt-0.5">{viagem.obreiroNome || 'Não informado'}</span>
              </div>
            </div>

            <div className="mt-4 p-3 bg-white rounded-xl border border-slate-200/60 flex items-center justify-between">
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400">Origem</span>
                <p className="font-bold text-slate-900 text-sm">{viagem.origem}</p>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  {formattedDate(viagem.dataSaida)} às {viagem.horarioSaida || '00:00'}
                </p>
                {viagem.localEmbarque && (
                  <p className="text-[10px] text-slate-400 mt-0.5">Local: {viagem.localEmbarque}</p>
                )}
              </div>

              <div className="flex flex-col items-center px-3">
                <span className="text-xs font-bold text-emerald-700">{viagem.meioTransporte || 'TRANSPORTE'}</span>
                <div className="w-16 h-0.5 bg-emerald-300 relative my-1">
                  <div className="w-2 h-2 rounded-full bg-emerald-600 absolute right-0 -top-[3px]"></div>
                </div>
                <span className="text-[10px] text-slate-400 font-medium">{viagem.empresa || ''}</span>
              </div>

              <div className="text-right">
                <span className="text-[10px] uppercase font-bold text-slate-400">Destino</span>
                <p className="font-bold text-slate-900 text-sm">{viagem.destino}</p>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  {formattedDate(viagem.dataChegada || viagem.dataSaida)} às {viagem.horarioChegada || '00:00'}
                </p>
                {viagem.localDesembarque && (
                  <p className="text-[10px] text-slate-400 mt-0.5">Local: {viagem.localDesembarque}</p>
                )}
              </div>
            </div>

            {viagem.observacoes && (
              <div className="mt-3 text-xs bg-amber-50/80 border border-amber-200/60 rounded-xl p-2.5 text-amber-900">
                <span className="font-bold block">Observações:</span>
                <p className="mt-0.5 text-[11px]">{viagem.observacoes}</p>
              </div>
            )}
          </div>

          {/* WhatsApp Direct Option */}
          <div className="space-y-3 pt-1">
            <label className="block text-xs font-bold text-slate-700">
              Número de WhatsApp do Destinatário <span className="font-normal text-slate-400">(opcional - deixe em branco para escolher no WhatsApp)</span>:
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                placeholder="Ex: (11) 98765-4321 ou DDD+Número"
                className="flex-1 px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition"
              />
              <button
                type="button"
                onClick={handleOpenWhatsApp}
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold rounded-xl text-sm shadow-md transition"
              >
                <Share2 className="w-4 h-4" />
                <span>Abrir WhatsApp</span>
              </button>
            </div>
          </div>

          {/* Formatted Message Preview Box */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-700">Texto formatado pronto para envio:</span>
              <button
                type="button"
                onClick={handleCopy}
                className="inline-flex items-center gap-1 font-semibold text-emerald-700 hover:text-emerald-800 transition"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span className="text-emerald-600 font-bold">Copiado!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copiar texto</span>
                  </>
                )}
              </button>
            </div>
            <textarea
              readOnly
              value={messageText}
              rows={5}
              className="w-full p-3 bg-slate-100/80 border border-slate-200 rounded-xl font-mono text-xs text-slate-700 focus:outline-none select-all"
            />
          </div>

          {/* Action Footer */}
          <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
            <button
              type="button"
              onClick={handlePrint}
              className="inline-flex items-center gap-2 px-4 py-2 border border-slate-300 text-slate-700 hover:bg-slate-50 font-semibold rounded-xl text-xs transition active:scale-95"
            >
              <Printer className="w-4 h-4 text-slate-500" />
              <span>Imprimir Ficha / Salvar PDF</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs transition"
            >
              Fechar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
