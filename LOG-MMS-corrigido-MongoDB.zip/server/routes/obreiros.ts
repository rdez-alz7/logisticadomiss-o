import { Router, Request, Response } from 'express';
import { db, saveLocalFile } from '../db/database.js';
import { authenticateToken, requireRoles } from '../services/authService.js';
import { logAudit } from '../services/auditService.js';
import { Obreiro } from '../types/index.js';

export const obreirosRouter = Router();

// GET /api/obreiros
obreirosRouter.get('/obreiros', authenticateToken, async (_req: Request, res: Response) => {
  try {
    const obreiros = await db.obreiros.find();
    res.json(obreiros);
  } catch (error: any) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: 'Erro ao buscar obreiros.' });
  }
});

// GET /api/obreiros/:id
obreirosRouter.get('/obreiros/:id', authenticateToken, async (req: Request, res: Response) => {
  try {
    const obreiro = await db.obreiros.findById(req.params.id);
    if (!obreiro) {
      res.status(404).json({ error: 'NOT_FOUND', message: 'Obreiro não encontrado.' });
      return;
    }
    res.json(obreiro);
  } catch (error: any) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: 'Erro ao buscar obreiro.' });
  }
});

// POST /api/obreiros
obreirosRouter.post(
  '/obreiros',
  authenticateToken,
  requireRoles('ADMIN_HOST', 'ADMIN', 'GESTOR'),
  async (req: Request, res: Response) => {
    try {
      const { nome, email, funcao, status } = req.body;

      if (!nome || !nome.trim()) {
        res.status(400).json({ error: 'BAD_REQUEST', message: 'O nome do obreiro é obrigatório.' });
        return;
      }

      const newObreiro: Obreiro = {
        id: `obr_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        nome: nome.trim(),
        email: email?.trim() || '',
        funcao: funcao?.trim() || 'Obreiro',
        status: status === 'INATIVO' ? 'INATIVO' : 'ATIVO',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      await db.obreiros.insertOne(newObreiro);

      await logAudit(req, {
        acao: 'CRIACAO_OBREIRO',
        entidade: 'Obreiro',
        entidadeId: newObreiro.id,
        detalhes: `Obreiro cadastrado: ${newObreiro.nome}`,
      });

      res.status(201).json(newObreiro);
    } catch (error: any) {
      res.status(500).json({ error: 'INTERNAL_ERROR', message: 'Erro ao criar obreiro.' });
    }
  }
);

// PUT /api/obreiros/:id
obreirosRouter.put(
  '/obreiros/:id',
  authenticateToken,
  requireRoles('ADMIN_HOST', 'ADMIN', 'GESTOR'),
  async (req: Request, res: Response) => {
    try {
      const { nome, email, funcao, status } = req.body;
      const existing = await db.obreiros.findById(req.params.id);

      if (!existing) {
        res.status(404).json({ error: 'NOT_FOUND', message: 'Obreiro não encontrado.' });
        return;
      }

      const updates: Partial<Obreiro> = {};
      if (nome !== undefined) updates.nome = nome.trim();
      if (email !== undefined) updates.email = email.trim();
      if (funcao !== undefined) updates.funcao = funcao.trim();
      if (status !== undefined) updates.status = status;

      const updated = await db.obreiros.updateOne(req.params.id, updates);

      // If obreiro name changed, sync in alunos and viagens
      if (updates.nome && updates.nome !== existing.nome) {
        const alunos = await db.alunos.find({ obreiroId: existing.id });
        for (const a of alunos) {
          await db.alunos.updateOne(a.id, { obreiroNome: updates.nome });
        }
      }

      await logAudit(req, {
        acao: 'EDICAO_OBREIRO',
        entidade: 'Obreiro',
        entidadeId: existing.id,
        detalhes: `Obreiro atualizado: ${existing.nome}`,
      });

      res.json(updated);
    } catch (error: any) {
      res.status(500).json({ error: 'INTERNAL_ERROR', message: 'Erro ao atualizar obreiro.' });
    }
  }
);

// DELETE /api/obreiros/:id
obreirosRouter.delete(
  '/obreiros/:id',
  authenticateToken,
  requireRoles('ADMIN_HOST', 'ADMIN'),
  async (req: Request, res: Response) => {
    try {
      const existing = await db.obreiros.findById(req.params.id);
      if (!existing) {
        res.status(404).json({ error: 'NOT_FOUND', message: 'Obreiro não encontrado.' });
        return;
      }

      const forceUnlink = req.query.forceUnlink === 'true' || req.body?.forceUnlink === true;

      // Check if any aluno has this obreiro
      const allAlunos = await db.alunos.find();
      const alunosLinked = allAlunos.filter(
        (a) => a.obreiroId === existing.id || (Array.isArray(a.obreiroIds) && a.obreiroIds.includes(existing.id))
      );

      if (alunosLinked.length > 0) {
        if (!forceUnlink) {
          res.status(400).json({
            error: 'BAD_REQUEST',
            message: `Não é possível excluir este obreiro pois existem ${alunosLinked.length} aluno(s) vinculados a ele.`,
          });
          return;
        }

        // Unlink obreiro from students
        for (const a of alunosLinked) {
          const updatedIds = (a.obreiroIds || []).filter((id) => id !== existing.id);
          const updatedNomes = (a.obreiroNomes || []).filter((nome) => nome !== existing.nome);
          const newPrimaryId = a.obreiroId === existing.id ? (updatedIds[0] || '') : a.obreiroId;
          const newPrimaryNome = updatedNomes.length > 0 ? updatedNomes.join(', ') : (newPrimaryId ? a.obreiroNome : 'Não vinculado');

          await db.alunos.updateOne(a.id, {
            obreiroId: newPrimaryId,
            obreiroNome: newPrimaryNome,
            obreiroIds: updatedIds,
            obreiroNomes: updatedNomes,
          });
        }
      }

      await db.obreiros.deleteOne(req.params.id);
      saveLocalFile();

      await logAudit(req, {
        acao: 'EXCLUSAO_OBREIRO',
        entidade: 'Obreiro',
        entidadeId: existing.id,
        detalhes: `Obreiro excluído: ${existing.nome}`,
      });

      res.json({ message: 'Obreiro excluído com sucesso.' });
    } catch (error: any) {
      res.status(500).json({ error: 'INTERNAL_ERROR', message: 'Erro ao excluir obreiro.' });
    }
  }
);

// POST /api/obreiros/batch - Batch actions (e.g. DELETE multiple obreiros at once)
obreirosRouter.post(
  '/obreiros/batch',
  authenticateToken,
  requireRoles('ADMIN_HOST', 'ADMIN'),
  async (req: Request, res: Response) => {
    try {
      const { action, obreiroIds, forceUnlinkAlunos = true } = req.body;

      if (!Array.isArray(obreiroIds) || obreiroIds.length === 0) {
        res.status(400).json({ error: 'BAD_REQUEST', message: 'Selecione ao menos um obreiro.' });
        return;
      }

      if (action === 'DELETE') {
        let deletedCount = 0;
        let unlinkedAlunosCount = 0;

        const allAlunos = await db.alunos.find();

        for (const obrId of obreiroIds) {
          const obreiro = await db.obreiros.findById(obrId);
          if (!obreiro) continue;

          // Find students linked to this obreiro
          const linkedAlunos = allAlunos.filter(
            (a) =>
              a.obreiroId === obrId ||
              (Array.isArray(a.obreiroIds) && a.obreiroIds.includes(obrId))
          );

          if (linkedAlunos.length > 0) {
            if (!forceUnlinkAlunos) {
              res.status(400).json({
                error: 'BAD_REQUEST',
                message: `O obreiro "${obreiro.nome}" possui ${linkedAlunos.length} aluno(s) vinculado(s).`,
              });
              return;
            }

            // Safely unlink the obreiro from these students
            for (const aluno of linkedAlunos) {
              const updatedObrIds = (aluno.obreiroIds || []).filter((id) => id !== obrId);
              const updatedObrNomes = (aluno.obreiroNomes || []).filter((nome) => nome !== obreiro.nome);

              const newPrimaryId = aluno.obreiroId === obrId ? (updatedObrIds[0] || '') : aluno.obreiroId;
              const newPrimaryNome = updatedObrNomes.length > 0 ? updatedObrNomes.join(', ') : (newPrimaryId ? aluno.obreiroNome : 'Não vinculado');

              await db.alunos.updateOne(aluno.id, {
                obreiroId: newPrimaryId,
                obreiroNome: newPrimaryNome,
                obreiroIds: updatedObrIds,
                obreiroNomes: updatedObrNomes,
              });
              unlinkedAlunosCount++;
            }
          }

          const deleted = await db.obreiros.deleteOne(obrId);
          if (deleted) {
            deletedCount++;
          }
        }

        saveLocalFile();

        await logAudit(req, {
          acao: 'LOTE_DELETE_OBREIROS',
          entidade: 'Obreiro',
          detalhes: `${deletedCount} obreiro(s) excluído(s) em lote. ${unlinkedAlunosCount} aluno(s) desvinculado(s).`,
        });

        res.json({
          success: true,
          count: deletedCount,
          unlinkedAlunosCount,
          message: `${deletedCount} obreiro(s) excluído(s) com sucesso.${
            unlinkedAlunosCount > 0 ? ` ${unlinkedAlunosCount} vínculo(s) de alunos atualizado(s) com segurança.` : ''
          }`,
        });
      } else {
        res.status(400).json({ error: 'BAD_REQUEST', message: 'Ação em lote desconhecida.' });
      }
    } catch (error: any) {
      res.status(500).json({ error: 'INTERNAL_ERROR', message: 'Erro ao processar ação em lote nos obreiros.' });
    }
  }
);

// POST /api/obreiros/import-document
// Reads text/list from document, parses obreiros and registers them
obreirosRouter.post(
  '/obreiros/import-document',
  authenticateToken,
  requireRoles('ADMIN_HOST', 'ADMIN', 'GESTOR'),
  async (req: Request, res: Response) => {
    try {
      const { text, defaultFuncao = 'Obreiro', items } = req.body;

      const existingObreiros = await db.obreiros.find();
      const existingNames = new Set(existingObreiros.map((o) => o.nome.toLowerCase().trim()));
      const createdObreiros: Obreiro[] = [];
      const skippedNames: string[] = [];

      // If pre-structured array
      if (Array.isArray(items) && items.length > 0) {
        for (const item of items) {
          const nome = item.nome?.trim();
          if (!nome) continue;
          if (existingNames.has(nome.toLowerCase())) {
            skippedNames.push(nome);
            continue;
          }

          const newObr: Obreiro = {
            id: `obr_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
            nome,
            email: item.email?.trim() || '',
            funcao: item.funcao?.trim() || defaultFuncao,
            status: 'ATIVO',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          };

          await db.obreiros.insertOne(newObr);
          existingNames.add(nome.toLowerCase());
          createdObreiros.push(newObr);
        }
      } else if (typeof text === 'string' && text.trim()) {
        const lines = text.split('\n').map((l) => l.trim()).filter((l) => l.length > 0);
        const emailRegex = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/;

        for (const line of lines) {
          let cleanLine = line;

          // Extract email if present
          let email = '';
          const emailMatch = cleanLine.match(emailRegex);
          if (emailMatch) {
            email = emailMatch[0];
            cleanLine = cleanLine.replace(email, '').trim();
          }

          let nome = cleanLine;
          let funcao = defaultFuncao;

          // Check for separator like " - " or ";" or "," or tab
          if (cleanLine.includes(' - ')) {
            const parts = cleanLine.split(' - ');
            nome = parts[0].trim();
            if (parts[1] && parts[1].trim()) {
              funcao = parts[1].trim();
            }
          } else if (cleanLine.includes(';')) {
            const parts = cleanLine.split(';');
            nome = parts[0].trim();
            if (parts[1] && parts[1].trim()) {
              funcao = parts[1].trim();
            }
          } else if (cleanLine.includes('\t')) {
            const parts = cleanLine.split('\t');
            nome = parts[0].trim();
            if (parts[1] && parts[1].trim()) {
              funcao = parts[1].trim();
            }
          } else if (cleanLine.includes('(') && cleanLine.includes(')')) {
            // e.g. "João Silva (Coordenador)"
            const match = cleanLine.match(/^(.*?)\((.*?)\)/);
            if (match) {
              nome = match[1].trim();
              funcao = match[2].trim();
            }
          }

          // Strip numbering prefixes like "1.", "1 -", "1)", "•", "-"
          nome = nome.replace(/^[\d\.\-\)\•\*\s]+/, '').trim();
          // Clean trailing punctuation
          nome = nome.replace(/[,;:-]+$/, '').trim();

          if (!nome || nome.length < 2) continue;

          // Avoid duplicate entry if name already registered
          if (existingNames.has(nome.toLowerCase())) {
            skippedNames.push(nome);
            continue;
          }

          const newObr: Obreiro = {
            id: `obr_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
            nome,
            email,
            funcao: funcao || defaultFuncao,
            status: 'ATIVO',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          };

          await db.obreiros.insertOne(newObr);
          existingNames.add(nome.toLowerCase());
          createdObreiros.push(newObr);
        }
      }

      await logAudit(req, {
        acao: 'IMPORTACAO_OBREIROS_DOCUMENTO',
        entidade: 'Obreiro',
        detalhes: `${createdObreiros.length} obreiro(s) cadastrado(s) automaticamente a partir de lista/documento.`,
      });

      res.status(201).json({
        message: `${createdObreiros.length} obreiro(s) cadastrado(s) com sucesso.${
          skippedNames.length > 0 ? ` (${skippedNames.length} já existiam e foram mantidos)` : ''
        }`,
        total: createdObreiros.length,
        obreiros: createdObreiros,
        skipped: skippedNames,
      });
    } catch (error: any) {
      res.status(500).json({ error: 'INTERNAL_ERROR', message: 'Erro ao importar obreiros do documento.' });
    }
  }
);
