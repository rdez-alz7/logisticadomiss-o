import React, { useState, useEffect } from 'react';
import {
  Compass,
  Plus,
  Search,
  Filter,
  Calendar,
  Clock,
  MapPin,
  Building,
  Edit2,
  Trash2,
  AlertCircle,
  CheckCircle,
  X,
  ChevronLeft,
  ChevronRight,
  Bus,
  Plane,
  Car,
  Ship,
  Train,
  ArrowRightLeft,
  Timer,
  Share2,
  RefreshCw,
  Radio,
  Activity,
  CheckCheck,
  Sparkles,
} from 'lucide-react';
import { api } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import { Viagem, Aluno, ViagemStatus, MeioTransporte } from '../types';
import { ConfirmModal } from '../components/ConfirmModal';
import { ViagemShareModal } from '../components/ViagemShareModal';
import { saveLocalSnapshot } from '../lib/sync';
import { BRAND_ASSETS } from '../lib/branding';

export const ViagensPage: React.FC = () => {
  const { hasRole } = useAuth();
  const canEdit = hasRole('ADMIN_HOST', 'ADMIN', 'GESTOR');
  const canDelete = hasRole('ADMIN_HOST', 'ADMIN');

  // Tab View Switcher (Feature 2): 'grade' (tabela) ou 'embarques' (Live Board ao vivo)
  const [activeTab, setActiveTab] = useState<'grade' | 'embarques'>('grade');

  const [viagens, setViagens] = useState<Viagem[]>([]);
  const [alunos, setAlunos] = useState<Aluno[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Live Board Embarques State (Feature 2)
  const [embarquesData, setEmbarquesData] = useState<{
    todayStr: string;
    tomorrowStr: string;
    stats: {
      totalHoje: number;
      emTransito: number;
      concluidasHoje: number;
      pendentesHoje: number;
      amanhaTotal: number;
      totalProximos48h: number;
    };
    hoje: Viagem[];
    amanha: Viagem[];
    proximos48h: Viagem[];
    emTransito: Viagem[];
    allUpcoming?: Viagem[];
  } | null>(null);
  const [isLoadingEmbarques, setIsLoadingEmbarques] = useState(false);
  const [lastBoardRefresh, setLastBoardRefresh] = useState<Date>(new Date());

  // WhatsApp Share & Ficha Modal State (Feature 6)
  const [shareViagem, setShareViagem] = useState<Viagem | null>(null);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);

  // Filters & Pagination
  const [search, setSearch] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('');
  const [selectedTransporte, setSelectedTransporte] = useState('');
  const [selectedAluno, setSelectedAluno] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalItems, setTotalItems] = useState(0);

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingViagem, setEditingViagem] = useState<Viagem | null>(null);

  // Form State (Ida)
  const [formAlunoId, setFormAlunoId] = useState('');
  const [formMeioTransporte, setFormMeioTransporte] = useState<MeioTransporte>('ONIBUS');
  const [formOrigem, setFormOrigem] = useState('');
  const [formDestino, setFormDestino] = useState('');
  const [formDataSaida, setFormDataSaida] = useState('');
  const [formHorarioSaida, setFormHorarioSaida] = useState('08:00');
  const [formDataChegada, setFormDataChegada] = useState('');
  const [formHorarioChegada, setFormHorarioChegada] = useState('16:00');
  const [formEmpresa, setFormEmpresa] = useState('');
  const [formNumeroLocalizador, setFormNumeroLocalizador] = useState('');
  const [formLocalEmbarque, setFormLocalEmbarque] = useState('');
  const [formLocalDesembarque, setFormLocalDesembarque] = useState('');
  const [formStatus, setFormStatus] = useState<ViagemStatus>('PLANEJADA');
  const [formObservacoes, setFormObservacoes] = useState('');

  // Round-trip State (Ida e Volta Juntos)
  const [cadastrarVolta, setCadastrarVolta] = useState(false);
  const [voltaMeioTransporte, setVoltaMeioTransporte] = useState<MeioTransporte>('ONIBUS');
  const [voltaDataSaida, setVoltaDataSaida] = useState('');
  const [voltaHorarioSaida, setVoltaHorarioSaida] = useState('08:00');
  const [voltaDataChegada, setVoltaDataChegada] = useState('');
  const [voltaHorarioChegada, setVoltaHorarioChegada] = useState('16:00');
  const [voltaEmpresa, setVoltaEmpresa] = useState('');
  const [voltaNumeroLocalizador, setVoltaNumeroLocalizador] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Delete State
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [deletingTitle, setDeletingTitle] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);

  // Toast
  const [toastMessage, setToastMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const showToast = (type: 'success' | 'error', text: string) => {
    setToastMessage({ type, text });
    setTimeout(() => setToastMessage(null), 4000);
  };

  const fetchAlunos = async () => {
    try {
      const res = await api.get('/alunos');
      setAlunos(res.data);
    } catch (err) {
      console.error('Erro ao carregar alunos:', err);
    }
  };

  const fetchViagens = async () => {
    setIsLoading(true);
    try {
      const params: any = {
        page,
        limit: 20,
      };
      if (search.trim()) params.search = search.trim();
      if (selectedStatus) params.status = selectedStatus;
      if (selectedAluno) params.alunoId = selectedAluno;

      const res = await api.get('/viagens', { params });
      const items = res.data.items || res.data;
      setViagens(items);
      setTotalPages(res.data.totalPages || 1);
      setTotalItems(res.data.total || 0);
      if (page === 1 && !search.trim() && !selectedStatus && !selectedAluno) {
        saveLocalSnapshot('viagens', items);
      }
    } catch (err) {
      showToast('error', 'Falha ao buscar viagens.');
    } finally {
      setIsLoading(false);
    }
  };

  const fetchEmbarques = async () => {
    setIsLoadingEmbarques(true);
    try {
      const res = await api.get('/viagens/embarques');
      setEmbarquesData(res.data);
      setLastBoardRefresh(new Date());
    } catch (err) {
      console.error('Erro ao buscar painel de embarques:', err);
    } finally {
      setIsLoadingEmbarques(false);
    }
  };

  const handleQuickStatusChange = async (viagemId: string, newStatus: ViagemStatus) => {
    try {
      await api.put(`/viagens/${viagemId}/quick-status`, { status: newStatus });
      showToast('success', `Status da viagem atualizado para ${newStatus}.`);
      if (activeTab === 'embarques') {
        fetchEmbarques();
      } else {
        fetchViagens();
      }
    } catch (err: any) {
      showToast('error', err.response?.data?.message || 'Erro ao alterar status do embarque.');
    }
  };

  const handleOpenShareModal = (v: Viagem) => {
    setShareViagem(v);
    setIsShareModalOpen(true);
  };

  useEffect(() => {
    fetchAlunos();
    fetchEmbarques();
  }, []);

  useEffect(() => {
    if (activeTab === 'embarques') {
      fetchEmbarques();
      const interval = setInterval(fetchEmbarques, 30000);
      return () => clearInterval(interval);
    }
  }, [activeTab]);

  useEffect(() => {
    const timer = setTimeout(() => {
      fetchViagens();
    }, 200);
    return () => clearTimeout(timer);
  }, [search, selectedStatus, selectedAluno, page]);

  const handleOpenCreateModal = () => {
    setEditingViagem(null);
    setFormAlunoId(alunos.length > 0 ? alunos[0].id : '');
    setFormMeioTransporte('ONIBUS');
    setFormOrigem('');
    setFormDestino('');
    const today = new Date().toISOString().split('T')[0];
    const nextWeek = new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0];
    setFormDataSaida(today);
    setFormHorarioSaida('08:00');
    setFormDataChegada(today);
    setFormHorarioChegada('16:00');
    setFormEmpresa('');
    setFormNumeroLocalizador('');
    setFormLocalEmbarque('');
    setFormLocalDesembarque('');
    setFormStatus('PLANEJADA');
    setFormObservacoes('');

    // Volta
    setCadastrarVolta(true); // Default true since user explicitly requested registering round-trip together!
    setVoltaMeioTransporte('ONIBUS');
    setVoltaDataSaida(nextWeek);
    setVoltaHorarioSaida('08:00');
    setVoltaDataChegada(nextWeek);
    setVoltaHorarioChegada('16:00');
    setVoltaEmpresa('');
    setVoltaNumeroLocalizador('');

    setFormError(null);
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (v: Viagem) => {
    setEditingViagem(v);
    setFormAlunoId(v.alunoId);
    setFormMeioTransporte(v.meioTransporte || 'ONIBUS');
    setFormOrigem(v.origem);
    setFormDestino(v.destino);
    setFormDataSaida(v.dataSaida);
    setFormHorarioSaida(v.horarioSaida);
    setFormDataChegada(v.dataChegada);
    setFormHorarioChegada(v.horarioChegada);
    setFormEmpresa(v.empresa || '');
    setFormNumeroLocalizador(v.numeroLocalizador || '');
    setFormLocalEmbarque(v.localEmbarque || '');
    setFormLocalDesembarque(v.localDesembarque || '');
    setFormStatus(v.status);
    setFormObservacoes(v.observacoes || '');
    setCadastrarVolta(false);
    setFormError(null);
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formAlunoId) {
      setFormError('Selecione o aluno.');
      return;
    }
    if (!formOrigem.trim() || !formDestino.trim()) {
      setFormError('Informe a origem e o destino da viagem.');
      return;
    }

    setIsSubmitting(true);
    setFormError(null);

    const payload: any = {
      alunoId: formAlunoId,
      meioTransporte: formMeioTransporte,
      origem: formOrigem.trim(),
      destino: formDestino.trim(),
      dataSaida: formDataSaida,
      horarioSaida: formHorarioSaida,
      dataChegada: formDataChegada,
      horarioChegada: formHorarioChegada,
      empresa: formEmpresa.trim(),
      numeroLocalizador: formNumeroLocalizador.trim(),
      localEmbarque: formLocalEmbarque.trim(),
      localDesembarque: formLocalDesembarque.trim(),
      status: formStatus,
      observacoes: formObservacoes.trim(),
      cadastrarVolta: !editingViagem && cadastrarVolta,
      voltaMeioTransporte,
      voltaDataSaida,
      voltaHorarioSaida,
      voltaDataChegada,
      voltaHorarioChegada,
      voltaEmpresa,
      voltaNumeroLocalizador,
    };

    try {
      if (editingViagem) {
        await api.put(`/viagens/${editingViagem.id}`, payload);
        showToast('success', 'Viagem atualizada com sucesso.');
      } else {
        await api.post('/viagens', payload);
        showToast('success', cadastrarVolta ? 'Ida e volta cadastradas juntas com sucesso!' : 'Viagem cadastrada com sucesso.');
      }
      setIsModalOpen(false);
      fetchViagens();
    } catch (err: any) {
      setFormError(err.response?.data?.message || 'Erro ao salvar viagem.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!deletingId) return;
    setIsDeleting(true);
    try {
      await api.delete(`/viagens/${deletingId}`);
      showToast('success', 'Viagem excluída com sucesso.');
      setDeletingId(null);
      fetchViagens();
    } catch (err: any) {
      showToast('error', err.response?.data?.message || 'Erro ao excluir viagem.');
    } finally {
      setIsDeleting(false);
    }
  };

  // Helper: calculate days remaining for a trip
  const getDaysRemainingForTrip = (dataSaida: string, horarioSaida: string) => {
    try {
      const now = new Date();
      const tripDate = new Date(`${dataSaida}T${horarioSaida || '00:00'}:00`);
      const diffMs = tripDate.getTime() - now.getTime();
      const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

      if (diffDays < 0) return { text: `${Math.abs(diffDays)}d atrás`, color: 'text-slate-400 bg-slate-100' };
      if (diffDays === 0) return { text: 'Hoje!', color: 'text-rose-700 bg-rose-100 font-black animate-pulse' };
      if (diffDays === 1) return { text: 'Amanhã', color: 'text-amber-800 bg-amber-100 font-bold' };
      return { text: `Faltam ${diffDays} dias`, color: 'text-emerald-800 bg-emerald-100 font-semibold' };
    } catch {
      return { text: '-', color: 'text-slate-400 bg-slate-50' };
    }
  };

  // Transport Icon & Label Helper
  const getTransportBadge = (tipo?: MeioTransporte) => {
    const t = tipo || 'ONIBUS';
    switch (t) {
      case 'AVIAO':
        return { label: 'Avião', icon: Plane, bg: 'bg-sky-50 text-sky-700 border-sky-200' };
      case 'CARRO':
        return { label: 'Carro', icon: Car, bg: 'bg-emerald-50 text-emerald-700 border-emerald-200' };
      case 'BARCO':
        return { label: 'Barco', icon: Ship, bg: 'bg-cyan-50 text-cyan-700 border-cyan-200' };
      case 'TREM':
        return { label: 'Trem', icon: Train, bg: 'bg-purple-50 text-purple-700 border-purple-200' };
      case 'VAN':
        return { label: 'Van', icon: Car, bg: 'bg-amber-50 text-amber-700 border-amber-200' };
      case 'ONIBUS':
      default:
        return { label: 'Ônibus', icon: Bus, bg: 'bg-blue-50 text-blue-700 border-blue-200' };
    }
  };

  const statusStyles: Record<ViagemStatus, { label: string; badge: string }> = {
    PLANEJADA: { label: 'Planejada', badge: 'bg-blue-100 text-blue-800 border-blue-300' },
    EM_ANDAMENTO: { label: 'Em Andamento', badge: 'bg-emerald-100 text-emerald-800 border-emerald-300 font-black animate-pulse' },
    CONCLUÍDA: { label: 'Concluída', badge: 'bg-slate-100 text-slate-700 border-slate-300' },
    CANCELADA: { label: 'Cancelada', badge: 'bg-rose-100 text-rose-800 border-rose-300' },
  };

  const filteredViagens = viagens.filter((v) => {
    if (!selectedTransporte) return true;
    return (v.meioTransporte || 'ONIBUS') === selectedTransporte;
  });

  return (
    <div className="space-y-6">
      {/* Toast Alert */}
      {toastMessage && (
        <div
          className={`fixed top-4 right-4 z-50 flex items-center gap-2 px-4 py-3 rounded-xl shadow-lg text-sm font-semibold transition ${
            toastMessage.type === 'success' ? 'bg-emerald-700 text-white' : 'bg-rose-700 text-white'
          }`}
        >
          {toastMessage.type === 'success' ? (
            <CheckCircle className="w-5 h-5 flex-shrink-0" />
          ) : (
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
          )}
          <span>{toastMessage.text}</span>
        </div>
      )}

      {/* Header with Military Theme and Cover Image touch */}
      <div className="rounded-2xl bg-gradient-to-r from-[#213827] via-[#2a4632] to-[#1c3022] p-5 sm:p-6 text-white border border-[#3b5943] shadow-md flex flex-col md:flex-row md:items-center justify-between gap-4 relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-72 opacity-25 pointer-events-none hidden md:block">
          <img
            src={BRAND_ASSETS.coverImage}
            alt="Mission Movement"
            className="w-full h-full object-cover object-center"
          />
        </div>
        <div className="relative z-10">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-[#132218]/80 text-[#cae2cd] text-[10px] font-bold uppercase tracking-wider mb-2 border border-[#3b5d44]">
            <Sparkles className="w-3 h-3 text-[#9cc79f]" />
            <span>Mission Movement • Logística de Rotas</span>
          </div>
          <h1 className="text-2xl font-black text-white tracking-tight flex items-center gap-2.5">
            <Compass className="w-6 h-6 text-[#9cc79f]" />
            <span>Viagens e Logística</span>
          </h1>
          <p className="text-xs sm:text-sm text-[#c7dcc9] mt-0.5 max-w-xl">
            Cadastro unificado de ida e volta, múltiplos modais de transporte, monitor de embarques ao vivo e compartilhamento via WhatsApp.
          </p>
        </div>

        {canEdit && (
          <button
            onClick={handleOpenCreateModal}
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-[#ffffff] hover:bg-[#edf5ee] text-[#1b2c1f] font-bold rounded-xl text-xs transition shadow-md active:scale-95 flex-shrink-0 relative z-10 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5 text-[#2b4b34]" />
            <span>+ Cadastrar Viagem (Ida e Volta)</span>
          </button>
        )}
      </div>

      {/* View Switcher: Grade Geral vs Monitor de Embarques Ao Vivo (Feature 2) */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-2.5 rounded-2xl border border-slate-200/80 shadow-2xs">
        <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl">
          <button
            type="button"
            onClick={() => setActiveTab('grade')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition ${
              activeTab === 'grade'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Compass className="w-4 h-4 text-emerald-700" />
            <span>Grade de Viagens</span>
            <span className="px-1.5 py-0.2 rounded-full bg-slate-200 text-slate-700 text-[10px]">
              {totalItems}
            </span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTab('embarques');
              fetchEmbarques();
            }}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition ${
              activeTab === 'embarques'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Radio className="w-4 h-4 text-emerald-600 animate-pulse" />
            <span>Monitor de Embarques Ao Vivo</span>
            {embarquesData && (
              <span className="px-1.5 py-0.2 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black">
                {embarquesData.stats.totalHoje} hoje
              </span>
            )}
          </button>
        </div>

        {activeTab === 'embarques' && (
          <div className="flex items-center gap-3 pr-2">
            <span className="text-[11px] text-slate-400 hidden sm:inline">
              Atualizado às {lastBoardRefresh.toLocaleTimeString()}
            </span>
            <button
              type="button"
              onClick={fetchEmbarques}
              disabled={isLoadingEmbarques}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition active:scale-95"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoadingEmbarques ? 'animate-spin' : ''}`} />
              <span>Atualizar</span>
            </button>
          </div>
        )}
      </div>

      {activeTab === 'grade' && (
        <>
          {/* Filters Bar */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3 pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
            placeholder="Pesquisar por aluno, origem, destino, empresa ou localizador..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition"
          />
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Transporte filter */}
          <select
            value={selectedTransporte}
            onChange={(e) => setSelectedTransporte(e.target.value)}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition"
          >
            <option value="">Todos os transportes</option>
            <option value="ONIBUS">Ônibus</option>
            <option value="AVIAO">Avião</option>
            <option value="CARRO">Carro</option>
            <option value="BARCO">Barco</option>
            <option value="TREM">Trem</option>
            <option value="VAN">Van</option>
          </select>

          {/* Status filter */}
          <select
            value={selectedStatus}
            onChange={(e) => {
              setSelectedStatus(e.target.value);
              setPage(1);
            }}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition"
          >
            <option value="">Todos os status</option>
            <option value="PLANEJADA">PLANEJADA</option>
            <option value="EM_ANDAMENTO">EM ANDAMENTO</option>
            <option value="CONCLUÍDA">CONCLUÍDA</option>
            <option value="CANCELADA">CANCELADA</option>
          </select>

          {(search || selectedStatus || selectedTransporte || selectedAluno) && (
            <button
              onClick={() => {
                setSearch('');
                setSelectedStatus('');
                setSelectedTransporte('');
                setSelectedAluno('');
                setPage(1);
              }}
              className="text-xs text-rose-600 hover:text-rose-800 font-semibold px-2 py-1.5"
            >
              Limpar
            </button>
          )}
        </div>
      </div>

      {/* Main Table View */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                <th className="py-3.5 px-6">Aluno e Transporte</th>
                <th className="py-3.5 px-6">Obreiro</th>
                <th className="py-3.5 px-6">Trajeto</th>
                <th className="py-3.5 px-6 text-center">Partida</th>
                <th className="py-3.5 px-6 text-center">Dias Restantes</th>
                <th className="py-3.5 px-6 text-center">Status (Automático)</th>
                <th className="py-3.5 px-6 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {isLoading ? (
                [...Array(4)].map((_, i) => (
                  <tr key={i} className="animate-pulse">
                    <td className="py-4 px-6"><div className="h-4 bg-slate-200 rounded w-36"></div></td>
                    <td className="py-4 px-6"><div className="h-4 bg-slate-200 rounded w-28"></div></td>
                    <td className="py-4 px-6"><div className="h-4 bg-slate-200 rounded w-44"></div></td>
                    <td className="py-4 px-6 text-center"><div className="h-4 bg-slate-200 rounded w-20 mx-auto"></div></td>
                    <td className="py-4 px-6 text-center"><div className="h-4 bg-slate-200 rounded w-20 mx-auto"></div></td>
                    <td className="py-4 px-6 text-center"><div className="h-5 bg-slate-200 rounded-full w-20 mx-auto"></div></td>
                    <td className="py-4 px-6 text-right"><div className="h-6 bg-slate-200 rounded w-16 ml-auto"></div></td>
                  </tr>
                ))
              ) : filteredViagens.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    <Compass className="w-10 h-10 mx-auto text-slate-300 mb-2" />
                    <p className="font-semibold text-slate-700">Nenhuma viagem encontrada</p>
                    <p className="text-xs text-slate-500 mt-1">
                      {search || selectedStatus || selectedTransporte
                        ? 'Verifique os filtros aplicados.'
                        : 'Cadastre a primeira viagem (ida e volta juntos) para começar o rastreio.'}
                    </p>
                  </td>
                </tr>
              ) : (
                filteredViagens.map((viagem) => {
                  const s = statusStyles[viagem.status] || { label: viagem.status, badge: 'bg-slate-100 text-slate-700' };
                  const t = getTransportBadge(viagem.meioTransporte);
                  const TransportIcon = t.icon;
                  const countdown = getDaysRemainingForTrip(viagem.dataSaida, viagem.horarioSaida);

                  return (
                    <tr key={viagem.id} className="hover:bg-slate-50/60 transition">
                      {/* Aluno & Transporte */}
                      <td className="py-4 px-6">
                        <div className="flex items-center gap-2.5">
                          <span
                            title={`Transporte: ${t.label}`}
                            className={`p-2 rounded-xl border flex items-center justify-center flex-shrink-0 ${t.bg}`}
                          >
                            <TransportIcon className="w-4 h-4" />
                          </span>
                          <div>
                            <span className="font-bold text-slate-900 block">{viagem.alunoNome}</span>
                            <div className="flex items-center gap-1.5 mt-0.5">
                              {viagem.tipo && (
                                <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded border ${
                                  viagem.tipo === 'IDA' ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : 'bg-purple-50 text-purple-800 border-purple-200'
                                }`}>
                                  {viagem.tipo}
                                </span>
                              )}
                              <span className="text-[11px] text-slate-500 font-medium">
                                {viagem.empresa || t.label} {viagem.numeroLocalizador ? `• Loc: ${viagem.numeroLocalizador}` : ''}
                              </span>
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Obreiro Responsável */}
                      <td className="py-4 px-6">
                        <div className="flex items-center gap-1.5 font-semibold text-slate-800 text-xs">
                          <Building className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0" />
                          <span>{viagem.obreiroNome || 'Não informado'}</span>
                        </div>
                      </td>

                      {/* Trajeto */}
                      <td className="py-4 px-6">
                        <div className="flex items-center gap-1.5 text-xs">
                          <span className="font-semibold text-slate-800">{viagem.origem}</span>
                          <span className="text-slate-400 font-black">→</span>
                          <span className="font-semibold text-slate-800">{viagem.destino}</span>
                        </div>
                        {(viagem.localEmbarque || viagem.localDesembarque) && (
                          <p className="text-[11px] text-slate-400 mt-0.5 truncate max-w-xs">
                            Embarque: {viagem.localEmbarque || '-'}
                          </p>
                        )}
                      </td>

                      {/* Partida */}
                      <td className="py-4 px-6 text-center text-xs">
                        <span className="font-semibold text-slate-800 block">{viagem.dataSaida}</span>
                        <span className="text-slate-500 block">{viagem.horarioSaida}</span>
                      </td>

                      {/* Contador de Dias que Faltam */}
                      <td className="py-4 px-6 text-center">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs ${countdown.color}`}>
                          <Timer className="w-3.5 h-3.5" />
                          <span>{countdown.text}</span>
                        </span>
                      </td>

                      {/* Status Automático por Horário */}
                      <td className="py-4 px-6 text-center">
                        <span
                          title="Status atualizado automaticamente conforme as horas cadastradas"
                          className={`inline-block text-[11px] px-2.5 py-0.5 rounded-full border uppercase tracking-wider ${s.badge}`}
                        >
                          {s.label}
                        </span>
                      </td>

                      {/* Ações */}
                      <td className="py-4 px-6 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* WhatsApp Share Button (Feature 6) */}
                          <button
                            type="button"
                            onClick={() => handleOpenShareModal(viagem)}
                            title="Compartilhar Itinerário no WhatsApp / Imprimir Ficha"
                            className="p-1.5 text-emerald-600 hover:text-emerald-800 hover:bg-emerald-50 rounded-lg transition"
                          >
                            <Share2 className="w-4 h-4" />
                          </button>

                          {canEdit && (
                            <button
                              onClick={() => handleOpenEditModal(viagem)}
                              title="Editar viagem"
                              className="p-1.5 text-slate-500 hover:text-blue-700 hover:bg-slate-100 rounded-lg transition"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                          )}
                          {canDelete && (
                            <button
                              onClick={() => {
                                setDeletingId(viagem.id);
                                setDeletingTitle(`${viagem.alunoNome} (${viagem.origem} -> ${viagem.destino})`);
                              }}
                              title="Excluir viagem"
                              className="p-1.5 text-slate-500 hover:text-rose-700 hover:bg-slate-100 rounded-lg transition"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
      </>
      )}

      {/* MONITOR DE EMBARQUES AO VIVO (Feature 2) */}
      {activeTab === 'embarques' && (
        <div className="space-y-6">
          {/* Top KPI Cards do Live Board */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-emerald-900 text-white p-4 rounded-2xl shadow-sm border border-emerald-700/60 relative overflow-hidden">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-emerald-200 uppercase tracking-wider">Em Trânsito Agora</span>
                <span className="flex h-2.5 w-2.5 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-400"></span>
                </span>
              </div>
              <p className="text-3xl font-black mt-2">{embarquesData?.stats.emTransito || 0}</p>
              <p className="text-[11px] text-emerald-300 mt-1">Viagens em andamento no momento</p>
            </div>

            <div className="bg-white p-4 rounded-2xl shadow-xs border border-slate-200">
              <div className="flex items-center justify-between text-slate-500">
                <span className="text-xs font-bold uppercase tracking-wider">Total Hoje</span>
                <Calendar className="w-4 h-4 text-blue-600" />
              </div>
              <p className="text-3xl font-black text-slate-900 mt-2">{embarquesData?.stats.totalHoje || 0}</p>
              <p className="text-[11px] text-slate-400 mt-1">Partidas e chegadas previstas hoje</p>
            </div>

            <div className="bg-white p-4 rounded-2xl shadow-xs border border-slate-200">
              <div className="flex items-center justify-between text-slate-500">
                <span className="text-xs font-bold uppercase tracking-wider">Aguardando Embarque</span>
                <Clock className="w-4 h-4 text-amber-600" />
              </div>
              <p className="text-3xl font-black text-amber-700 mt-2">{embarquesData?.stats.pendentesHoje || 0}</p>
              <p className="text-[11px] text-slate-400 mt-1">Planejadas para hoje ainda não iniciadas</p>
            </div>

            <div className="bg-white p-4 rounded-2xl shadow-xs border border-slate-200">
              <div className="flex items-center justify-between text-slate-500">
                <span className="text-xs font-bold uppercase tracking-wider">Concluídas Hoje</span>
                <CheckCheck className="w-4 h-4 text-emerald-600" />
              </div>
              <p className="text-3xl font-black text-emerald-700 mt-2">{embarquesData?.stats.concluidasHoje || 0}</p>
              <p className="text-[11px] text-slate-400 mt-1">Chegadas confirmadas hoje</p>
            </div>
          </div>

          {/* SEÇÃO 1: EM TRÂNSITO AGORA */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse"></span>
                <span>Em Trânsito Agora ({embarquesData?.emTransito.length || 0})</span>
              </h2>
              <span className="text-xs text-slate-400">Rastreio em rota ativa</span>
            </div>

            {embarquesData?.emTransito.length === 0 ? (
              <div className="p-6 bg-white rounded-2xl border border-slate-200 text-center text-slate-400 text-xs">
                Nenhuma viagem em trânsito no momento.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {embarquesData?.emTransito.map((v) => {
                  const t = getTransportBadge(v.meioTransporte);
                  const TransportIcon = t.icon;
                  return (
                    <div
                      key={v.id}
                      className="bg-white p-5 rounded-2xl border-2 border-emerald-500/40 shadow-sm relative overflow-hidden"
                    >
                      <div className="flex items-start justify-between gap-3 pb-3 border-b border-slate-100">
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-xl flex items-center justify-center border ${t.bg}`}>
                            <TransportIcon className="w-5 h-5" />
                          </div>
                          <div>
                            <h3 className="font-bold text-slate-900 text-base leading-tight">{v.alunoNome}</h3>
                            <p className="text-xs text-slate-500 mt-0.5">
                              Obreiro(a): <span className="font-semibold text-slate-700">{v.obreiroNome || 'Não informado'}</span>
                            </p>
                          </div>
                        </div>

                        <span className="px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-100 text-emerald-800 border border-emerald-300 animate-pulse">
                          Em Trânsito
                        </span>
                      </div>

                      <div className="py-3 space-y-2 text-xs">
                        <div className="flex items-center justify-between bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                          <div>
                            <span className="text-[10px] font-bold text-slate-400 uppercase">Saída</span>
                            <p className="font-bold text-slate-800 text-sm">{v.origem}</p>
                            <p className="text-slate-500">{v.horarioSaida}</p>
                          </div>
                          <div className="text-center px-2">
                            <span className="text-[10px] text-emerald-700 font-bold block">{t.label}</span>
                            <span className="text-slate-400 font-black">━━━➔</span>
                            <span className="text-[10px] text-slate-400 font-mono">{v.empresa || ''}</span>
                          </div>
                          <div className="text-right">
                            <span className="text-[10px] font-bold text-slate-400 uppercase">Destino</span>
                            <p className="font-bold text-slate-800 text-sm">{v.destino}</p>
                            <p className="text-slate-500">Prev. {v.horarioChegada || '--:--'}</p>
                          </div>
                        </div>

                        {v.numeroLocalizador && (
                          <div className="flex items-center justify-between text-xs px-1 text-slate-600">
                            <span>Localizador:</span>
                            <span className="font-mono font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded">
                              {v.numeroLocalizador}
                            </span>
                          </div>
                        )}
                      </div>

                      {/* Quick Status and WhatsApp Actions */}
                      <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                        <button
                          type="button"
                          onClick={() => handleOpenShareModal(v)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold text-xs rounded-xl border border-emerald-200 transition active:scale-95"
                        >
                          <Share2 className="w-3.5 h-3.5 text-emerald-700" />
                          <span>WhatsApp</span>
                        </button>

                        {canEdit && (
                          <button
                            type="button"
                            onClick={() => handleQuickStatusChange(v.id, 'CONCLUÍDA')}
                            className="inline-flex items-center gap-1.5 px-4 py-1.5 bg-emerald-700 hover:bg-emerald-800 active:scale-95 text-white font-bold text-xs rounded-xl transition shadow-xs"
                          >
                            <CheckCheck className="w-3.5 h-3.5" />
                            <span>Confirmar Chegada</span>
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* SEÇÃO 2: EMBARQUES DE HOJE (AGUARDANDO PARTIDA) */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-amber-500"></span>
                <span>Embarques de Hoje - Aguardando Partida ({embarquesData?.hoje.filter((v) => v.status === 'PLANEJADA').length || 0})</span>
              </h2>
              <span className="text-xs text-slate-400">Prontos para embarque hoje</span>
            </div>

            {embarquesData?.hoje.filter((v) => v.status === 'PLANEJADA').length === 0 ? (
              <div className="p-6 bg-white rounded-2xl border border-slate-200 text-center text-slate-400 text-xs">
                Todos os embarques previstos para hoje já foram iniciados ou não há novos embarques pendentes.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {embarquesData?.hoje
                  .filter((v) => v.status === 'PLANEJADA')
                  .map((v) => {
                    const t = getTransportBadge(v.meioTransporte);
                    const TransportIcon = t.icon;
                    return (
                      <div
                        key={v.id}
                        className="bg-white p-4 rounded-2xl border border-amber-200/80 shadow-xs space-y-3"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <span className="text-[11px] font-black px-2 py-0.5 rounded-lg bg-amber-100 text-amber-900 border border-amber-300 inline-block mb-1">
                              Partida às {v.horarioSaida || '00:00'}
                            </span>
                            <h3 className="font-bold text-slate-900 text-sm">{v.alunoNome}</h3>
                            <p className="text-[11px] text-slate-500">Obreiro: {v.obreiroNome || '-'}</p>
                          </div>
                          <div className={`w-8 h-8 rounded-lg flex items-center justify-center border ${t.bg}`}>
                            <TransportIcon className="w-4 h-4" />
                          </div>
                        </div>

                        <div className="text-xs bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                          <p className="font-bold text-slate-800">
                            {v.origem} <span className="text-slate-400">➔</span> {v.destino}
                          </p>
                          <p className="text-[11px] text-slate-500 mt-0.5">
                            {v.empresa || t.label} {v.numeroLocalizador ? `• Loc: ${v.numeroLocalizador}` : ''}
                          </p>
                          {v.localEmbarque && (
                            <p className="text-[10px] text-slate-400 mt-1 truncate">Local: {v.localEmbarque}</p>
                          )}
                        </div>

                        <div className="flex items-center justify-between gap-2 pt-1 border-t border-slate-100">
                          <button
                            type="button"
                            onClick={() => handleOpenShareModal(v)}
                            className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 hover:text-emerald-900 p-1"
                          >
                            <Share2 className="w-3.5 h-3.5" />
                            <span>WhatsApp</span>
                          </button>

                          {canEdit && (
                            <button
                              type="button"
                              onClick={() => handleQuickStatusChange(v.id, 'EM_ANDAMENTO')}
                              className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-xs transition active:scale-95"
                            >
                              Confirmar Embarque
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
              </div>
            )}
          </div>

          {/* SEÇÃO 3: AMANHÃ & PRÓXIMAS 48 HORAS */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-blue-500"></span>
                <span>Programação de Amanhã e Próximas 48 Horas ({embarquesData?.proximos48h.length || 0})</span>
              </h2>
              <span className="text-xs text-slate-400">Antecipação e aviso prévio</span>
            </div>

            {embarquesData?.proximos48h.length === 0 ? (
              <div className="p-6 bg-white rounded-2xl border border-slate-200 text-center text-slate-400 text-xs">
                Nenhum embarque programado para as próximas 48 horas.
              </div>
            ) : (
              <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase font-bold text-[10px]">
                        <th className="py-3 px-4">Data/Hora</th>
                        <th className="py-3 px-4">Aluno</th>
                        <th className="py-3 px-4">Obreiro</th>
                        <th className="py-3 px-4">Trajeto</th>
                        <th className="py-3 px-4">Transporte</th>
                        <th className="py-3 px-4 text-right">Notificar</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {embarquesData?.proximos48h.map((v) => {
                        const t = getTransportBadge(v.meioTransporte);
                        return (
                          <tr key={v.id} className="hover:bg-slate-50/60">
                            <td className="py-3 px-4 font-bold text-slate-900 whitespace-nowrap">
                              {v.dataSaida} às {v.horarioSaida}
                            </td>
                            <td className="py-3 px-4 font-semibold text-slate-800">{v.alunoNome}</td>
                            <td className="py-3 px-4 text-slate-600">{v.obreiroNome || '-'}</td>
                            <td className="py-3 px-4 font-semibold text-slate-800">
                              {v.origem} → {v.destino}
                            </td>
                            <td className="py-3 px-4 text-slate-600">
                              {t.label} {v.empresa ? `(${v.empresa})` : ''}
                            </td>
                            <td className="py-3 px-4 text-right">
                              <button
                                type="button"
                                onClick={() => handleOpenShareModal(v)}
                                className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-bold bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-lg border border-emerald-200 transition"
                              >
                                <Share2 className="w-3 h-3 text-emerald-700" />
                                <span>WhatsApp</span>
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>

          {/* SEÇÃO 4: CONCLUÍDAS HOJE */}
          {embarquesData && embarquesData.stats.concluidasHoje > 0 && (
            <div className="space-y-3">
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <CheckCheck className="w-4 h-4 text-emerald-600" />
                <span>Viagens Concluídas Hoje ({embarquesData.stats.concluidasHoje})</span>
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {embarquesData.hoje
                  .filter((v) => v.status === 'CONCLUÍDA')
                  .map((v) => (
                    <div
                      key={v.id}
                      className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs flex items-center justify-between text-xs"
                    >
                      <div>
                        <span className="font-bold text-slate-800 block">{v.alunoNome}</span>
                        <span className="text-[11px] text-slate-400 block">
                          {v.origem} → {v.destino}
                        </span>
                      </div>
                      <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[10px]">
                        Concluída
                      </span>
                    </div>
                  ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* MODAL: CADASTRAR VIAGEM COM OPÇÃO DE IDA E VOLTA JUNTOS */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl overflow-hidden border border-slate-200">
            <div className="p-6 bg-slate-900 text-white flex items-center justify-between">
              <div>
                <h3 className="font-bold text-lg flex items-center gap-2">
                  <Compass className="w-5 h-5 text-emerald-400" />
                  <span>{editingViagem ? 'Editar Viagem' : 'Cadastrar Viagem (Ida e Volta Juntos)'}</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Informe o aluno, transporte (ônibus, carro, barco, avião) e os dados de deslocamento.
                </p>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-white p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
              {formError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 flex-shrink-0 text-rose-600" />
                  <span>{formError}</span>
                </div>
              )}

              {/* 1. Aluno Selecionado & Meio de Transporte */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Aluno <span className="text-rose-500">*</span>
                  </label>
                  <select
                    required
                    value={formAlunoId}
                    onChange={(e) => setFormAlunoId(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:bg-white outline-none"
                  >
                    <option value="" disabled>Selecione o aluno...</option>
                    {alunos.map((a) => (
                      <option key={a.id} value={a.id}>
                        {a.nome} (Obr. {a.obreiroNome})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Opção de Transporte <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={formMeioTransporte}
                    onChange={(e) => setFormMeioTransporte(e.target.value as MeioTransporte)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:bg-white outline-none font-semibold"
                  >
                    <option value="ONIBUS">🚌 Ônibus</option>
                    <option value="AVIAO">✈️ Avião</option>
                    <option value="CARRO">🚗 Carro</option>
                    <option value="BARCO">🚢 Barco</option>
                    <option value="TREM">🚆 Trem</option>
                    <option value="VAN">🚐 Van</option>
                    <option value="OUTRO">Outro</option>
                  </select>
                </div>
              </div>

              {/* SECTION: DADOS DA IDA */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
                    <span>1. Trajeto de Ida</span>
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Origem (Partida) *</label>
                    <input
                      type="text"
                      required
                      value={formOrigem}
                      onChange={(e) => setFormOrigem(e.target.value)}
                      placeholder="Ex: São Paulo - SP"
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Destino (Chegada) *</label>
                    <input
                      type="text"
                      required
                      value={formDestino}
                      onChange={(e) => setFormDestino(e.target.value)}
                      placeholder="Ex: Belo Horizonte - MG"
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Data Saída</label>
                    <input
                      type="date"
                      required
                      value={formDataSaida}
                      onChange={(e) => setFormDataSaida(e.target.value)}
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-xl text-xs outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Horário Saída</label>
                    <input
                      type="time"
                      required
                      value={formHorarioSaida}
                      onChange={(e) => setFormHorarioSaida(e.target.value)}
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-xl text-xs outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Data Chegada</label>
                    <input
                      type="date"
                      required
                      value={formDataChegada}
                      onChange={(e) => setFormDataChegada(e.target.value)}
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-xl text-xs outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Horário Chegada</label>
                    <input
                      type="time"
                      required
                      value={formHorarioChegada}
                      onChange={(e) => setFormHorarioChegada(e.target.value)}
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-xl text-xs outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    value={formEmpresa}
                    onChange={(e) => setFormEmpresa(e.target.value)}
                    placeholder="Empresa (Ex: Cometa, LATAM, Gol, Barco Regional)"
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs outline-none"
                  />
                  <input
                    type="text"
                    value={formNumeroLocalizador}
                    onChange={(e) => setFormNumeroLocalizador(e.target.value)}
                    placeholder="Código / Localizador / Bilhete"
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs outline-none"
                  />
                </div>
              </div>

              {/* SECTION: CADASTRAR VOLTA JUNTO (Opcional ou marcada por padrão) */}
              {!editingViagem && (
                <div className="p-4 bg-purple-50/70 rounded-2xl border border-purple-200 space-y-4">
                  <div className="flex items-center justify-between pb-2 border-b border-purple-200/80">
                    <label className="flex items-center gap-2 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={cadastrarVolta}
                        onChange={(e) => setCadastrarVolta(e.target.checked)}
                        className="w-4 h-4 rounded text-purple-600 focus:ring-purple-500"
                      />
                      <span className="text-xs font-bold uppercase tracking-wider text-purple-900 flex items-center gap-1.5">
                        <ArrowRightLeft className="w-3.5 h-3.5 text-purple-700" />
                        <span>2. Cadastrar Ida e Volta Juntos (Recomendado)</span>
                      </span>
                    </label>
                  </div>

                  {cadastrarVolta && (
                    <div className="space-y-3">
                      <p className="text-[11px] text-purple-800">
                        O trajeto de volta inverterá automaticamente origem e destino (
                        <strong>{formDestino || 'Destino'}</strong> &rarr; <strong>{formOrigem || 'Origem'}</strong>
                        ).
                      </p>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1">Transporte Volta</label>
                          <select
                            value={voltaMeioTransporte}
                            onChange={(e) => setVoltaMeioTransporte(e.target.value as MeioTransporte)}
                            className="w-full px-2.5 py-1.5 bg-white border border-purple-200 rounded-xl text-xs outline-none font-semibold"
                          >
                            <option value="ONIBUS">🚌 Ônibus</option>
                            <option value="AVIAO">✈️ Avião</option>
                            <option value="CARRO">🚗 Carro</option>
                            <option value="BARCO">🚢 Barco</option>
                            <option value="TREM">🚆 Trem</option>
                            <option value="VAN">🚐 Van</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1">Data Saída Volta</label>
                          <input
                            type="date"
                            required={cadastrarVolta}
                            value={voltaDataSaida}
                            onChange={(e) => setVoltaDataSaida(e.target.value)}
                            className="w-full px-2.5 py-1.5 bg-white border border-purple-200 rounded-xl text-xs outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1">Horário Volta</label>
                          <input
                            type="time"
                            value={voltaHorarioSaida}
                            onChange={(e) => setVoltaHorarioSaida(e.target.value)}
                            className="w-full px-2.5 py-1.5 bg-white border border-purple-200 rounded-xl text-xs outline-none"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <input
                          type="text"
                          value={voltaEmpresa}
                          onChange={(e) => setVoltaEmpresa(e.target.value)}
                          placeholder="Empresa da volta (se diferente)"
                          className="w-full px-3 py-2 bg-white border border-purple-200 rounded-xl text-xs outline-none"
                        />
                        <input
                          type="text"
                          value={voltaNumeroLocalizador}
                          onChange={(e) => setVoltaNumeroLocalizador(e.target.value)}
                          placeholder="Código / Localizador da volta"
                          className="w-full px-3 py-2 bg-white border border-purple-200 rounded-xl text-xs outline-none"
                        />
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Status e Observações */}
              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Status da Viagem
                  </label>
                  <select
                    value={formStatus}
                    onChange={(e) => setFormStatus(e.target.value as ViagemStatus)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="PLANEJADA">PLANEJADA (Padrão inicial)</option>
                    <option value="EM_ANDAMENTO">EM ANDAMENTO</option>
                    <option value="CONCLUÍDA">CONCLUÍDA</option>
                    <option value="CANCELADA">CANCELADA</option>
                  </select>
                  <p className="text-[11px] text-slate-500 mt-1">
                    * O sistema também calcula e atualiza o status automaticamente conforme as horas e datas cadastradas!
                  </p>
                </div>

                <div>
                  <textarea
                    rows={2}
                    value={formObservacoes}
                    onChange={(e) => setFormObservacoes(e.target.value)}
                    placeholder="Observações adicionais, poltrona, conexões..."
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:ring-2 focus:ring-emerald-500"
                  ></textarea>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-sm font-semibold rounded-xl transition shadow-sm disabled:opacity-50"
                >
                  {isSubmitting ? 'Salvando...' : editingViagem ? 'Salvar Alterações' : cadastrarVolta ? 'Cadastrar Ida e Volta' : 'Cadastrar Viagem'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <ConfirmModal
        isOpen={!!deletingId}
        title="Excluir Viagem"
        message={`Tem certeza que deseja excluir esta viagem: "${deletingTitle}"?`}
        confirmLabel="Sim, excluir"
        isDestructive={true}
        isLoading={isDeleting}
        onConfirm={handleDelete}
        onCancel={() => setDeletingId(null)}
      />

      {/* WhatsApp Share & Travel Pass Modal (Feature 6) */}
      <ViagemShareModal
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
        viagem={shareViagem}
      />
    </div>
  );
};
