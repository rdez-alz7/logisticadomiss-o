# LOG MMS — configuração do MongoDB Atlas

## Correção incluída

O adaptador de banco foi ajustado para:
- aguardar a confirmação das gravações no MongoDB antes de responder sucesso;
- persistir atualizações usando o registro atualizado completo;
- carregar dados remotos mesmo quando a coleção `users` estiver vazia, desde que outras coleções tenham dados;
- inicializar o Atlas com os dados iniciais quando o banco remoto estiver vazio;
- falhar claramente na inicialização se `MONGODB_URL` estiver configurada mas a conexão falhar, em vez de aparentar que o MongoDB está funcionando enquanto usa o arquivo local;
- mostrar no status do sistema quando estiver usando o arquivo JSON local, que não é um banco compartilhado e pode não sobreviver a reinícios de ambientes hospedados.

## Configurar localmente

1. Crie um arquivo `.env` na raiz do projeto, ao lado de `package.json`. Você pode copiar `.env.example` e renomeá-lo para `.env`.
2. No MongoDB Atlas, abra seu cluster e escolha **Conectar → Drivers**. Copie a URI de conexão fornecida pelo Atlas.
3. Coloque a URI em `MONGODB_URL` no arquivo `.env`. Substitua o marcador de senha pela senha do usuário do banco. Se a senha contiver caracteres reservados na URI (por exemplo `@`, `:` ou `/`), faça URL-encode desses caracteres.
4. Defina `MONGODB_DATABASE=log_mms`.
5. Defina `JWT_SECRET` com um segredo longo e aleatório.
6. Defina `INITIAL_ADMIN_EMAIL` e `INITIAL_ADMIN_PASSWORD` para credenciais fortes que você controla.
7. No Atlas, em **Acesso à rede / Network Access**, autorize o IP do ambiente onde o servidor vai rodar. Para produção, prefira autorizar o IP de saída do provedor de hospedagem, se disponível. Evite `0.0.0.0/0` salvo como teste temporário e compreendendo o risco.
8. Instale as dependências e inicie:
   - `npm install`
   - `npm run dev`

Se `MONGODB_URL` estiver configurada e inválida ou o Atlas bloquear a conexão, o servidor agora exibirá erro e não iniciará usando silenciosamente o JSON local.

## Publicar

Este projeto tem servidor Node.js/Express (`server.ts`) e frontend Vite. O Netlify, sozinho, não executa este servidor Express persistente como um processo Node tradicional. Para manter a estrutura atual, hospede o projeto inteiro em um serviço compatível com Node.js (por exemplo Render) com:

- Build command: `npm install && npm run build`
- Start command: `npm start`
- Variáveis de ambiente: `MONGODB_URL`, `MONGODB_DATABASE`, `JWT_SECRET`, `INITIAL_ADMIN_NAME`, `INITIAL_ADMIN_USERNAME`, `INITIAL_ADMIN_EMAIL`, `INITIAL_ADMIN_PASSWORD` e, se necessário, `GEMINI_API_KEY`.

Não comite nem envie o arquivo `.env`. Configure os valores secretos no painel de variáveis de ambiente do provedor de hospedagem.

## Verificação depois de conectar

1. Inicie o servidor e confira os logs: deve aparecer uma mensagem de conexão com MongoDB Atlas.
2. Entre no LOG MMS e crie um registro de teste.
3. No Atlas, abra **Database → Browse Collections** e confira se o registro apareceu na coleção correspondente.
4. Reinicie o servidor e confira se o registro continua lá.

Observação: esta correção melhora a persistência do backend, mas ainda precisa ser testada com sua URI e configuração real do Atlas. Não coloque sua URI com senha em mensagens ou no código do frontend.
