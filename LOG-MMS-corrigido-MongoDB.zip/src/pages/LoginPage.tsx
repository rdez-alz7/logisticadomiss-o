import React, { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { LogIn, AlertCircle, Lock, User as UserIcon, Shield, Sparkles } from 'lucide-react';
import { api } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import { BRAND_ASSETS } from '../lib/branding';
import { PWAInstallButton } from '../components/PWAInstallButton';

export const LoginPage: React.FC = () => {
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const { login } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  const isExpired = searchParams.get('expired') === '1';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!identifier.trim() || !password) {
      setError('Por favor preencha todos os campos.');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const response = await api.post('/auth/login', {
        username: identifier.trim(),
        password,
      });

      const { token, user } = response.data;
      login(token, user);
      navigate('/dashboard', { replace: true });
    } catch (err: any) {
      setError(
        err.response?.data?.message || 'Falha na autenticação. Verifique os dados e tente novamente.'
      );
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#121e15] via-[#1a2c1f] to-[#0f1711] flex flex-col justify-center items-center p-4 relative antialiased selection:bg-[#3d5d45] selection:text-white">
      {/* PWA Button */}
      <div className="absolute top-4 right-4 z-10">
        <PWAInstallButton compact />
      </div>

      {/* Main Card Container */}
      <div className="w-full max-w-lg bg-[#ffffff] rounded-3xl shadow-2xl border border-[#2d4633]/30 overflow-hidden">
        {/* Cover Image Showcase */}
        <div className="relative bg-[#26402e] text-white overflow-hidden border-b border-[#3b5943]/40">
          <div className="relative h-56 sm:h-64 w-full flex items-center justify-center overflow-hidden bg-[#243b2c]">
            <img
              src={BRAND_ASSETS.coverImage}
              alt="Mission Movement Capa"
              className="w-full h-full object-cover object-center filter brightness-95 contrast-105"
            />
            {/* Subtle tactical gradient overlays */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#1b2f22] via-transparent to-black/20" />
            <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between text-xs">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-[#142318]/85 backdrop-blur-md border border-[#3b5a44]/60 text-[#d7e5d8] font-bold uppercase tracking-wider text-[11px]">
                <Sparkles className="w-3.5 h-3.5 text-[#a8cca9]" />
                <span>Mission Movement</span>
              </span>
              <span className="text-[11px] font-semibold text-[#c7d9c9] bg-[#142318]/80 backdrop-blur-md px-2.5 py-1 rounded-lg border border-[#3b5a44]/40">
                Logística Missionária &amp; Gestão
              </span>
            </div>
          </div>
        </div>

        {/* Form Body */}
        <div className="p-6 sm:p-8 bg-[#ffffff]">
          <div className="mb-6 text-center">
            <h2 className="text-xl font-black text-[#19271c] tracking-tight">
              Acesso ao Sistema LOG MMS
            </h2>
            <p className="text-xs text-[#526655] mt-1">
              Plataforma unificada para rastreio de alunos, passagens e viagens missionárias.
            </p>
          </div>

          {isExpired && !error && (
            <div className="mb-5 p-3.5 bg-amber-50 border border-amber-300 rounded-2xl text-amber-900 text-xs flex items-center gap-2.5">
              <AlertCircle className="w-4 h-4 flex-shrink-0 text-amber-700" />
              <span>Sua sessão expirou por segurança. Faça login novamente.</span>
            </div>
          )}

          {error && (
            <div className="mb-5 p-3.5 bg-rose-50 border border-rose-300 rounded-2xl text-rose-900 text-xs flex items-center gap-2.5">
              <AlertCircle className="w-4 h-4 flex-shrink-0 text-rose-700" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-[#273a2b] uppercase tracking-wider mb-1.5">
                E-mail ou Usuário
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#5e7762]">
                  <UserIcon className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  required
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder="vitor ou seu@email.com"
                  className="w-full pl-10 pr-4 py-2.5 bg-[#f4f7f3] border border-[#cfdad0] rounded-xl text-sm text-[#18261b] placeholder-[#798e7d] focus:outline-none focus:ring-2 focus:ring-[#385840] focus:bg-white transition"
                  disabled={isLoading}
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#273a2b] uppercase tracking-wider mb-1.5">
                Senha de Acesso
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#5e7762]">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-4 py-2.5 bg-[#f4f7f3] border border-[#cfdad0] rounded-xl text-sm text-[#18261b] placeholder-[#798e7d] focus:outline-none focus:ring-2 focus:ring-[#385840] focus:bg-white transition"
                  disabled={isLoading}
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full mt-2 py-3 px-4 bg-[#26402e] hover:bg-[#32523b] active:scale-[0.99] text-white font-bold rounded-xl transition shadow-lg shadow-[#1b2d20]/30 flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
            >
              {isLoading ? (
                <>
                  <svg className="animate-spin h-5 w-5 text-white" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
                  </svg>
                  <span>Autenticando...</span>
                </>
              ) : (
                <>
                  <LogIn className="w-4 h-4 text-[#b9dab9]" />
                  <span>Entrar no Sistema</span>
                </>
              )}
            </button>
          </form>

          {/* Quick Demo Access Helpers */}
          <div className="mt-6 pt-5 border-t border-[#e2eae0]">
            <p className="text-[11px] font-bold text-[#4e6451] uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5 text-[#3b5943]" />
              <span>Acesso Rápido de Teste:</span>
            </p>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                type="button"
                onClick={() => {
                  setIdentifier('vitor');
                  setPassword('admin123');
                }}
                className="p-2 rounded-xl bg-[#edf3ed] hover:bg-[#dfeadf] border border-[#cbdbcc] text-[#203324] font-medium text-left transition"
              >
                <div className="font-bold">vitor</div>
                <div className="text-[10px] text-[#556e58]">Senha: admin123 (Host)</div>
              </button>
              <button
                type="button"
                onClick={() => {
                  setIdentifier('obreiro');
                  setPassword('obreiro123');
                }}
                className="p-2 rounded-xl bg-[#edf3ed] hover:bg-[#dfeadf] border border-[#cbdbcc] text-[#203324] font-medium text-left transition"
              >
                <div className="font-bold">obreiro</div>
                <div className="text-[10px] text-[#556e58]">Senha: obreiro123 (Gestor)</div>
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-[#f2f6f1] border-t border-[#dce6dc] text-center text-[11px] text-[#5c725f]">
          Mission Movement © 2026 • LOG MMS
        </div>
      </div>
    </div>
  );
};
