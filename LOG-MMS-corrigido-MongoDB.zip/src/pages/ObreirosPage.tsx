import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  UserCircle,
  Users,
  Search,
  Mail,
  Briefcase,
  Plus,
  CheckCircle,
  AlertCircle,
  ChevronRight,
  UserCheck,
  Upload,
  FileText,
  Edit2,
  Trash2,
  X,
  Sparkles,
  CheckSquare,
  Square,
} from 'lucide-react';
import { api } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import { Obreiro, Aluno, PassagemStatus } from '../types';
import { ConfirmModal } from '../components/ConfirmModal';
import { saveLocalSnapshot } from '../lib/sync';
import { BRAND_ASSETS } from '../lib/branding';

interface ObreiroCardData {
  obreiro: Obreiro;
  alunos: Array<{
    id: string;
    nome: string;
    status: string;
    passagemStatus?: PassagemStatus;
  }>;
  totalAlunos: number;
  totalComprados: number;
  totalPendentes: number;
}

export const ObreirosPage: React.FC = () => {
  const { hasRole } = useAuth();
  const canEdit = hasRole('ADMIN_HOST', 'ADMIN', 'GESTOR');
  const canDelete = hasRole('ADMIN_HOST', 'ADMIN');

  const [obreiros, setObreiros] = useState<Obreiro[]>([]);
  const [dashboardData, setDashboardData] = useState<any>(null);
  const [alunos, setAlunos] = useState<Aluno[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedObreiroId, setSelectedObreiroId] = useState<string | null>(null);

  // New Obreiro modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formNome, setFormNome] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formFuncao, setFormFuncao] = useState('Obreiro');
  const [formStatus, setFormStatus] = useState<'ATIVO' | 'INATIVO'>('ATIVO');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Edit Obreiro modal
  const [editingObreiro, setEditingObreiro] = useState<Obreiro | null>(null);
  const [editNome, setEditNome] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [editFuncao, setEditFuncao] = useState('Obreiro');
  const [editStatus, setEditStatus] = useState<'ATIVO' | 'INATIVO'>('ATIVO');
  const [isEditing, setIsEditing] = useState(false);

  // Import Document / List Modal State
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [importText, setImportText] = useState('');
  const [importFuncao, setImportFuncao] = useState('Obreiro');
  const [isImporting, setIsImporting] = useState(false);
  const [importError, setImportError] = useState<string | null>(null);

  // Delete State
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [deletingName, setDeletingName] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);

  // Batch Operations State (Ações em Lote para Obreiros)
  const [selectedObreiroIds, setSelectedObreiroIds] = useState<string[]>([]);
  const [isBatchLoading, setIsBatchLoading] = useState(false);
  const [isBatchDeleteModalOpen, setIsBatchDeleteModalOpen] = useState(false);

  // Toast
  const [toastMessage, setToastMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const showToast = (type: 'success' | 'error', text: string) => {
    setToastMessage({ type, text });
    setTimeout(() => setToastMessage(null), 4000);
  };

  const fetchData = async () => {
    setIsLoading(true);
    try {
      const [obrRes, dashRes, alnRes] = await Promise.all([
        api.get('/obreiros'),
        api.get('/dashboard'),
        api.get('/alunos'),
      ]);
      setObreiros(obrRes.data);
      saveLocalSnapshot('obreiros', obrRes.data);
      setDashboardData(dashRes.data);
      setAlunos(alnRes.data);
      if (obrRes.data.length > 0 && !selectedObreiroId) {
        setSelectedObreiroId(obrRes.data[0].id);
      }
    } catch (err) {
      showToast('error', 'Erro ao carregar dados dos obreiros.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSaveObreiro = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formNome.trim()) return;

    setIsSubmitting(true);
    try {
      await api.post('/obreiros', {
        nome: formNome.trim(),
        email: formEmail.trim(),
        funcao: formFuncao.trim(),
        status: formStatus,
      });
      showToast('success', 'Obreiro cadastrado com sucesso.');
      setIsModalOpen(false);
      setFormNome('');
      setFormEmail('');
      setFormFuncao('Obreiro');
      fetchData();
    } catch (err: any) {
      showToast('error', err.response?.data?.message || 'Erro ao cadastrar obreiro.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleOpenEdit = (obr: Obreiro) => {
    setEditingObreiro(obr);
    setEditNome(obr.nome);
    setEditEmail(obr.email || '');
    setEditFuncao(obr.funcao);
    setEditStatus(obr.status);
    setIsEditing(true);
  };

  const handleUpdateObreiro = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingObreiro || !editNome.trim()) return;

    setIsSubmitting(true);
    try {
      await api.put(`/obreiros/${editingObreiro.id}`, {
        nome: editNome.trim(),
        email: editEmail.trim(),
        funcao: editFuncao.trim(),
        status: editStatus,
      });
      showToast('success', 'Dados do obreiro atualizados com sucesso.');
      setIsEditing(false);
      setEditingObreiro(null);
      fetchData();
    } catch (err: any) {
      showToast('error', err.response?.data?.message || 'Erro ao atualizar obreiro.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteObreiro = async () => {
    if (!deletingId) return;
    setIsDeleting(true);
    try {
      await api.delete(`/obreiros/${deletingId}?forceUnlink=true`);
      showToast('success', 'Obreiro excluído com sucesso.');
      if (selectedObreiroId === deletingId) {
        setSelectedObreiroId(null);
      }
      setDeletingId(null);
      fetchData();
    } catch (err: any) {
      showToast('error', err.response?.data?.message || 'Erro ao excluir obreiro.');
    } finally {
      setIsDeleting(false);
    }
  };

  // Batch Handlers for Obreiros
  const handleToggleSelectObreiro = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setSelectedObreiroIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleSelectAllObreiros = () => {
    if (selectedObreiroIds.length === filteredObreiros.length && filteredObreiros.length > 0) {
      setSelectedObreiroIds([]);
    } else {
      setSelectedObreiroIds(filteredObreiros.map((item) => item.obreiro.id));
    }
  };

  const executeBatchDeleteObreiros = async () => {
    if (selectedObreiroIds.length === 0) return;
    setIsBatchLoading(true);
    try {
      const res = await api.post('/obreiros/batch', {
        action: 'DELETE',
        obreiroIds: selectedObreiroIds,
        forceUnlinkAlunos: true,
      });
      showToast(
        'success',
        res.data?.message || `${selectedObreiroIds.length} obreiro(s) excluído(s) com sucesso.`
      );
      if (selectedObreiroId && selectedObreiroIds.includes(selectedObreiroId)) {
        setSelectedObreiroId(null);
      }
      setSelectedObreiroIds([]);
      setIsBatchDeleteModalOpen(false);
      await fetchData();
    } catch (err: any) {
      showToast('error', err.response?.data?.message || 'Erro ao excluir obreiros em lote.');
    } finally {
      setIsBatchLoading(false);
    }
  };

  // Import Document / List handler
  const handleImportDocument = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!importText.trim()) {
      setImportError('Cole a lista ou envie um documento de texto com os nomes dos obreiros.');
      return;
    }

    setIsImporting(true);
    setImportError(null);
    try {
      const res = await api.post('/obreiros/import-document', {
        text: importText,
        defaultFuncao: importFuncao.trim() || 'Obreiro',
      });
      showToast('success', res.data.message || 'Obreiros importados com sucesso!');
      setIsImportModalOpen(false);
      setImportText('');
      fetchData();
    } catch (err: any) {
      setImportError(err.response?.data?.message || 'Erro ao importar obreiros do documento.');
    } finally {
      setIsImporting(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        setImportText(content);
      }
    };
    reader.readAsText(file);
  };

  // Build card data map
  const obreirosWithAlunos: ObreiroCardData[] = obreiros.map((obr) => {
    const dashAlunos = dashboardData?.alunosStatusList || [];
    const assignedAlunos = dashAlunos.filter(
      (a: any) =>
        (a.obreiroIds && a.obreiroIds.includes(obr.id)) ||
        (a.obreiroNome && a.obreiroNome.includes(obr.nome))
    );

    const totalComprados = assignedAlunos.filter((a: any) => a.passagemStatus === 'COMPRADO').length;
    const totalPendentes = assignedAlunos.length - totalComprados;

    return {
      obreiro: obr,
      alunos: assignedAlunos,
      totalAlunos: assignedAlunos.length,
      totalComprados,
      totalPendentes,
    };
  });

  const filteredObreiros = obreirosWithAlunos.filter(
    (item) =>
      item.obreiro.nome.toLowerCase().includes(search.toLowerCase()) ||
      item.obreiro.funcao.toLowerCase().includes(search.toLowerCase()) ||
      item.alunos.some((a) => a.nome.toLowerCase().includes(search.toLowerCase()))
  );

  const activeObreiro =
    obreirosWithAlunos.find((o) => o.obreiro.id === selectedObreiroId) || obreirosWithAlunos[0];

  return (
    <div className="space-y-6">
      {/* Toast Alert */}
      {toastMessage && (
        <div
          className={`fixed top-4 right-4 z-50 flex items-center gap-2 px-4 py-3 rounded-xl shadow-lg text-sm font-semibold transition ${
            toastMessage.type === 'success' ? 'bg-emerald-700 text-white' : 'bg-rose-700 text-white'
          }`}
        >
          {toastMessage.type === 'success' ? (
            <CheckCircle className="w-5 h-5 flex-shrink-0" />
          ) : (
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
          )}
          <span>{toastMessage.text}</span>
        </div>
      )}

      {/* Header with Military Green Theme & Cover Touch */}
      <div className="rounded-2xl bg-gradient-to-r from-[#213827] via-[#2a4632] to-[#1c3022] p-5 sm:p-6 text-white border border-[#3b5943] shadow-md flex flex-col md:flex-row md:items-center justify-between gap-4 relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-72 opacity-25 pointer-events-none hidden md:block">
          <img
            src={BRAND_ASSETS.coverImage}
            alt="Mission Movement"
            className="w-full h-full object-cover object-center"
          />
        </div>
        <div className="relative z-10">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-[#132218]/80 text-[#cae2cd] text-[10px] font-bold uppercase tracking-wider mb-2 border border-[#3b5d44]">
            <Sparkles className="w-3 h-3 text-[#9cc79f]" />
            <span>Mission Movement • Liderança &amp; Tutoria</span>
          </div>
          <h1 className="text-2xl font-black text-white tracking-tight flex items-center gap-2.5">
            <UserCircle className="w-6 h-6 text-[#9cc79f]" />
            <span>Obreiros e Responsabilidades</span>
          </h1>
          <p className="text-xs sm:text-sm text-[#c7dcc9] mt-0.5 max-w-xl">
            Acompanhe o número e a situação de cada aluno sob tutela de seus respectivos obreiros e líderes missionários.
          </p>
        </div>

        {canEdit && (
          <div className="flex flex-wrap items-center gap-2.5 relative z-10">
            {/* Auto Import from Document/List button */}
            <button
              onClick={() => {
                setImportText('');
                setImportError(null);
                setImportFuncao('Obreiro');
                setIsImportModalOpen(true);
              }}
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#17271c] hover:bg-[#111e15] text-[#d6e7d8] font-bold rounded-xl text-xs transition border border-[#3c5d45] shadow-xs active:scale-95 cursor-pointer"
            >
              <Upload className="w-3.5 h-3.5 text-[#9cc79f]" />
              <span>Ler Documento / Lista</span>
            </button>

            {/* New Obreiro button */}
            <button
              onClick={() => {
                setFormNome('');
                setFormEmail('');
                setFormFuncao('Obreiro');
                setFormStatus('ATIVO');
                setIsModalOpen(true);
              }}
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#ffffff] hover:bg-[#edf5ee] text-[#1b2c1f] font-bold rounded-xl text-xs transition shadow-md active:scale-95 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5 text-[#2b4b34]" />
              <span>+ Novo Obreiro</span>
            </button>
          </div>
        )}
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5 pointer-events-none" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Buscar obreiro por nome, função ou aluno vinculado..."
          className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 transition shadow-2xs"
        />
      </div>

      {/* Main Grid: Left List + Right Detail */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Obreiros List */}
        <div className="lg:col-span-5 space-y-3">
          <div className="flex items-center justify-between px-1">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Lista de Obreiros ({filteredObreiros.length})
            </h2>
            {filteredObreiros.length > 0 && (
              <button
                type="button"
                onClick={handleSelectAllObreiros}
                className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 flex items-center gap-1.5 transition px-2 py-1 rounded-lg hover:bg-emerald-50"
              >
                {selectedObreiroIds.length > 0 && selectedObreiroIds.length === filteredObreiros.length ? (
                  <>
                    <CheckSquare className="w-3.5 h-3.5" />
                    <span>Desmarcar todos</span>
                  </>
                ) : (
                  <>
                    <Square className="w-3.5 h-3.5 text-slate-400" />
                    <span>Selecionar todos ({filteredObreiros.length})</span>
                  </>
                )}
              </button>
            )}
          </div>

          {isLoading ? (
            <div className="space-y-3">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-24 bg-white rounded-2xl border border-slate-200 animate-pulse"></div>
              ))}
            </div>
          ) : filteredObreiros.length === 0 ? (
            <div className="p-8 text-center bg-white rounded-2xl border border-slate-200 text-slate-400 text-sm">
              Nenhum obreiro encontrado.
            </div>
          ) : (
            filteredObreiros.map((item) => {
              const isActive = activeObreiro?.obreiro.id === item.obreiro.id;
              const isSelectedInBatch = selectedObreiroIds.includes(item.obreiro.id);
              return (
                <div
                  key={item.obreiro.id}
                  onClick={() => setSelectedObreiroId(item.obreiro.id)}
                  className={`p-4 rounded-2xl border cursor-pointer transition flex items-center justify-between gap-3 ${
                    isSelectedInBatch
                      ? 'bg-emerald-50/70 border-emerald-500 shadow-sm ring-2 ring-emerald-500/50'
                      : isActive
                      ? 'bg-emerald-50/40 border-emerald-500 shadow-xs'
                      : 'bg-white border-slate-200/80 hover:border-emerald-300 hover:shadow-xs'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    {/* Multi-selection Checkbox */}
                    <button
                      type="button"
                      onClick={(e) => handleToggleSelectObreiro(item.obreiro.id, e)}
                      title={isSelectedInBatch ? 'Desmarcar obreiro' : 'Selecionar obreiro'}
                      className="text-slate-400 hover:text-emerald-700 transition flex items-center justify-center p-1 rounded-lg hover:bg-slate-100 flex-shrink-0"
                    >
                      {isSelectedInBatch ? (
                        <CheckSquare className="w-4 h-4 text-emerald-700" />
                      ) : (
                        <Square className="w-4 h-4 text-slate-300 hover:text-slate-500" />
                      )}
                    </button>

                    <div
                      className={`w-11 h-11 rounded-xl flex items-center justify-center font-bold text-base flex-shrink-0 ${
                        isActive || isSelectedInBatch
                          ? 'bg-emerald-700 text-white'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {item.obreiro.nome.charAt(0)}
                    </div>
                    <div className="min-w-0">
                      <h3 className="font-bold text-slate-900 truncate text-sm">
                        {item.obreiro.nome}
                      </h3>
                      <p className="text-xs text-slate-500 truncate flex items-center gap-1.5 mt-0.5">
                        <Briefcase className="w-3 h-3 text-slate-400 flex-shrink-0" />
                        <span>{item.obreiro.funcao}</span>
                      </p>
                    </div>
                  </div>

                  {/* Badges / Count */}
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <div className="text-right">
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-100/70 text-emerald-900 font-black text-xs">
                        <Users className="w-3 h-3" />
                        <span>{item.totalAlunos}</span>
                      </span>
                      <span className="block text-[10px] text-slate-400 mt-0.5">
                        {item.totalAlunos === 1 ? 'aluno' : 'alunos'}
                      </span>
                    </div>
                    <ChevronRight className={`w-4 h-4 ${isActive ? 'text-emerald-700' : 'text-slate-300'}`} />
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Right: Selected Obreiro Details and Students */}
        <div className="lg:col-span-7">
          {activeObreiro ? (
            <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-xs space-y-6">
              {/* Obreiro Summary Top */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-slate-100 gap-4">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-600 to-emerald-800 text-white flex items-center justify-center text-2xl font-black shadow-xs">
                    {activeObreiro.obreiro.nome.charAt(0)}
                  </div>
                  <div>
                    <h2 className="text-xl font-black text-slate-900">
                      {activeObreiro.obreiro.nome}
                    </h2>
                    <p className="text-xs text-slate-500 flex items-center gap-2 mt-0.5">
                      <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 font-semibold">
                        {activeObreiro.obreiro.funcao}
                      </span>
                      {activeObreiro.obreiro.email && (
                        <span className="flex items-center gap-1 text-slate-400">
                          <Mail className="w-3 h-3" />
                          <span>{activeObreiro.obreiro.email}</span>
                        </span>
                      )}
                    </p>
                  </div>
                </div>

                {/* Progress Indicators & Actions */}
                <div className="flex flex-wrap items-center gap-3">
                  <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-100 text-center min-w-[70px]">
                    <span className="text-[10px] text-slate-400 block font-semibold uppercase">Total</span>
                    <span className="text-base font-black text-slate-900">{activeObreiro.totalAlunos}</span>
                  </div>
                  <div className="p-2.5 bg-emerald-50 rounded-xl border border-emerald-100 text-center min-w-[70px]">
                    <span className="text-[10px] text-emerald-700 block font-semibold uppercase">Comprados</span>
                    <span className="text-base font-black text-emerald-700">{activeObreiro.totalComprados}</span>
                  </div>
                  <div className="p-2.5 bg-amber-50 rounded-xl border border-amber-100 text-center min-w-[70px]">
                    <span className="text-[10px] text-amber-700 block font-semibold uppercase">Pendentes</span>
                    <span className="text-base font-black text-amber-700">{activeObreiro.totalPendentes}</span>
                  </div>

                  {canEdit && (
                    <div className="flex items-center gap-1.5 ml-2">
                      <button
                        onClick={() => handleOpenEdit(activeObreiro.obreiro)}
                        title="Editar Obreiro"
                        className="p-2 text-slate-500 hover:text-emerald-700 hover:bg-emerald-50 rounded-xl border border-slate-200 transition"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      {canDelete && (
                        <button
                          onClick={() => {
                            setDeletingId(activeObreiro.obreiro.id);
                            setDeletingName(activeObreiro.obreiro.nome);
                          }}
                          title="Excluir Obreiro"
                          className="p-2 text-slate-500 hover:text-rose-700 hover:bg-rose-50 rounded-xl border border-slate-200 transition"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* List of responsible students */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <Users className="w-4 h-4 text-emerald-700" />
                    <span>Alunos sob responsabilidade ({activeObreiro.alunos.length})</span>
                  </h3>
                  <Link
                    to="/alunos"
                    className="text-xs text-emerald-700 hover:text-emerald-800 font-semibold"
                  >
                    Gerenciar todos os alunos &rarr;
                  </Link>
                </div>

                {activeObreiro.alunos.length === 0 ? (
                  <div className="p-8 text-center bg-slate-50 rounded-xl border border-dashed border-slate-200 text-slate-400 text-sm">
                    Este obreiro ainda não possui alunos vinculados.
                    <div className="mt-2">
                      <Link
                        to="/alunos"
                        className="text-xs text-emerald-700 hover:underline font-semibold"
                      >
                        Vincular aluno a este obreiro
                      </Link>
                    </div>
                  </div>
                ) : (
                  <div className="divide-y divide-slate-100 border border-slate-200/80 rounded-xl overflow-hidden">
                    {activeObreiro.alunos.map((aluno) => {
                      const pStatus = aluno.passagemStatus || 'NO_PRAZO';

                      const badgeConfig: Record<string, { label: string; sigla: string; bg: string; text: string; border: string }> = {
                        COMPRADO: { label: 'Comprado', sigla: 'C', bg: 'bg-emerald-500', text: 'text-white', border: 'border-emerald-600' },
                        EM_RISCO: { label: 'Em Risco (Faltando 1 Mês)', sigla: 'ER', bg: 'bg-amber-400', text: 'text-slate-950', border: 'border-amber-500' },
                        URGENCIA: { label: 'Urgente (Mês Limite)', sigla: 'U', bg: 'bg-rose-600', text: 'text-white', border: 'border-rose-700' },
                        NO_PRAZO: { label: 'No Prazo', sigla: 'NP', bg: 'bg-blue-500', text: 'text-white', border: 'border-blue-600' },
                      };

                      const currentBadge = badgeConfig[pStatus] || badgeConfig.NO_PRAZO;

                      return (
                        <div
                          key={aluno.id}
                          className="p-3.5 flex items-center justify-between hover:bg-slate-50/70 transition"
                        >
                          <div className="flex items-center gap-3">
                            {/* Status Square */}
                            <span
                              title={`Status da passagem: ${currentBadge.label}`}
                              className={`w-7 h-7 rounded-lg flex items-center justify-center font-black text-xs border shadow-2xs ${currentBadge.bg} ${currentBadge.text} ${currentBadge.border}`}
                            >
                              {currentBadge.sigla}
                            </span>
                            <div>
                              <Link
                                to={`/alunos/${aluno.id}`}
                                className="font-bold text-sm text-slate-900 hover:text-emerald-700 hover:underline block"
                              >
                                {aluno.nome}
                              </Link>
                              <span className="text-[11px] text-slate-500">
                                Passagem: {currentBadge.label}
                              </span>
                            </div>
                          </div>

                          <div className="flex items-center gap-2">
                            <span className="text-xs px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 font-medium">
                              {aluno.status}
                            </span>
                            <Link
                              to={`/alunos/${aluno.id}`}
                              className="text-xs font-semibold text-emerald-700 hover:underline px-2 py-1"
                            >
                              Ver detalhes
                            </Link>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="p-12 text-center bg-white rounded-2xl border border-slate-200 text-slate-400 text-sm">
              Selecione um obreiro à esquerda para ver os detalhes.
            </div>
          )}
        </div>
      </div>

      {/* Modal: Novo Obreiro */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="text-lg font-bold text-slate-900">Novo Obreiro / Responsável</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSaveObreiro} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Nome Completo *
                </label>
                <input
                  type="text"
                  required
                  value={formNome}
                  onChange={(e) => setFormNome(e.target.value)}
                  placeholder="Ex: João da Silva"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:bg-white outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  E-mail
                </label>
                <input
                  type="email"
                  value={formEmail}
                  onChange={(e) => setFormEmail(e.target.value)}
                  placeholder="Ex: joao@mms.org"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:bg-white outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Função / Cargo
                </label>
                <input
                  type="text"
                  value={formFuncao}
                  onChange={(e) => setFormFuncao(e.target.value)}
                  placeholder="Ex: Obreiro, Pastor, Coordenador"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:bg-white outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Status
                </label>
                <select
                  value={formStatus}
                  onChange={(e) => setFormStatus(e.target.value as any)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:bg-white outline-none"
                >
                  <option value="ATIVO">Ativo</option>
                  <option value="INATIVO">Inativo</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-sm text-slate-600 hover:text-slate-800 font-semibold"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-sm font-semibold transition"
                >
                  {isSubmitting ? 'Salvando...' : 'Salvar Obreiro'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Editar Obreiro */}
      {isEditing && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="text-lg font-bold text-slate-900">Editar Obreiro</h3>
              <button onClick={() => setIsEditing(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleUpdateObreiro} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Nome Completo *
                </label>
                <input
                  type="text"
                  required
                  value={editNome}
                  onChange={(e) => setEditNome(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:bg-white outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  E-mail
                </label>
                <input
                  type="email"
                  value={editEmail}
                  onChange={(e) => setEditEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:bg-white outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Função / Cargo
                </label>
                <input
                  type="text"
                  value={editFuncao}
                  onChange={(e) => setEditFuncao(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:bg-white outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Status
                </label>
                <select
                  value={editStatus}
                  onChange={(e) => setEditStatus(e.target.value as any)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:bg-white outline-none"
                >
                  <option value="ATIVO">Ativo</option>
                  <option value="INATIVO">Inativo</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-4 py-2 text-sm text-slate-600 hover:text-slate-800 font-semibold"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-sm font-semibold transition"
                >
                  {isSubmitting ? 'Salvando...' : 'Salvar Alterações'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Ler Documento / Lista de Obreiros */}
      {isImportModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 shadow-2xl space-y-5 border border-slate-200 overflow-hidden">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-slate-900 text-emerald-400">
                  <Upload className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-lg">
                    Ler Documento / Lista de Obreiros
                  </h3>
                  <p className="text-xs text-slate-500">
                    Importação automática a partir de lista colada ou documento de texto.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsImportModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {importError && (
              <div className="p-3.5 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-xl flex items-center gap-2 font-medium">
                <AlertCircle className="w-4 h-4 flex-shrink-0 text-rose-600" />
                <span>{importError}</span>
              </div>
            )}

            <form onSubmit={handleImportDocument} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Função / Cargo Padrão para os Novos Obreiros
                </label>
                <input
                  type="text"
                  value={importFuncao}
                  onChange={(e) => setImportFuncao(e.target.value)}
                  placeholder="Ex: Obreiro, Pastor, Coordenador, Missionário"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:bg-white outline-none"
                />
                <p className="text-[11px] text-slate-500 mt-1">
                  Se a linha contiver a função separada por hífen (ex: <i>João Silva - Pastor</i>), a função da linha terá prioridade.
                </p>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-slate-700 uppercase">
                    Cole os nomes dos obreiros (ou envie o documento)
                  </label>
                  <label className="cursor-pointer inline-flex items-center gap-1.5 text-xs text-emerald-700 hover:text-emerald-800 font-semibold">
                    <FileText className="w-3.5 h-3.5" />
                    <span>Carregar arquivo (.txt, .csv)</span>
                    <input
                      type="file"
                      accept=".txt,.csv,.doc"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </label>
                </div>
                <textarea
                  rows={8}
                  required
                  value={importText}
                  onChange={(e) => setImportText(e.target.value)}
                  placeholder={`Cole aqui os nomes dos obreiros, um por linha. Exemplos aceitos:
1. Pr. Carlos Alberto - Regional
2. Débora Souza - Missionária - debora@mms.org
Lucas Santos - Apoio
Mariana Oliveira
Pr. Fernando Rocha (Coordenador)`}
                  className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono focus:ring-2 focus:ring-emerald-500 focus:bg-white outline-none leading-relaxed"
                />
              </div>

              <div className="p-3 rounded-xl bg-emerald-50/70 border border-emerald-200/80 text-[11px] text-emerald-950 flex items-start gap-2">
                <Sparkles className="w-4 h-4 text-emerald-700 flex-shrink-0 mt-0.5" />
                <span>
                  O sistema reconhece numerações, hífens, pontuações, cargos e e-mails automaticamente, evitando duplicatas com nomes já cadastrados.
                </span>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsImportModalOpen(false)}
                  className="px-4 py-2.5 text-sm text-slate-600 hover:text-slate-800 font-semibold"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isImporting}
                  className="inline-flex items-center gap-2 px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-sm font-semibold transition active:scale-95 disabled:opacity-50"
                >
                  {isImporting ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      <span>Processando Lista...</span>
                    </>
                  ) : (
                    <>
                      <Upload className="w-4 h-4 text-emerald-400" />
                      <span>Processar e Cadastrar Obreiros</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Floating Batch Actions Bar for Obreiros */}
      {selectedObreiroIds.length > 0 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 bg-slate-900 text-white px-5 py-3 rounded-2xl shadow-2xl border border-slate-700 flex items-center gap-4 animate-in slide-in-from-bottom-5 duration-200">
          <div className="flex items-center gap-2.5 pr-3 border-r border-slate-700">
            <span className="w-6 h-6 rounded-lg bg-emerald-600 text-white font-bold text-xs flex items-center justify-center">
              {selectedObreiroIds.length}
            </span>
            <span className="text-xs font-semibold text-slate-200">
              {selectedObreiroIds.length === 1
                ? '1 obreiro selecionado'
                : `${selectedObreiroIds.length} obreiros selecionados`}
            </span>
          </div>

          {canDelete && (
            <button
              type="button"
              disabled={isBatchLoading}
              onClick={() => setIsBatchDeleteModalOpen(true)}
              className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition active:scale-95 shadow-sm disabled:opacity-50"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Excluir selecionados ({selectedObreiroIds.length})</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => setSelectedObreiroIds([])}
            className="text-xs text-slate-400 hover:text-white underline pl-1"
          >
            Desmarcar
          </button>
        </div>
      )}

      {/* Confirm Single Delete Modal */}
      <ConfirmModal
        isOpen={!!deletingId}
        title="Excluir Obreiro"
        message={`Tem certeza que deseja excluir o obreiro "${deletingName}"? Os alunos vinculados serão desvinculados com segurança e continuarão salvos no sistema.`}
        confirmLabel="Sim, excluir"
        cancelLabel="Cancelar"
        isDestructive={true}
        isLoading={isDeleting}
        onConfirm={handleDeleteObreiro}
        onCancel={() => setDeletingId(null)}
      />

      {/* Confirm Batch Delete Modal for Obreiros */}
      <ConfirmModal
        isOpen={isBatchDeleteModalOpen}
        title="Excluir Obreiros em Lote"
        message={`Tem certeza que deseja excluir os ${selectedObreiroIds.length} obreiro(s) selecionados? Os alunos que estiverem sob a responsabilidade deles serão desvinculados com segurança e continuarão salvos no sistema.`}
        confirmLabel={`Sim, excluir ${selectedObreiroIds.length} obreiro(s)`}
        cancelLabel="Cancelar"
        isDestructive={true}
        isLoading={isBatchLoading}
        onConfirm={executeBatchDeleteObreiros}
        onCancel={() => setIsBatchDeleteModalOpen(false)}
      />
    </div>
  );
};
