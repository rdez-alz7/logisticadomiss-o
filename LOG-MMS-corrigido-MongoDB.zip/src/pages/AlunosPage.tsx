import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  UserPlus,
  Search,
  Filter,
  Eye,
  Edit2,
  Trash2,
  AlertCircle,
  CheckCircle,
  X,
  Users,
  Upload,
  FileText,
  UserCheck,
  CheckSquare,
  Square,
  Sparkles,
} from 'lucide-react';
import { api } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import { Aluno, Obreiro, AlunoStatus, PassagemStatus } from '../types';
import { ConfirmModal } from '../components/ConfirmModal';
import { saveLocalSnapshot } from '../lib/sync';
import { BRAND_ASSETS } from '../lib/branding';

export const AlunosPage: React.FC = () => {
  const { hasRole } = useAuth();
  const canEdit = hasRole('ADMIN_HOST', 'ADMIN', 'GESTOR');
  const canDelete = hasRole('ADMIN_HOST', 'ADMIN');

  const [alunos, setAlunos] = useState<Aluno[]>([]);
  const [dashboardStatusMap, setDashboardStatusMap] = useState<Record<string, PassagemStatus>>({});
  const [obreiros, setObreiros] = useState<Obreiro[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedObreiro, setSelectedObreiro] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('');
  const [selectedPassagemStatus, setSelectedPassagemStatus] = useState('');

  // Modal State (Create/Edit)
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingAluno, setEditingAluno] = useState<Aluno | null>(null);
  const [formNome, setFormNome] = useState('');
  const [formObreiroIds, setFormObreiroIds] = useState<string[]>([]);
  const [formStatus, setFormStatus] = useState<AlunoStatus>('ATIVO');
  const [formPassagemStatus, setFormPassagemStatus] = useState<string>('AUTO');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Import Document Modal State
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [importText, setImportText] = useState('');
  const [importDefaultObreiroId, setImportDefaultObreiroId] = useState('');
  const [isImporting, setIsImporting] = useState(false);
  const [importError, setImportError] = useState<string | null>(null);

  // Quick Manual Status Update Modal/Pop
  const [statusAlunoTarget, setStatusAlunoTarget] = useState<Aluno | null>(null);

  // Delete State
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [deletingName, setDeletingName] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);

  // Batch Operations State (Ações em Lote)
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [isBatchLoading, setIsBatchLoading] = useState(false);
  const [isBatchDeleteModalOpen, setIsBatchDeleteModalOpen] = useState(false);
  const [isBatchObreiroModalOpen, setIsBatchObreiroModalOpen] = useState(false);
  const [batchTargetObreiroIds, setBatchTargetObreiroIds] = useState<string[]>([]);
  const [batchActionMenuOpen, setBatchActionMenuOpen] = useState<'passagem' | 'status' | null>(null);

  // Toast
  const [toastMessage, setToastMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const showToast = (type: 'success' | 'error', text: string) => {
    setToastMessage({ type, text });
    setTimeout(() => setToastMessage(null), 4000);
  };

  const fetchObreiros = async () => {
    try {
      const res = await api.get('/obreiros');
      setObreiros(res.data);
      if (res.data.length > 0 && !importDefaultObreiroId) {
        setImportDefaultObreiroId(res.data[0].id);
      }
    } catch (err) {
      console.error('Erro ao carregar obreiros:', err);
    }
  };

  const fetchAlunos = async () => {
    setIsLoading(true);
    try {
      const params: any = {};
      if (search.trim()) params.search = search.trim();
      if (selectedObreiro) params.obreiroId = selectedObreiro;
      if (selectedStatus) params.status = selectedStatus;

      const [alnRes, dashRes] = await Promise.all([
        api.get('/alunos', { params }),
        api.get('/dashboard'),
      ]);

      setAlunos(alnRes.data);
      if (!search.trim() && !selectedObreiro && !selectedStatus) {
        saveLocalSnapshot('alunos', alnRes.data);
      }

      // Map dashboard calculated statuses
      const map: Record<string, PassagemStatus> = {};
      if (dashRes.data?.alunosStatusList) {
        for (const item of dashRes.data.alunosStatusList) {
          map[item.id] = item.passagemStatus;
        }
      }
      setDashboardStatusMap(map);
    } catch (err: any) {
      showToast('error', 'Falha ao buscar lista de alunos.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchObreiros();
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      fetchAlunos();
    }, 250);
    return () => clearTimeout(timer);
  }, [search, selectedObreiro, selectedStatus]);

  const handleOpenCreateModal = () => {
    setEditingAluno(null);
    setFormNome('');
    setFormObreiroIds(obreiros.length > 0 ? [obreiros[0].id] : []);
    setFormStatus('ATIVO');
    setFormPassagemStatus('AUTO');
    setFormError(null);
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (aluno: Aluno) => {
    setEditingAluno(aluno);
    setFormNome(aluno.nome);
    const obIds = aluno.obreiroIds && aluno.obreiroIds.length > 0
      ? aluno.obreiroIds
      : aluno.obreiroId
      ? [aluno.obreiroId]
      : [];
    setFormObreiroIds(obIds);
    setFormStatus(aluno.status);
    setFormPassagemStatus(aluno.passagemStatusManual || 'AUTO');
    setFormError(null);
    setIsModalOpen(true);
  };

  const toggleObreiroSelection = (obrId: string) => {
    if (formObreiroIds.includes(obrId)) {
      setFormObreiroIds(formObreiroIds.filter((id) => id !== obrId));
    } else {
      setFormObreiroIds([...formObreiroIds, obrId]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formNome.trim()) {
      setFormError('Informe o nome do aluno.');
      return;
    }
    if (formObreiroIds.length === 0) {
      setFormError('Selecione ao menos um obreiro responsável.');
      return;
    }

    setIsSubmitting(true);
    setFormError(null);

    try {
      const manualStatus = formPassagemStatus === 'AUTO' ? undefined : formPassagemStatus;

      if (editingAluno) {
        await api.put(`/alunos/${editingAluno.id}`, {
          nome: formNome.trim(),
          obreiroIds: formObreiroIds,
          status: formStatus,
          passagemStatusManual: manualStatus,
        });
        showToast('success', 'Aluno atualizado com sucesso.');
      } else {
        await api.post('/alunos', {
          nome: formNome.trim(),
          obreiroIds: formObreiroIds,
          status: formStatus,
          passagemStatusManual: manualStatus,
        });
        showToast('success', 'Aluno cadastrado com sucesso.');
      }
      setIsModalOpen(false);
      fetchAlunos();
    } catch (err: any) {
      setFormError(err.response?.data?.message || 'Erro ao salvar aluno.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Quick inline update of passagem status
  const handleQuickUpdateStatus = async (alunoId: string, newStatus: string) => {
    try {
      await api.put(`/alunos/${alunoId}`, {
        passagemStatusManual: newStatus === 'AUTO' ? null : newStatus,
      });
      showToast('success', 'Status de passagem atualizado.');
      setStatusAlunoTarget(null);
      fetchAlunos();
    } catch (err) {
      showToast('error', 'Erro ao atualizar status.');
    }
  };

  // Handle document/list import
  const handleImportDocument = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!importText.trim()) {
      setImportError('Cole o texto ou a lista de alunos do documento.');
      return;
    }

    setIsImporting(true);
    setImportError(null);
    try {
      const res = await api.post('/alunos/import-document', {
        text: importText,
        defaultObreiroId: importDefaultObreiroId,
      });
      showToast('success', res.data.message || 'Alunos importados com sucesso!');
      setIsImportModalOpen(false);
      setImportText('');
      fetchAlunos();
    } catch (err: any) {
      setImportError(err.response?.data?.message || 'Erro ao importar documento.');
    } finally {
      setIsImporting(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        setImportText(content);
      }
    };
    reader.readAsText(file);
  };

  const handleDelete = async () => {
    if (!deletingId) return;
    setIsDeleting(true);
    try {
      await api.delete(`/alunos/${deletingId}`);
      showToast('success', 'Aluno excluído com sucesso.');
      setDeletingId(null);
      fetchAlunos();
    } catch (err: any) {
      showToast('error', err.response?.data?.message || 'Erro ao excluir aluno.');
    } finally {
      setIsDeleting(false);
    }
  };

  // Batch action handlers (Feature 5)
  const handleToggleSelect = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleSelectAll = () => {
    if (selectedIds.length === filteredAlunos.length && filteredAlunos.length > 0) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredAlunos.map((a) => a.id));
    }
  };

  const handleBatchUpdatePassagem = async (status: string) => {
    if (selectedIds.length === 0) return;
    setIsBatchLoading(true);
    try {
      await api.post('/alunos/batch', {
        action: 'UPDATE_PASSAGEM_STATUS',
        alunoIds: selectedIds,
        data: { passagemStatusManual: status === 'AUTO' ? null : status },
      });
      showToast('success', `Status de passagem de ${selectedIds.length} aluno(s) atualizado.`);
      setSelectedIds([]);
      setBatchActionMenuOpen(null);
      fetchAlunos();
    } catch (err: any) {
      showToast('error', err.response?.data?.message || 'Erro ao atualizar alunos em lote.');
    } finally {
      setIsBatchLoading(false);
    }
  };

  const handleBatchAssignObreiros = async () => {
    if (selectedIds.length === 0 || batchTargetObreiroIds.length === 0) {
      showToast('error', 'Selecione ao menos um obreiro.');
      return;
    }
    setIsBatchLoading(true);
    try {
      await api.post('/alunos/batch', {
        action: 'UPDATE_OBREIROS',
        alunoIds: selectedIds,
        data: { obreiroIds: batchTargetObreiroIds },
      });
      showToast('success', `Obreiro(s) atribuído(s) para ${selectedIds.length} aluno(s).`);
      setSelectedIds([]);
      setIsBatchObreiroModalOpen(false);
      setBatchTargetObreiroIds([]);
      fetchAlunos();
    } catch (err: any) {
      showToast('error', err.response?.data?.message || 'Erro ao vincular obreiros em lote.');
    } finally {
      setIsBatchLoading(false);
    }
  };

  const handleBatchUpdateEnrollmentStatus = async (status: AlunoStatus) => {
    if (selectedIds.length === 0) return;
    setIsBatchLoading(true);
    try {
      await api.post('/alunos/batch', {
        action: 'UPDATE_STATUS',
        alunoIds: selectedIds,
        data: { status },
      });
      showToast('success', `Status de matrícula de ${selectedIds.length} aluno(s) alterado para ${status}.`);
      setSelectedIds([]);
      setBatchActionMenuOpen(null);
      fetchAlunos();
    } catch (err: any) {
      showToast('error', err.response?.data?.message || 'Erro ao alterar status em lote.');
    } finally {
      setIsBatchLoading(false);
    }
  };

  const handleBatchDelete = () => {
    if (selectedIds.length === 0) return;
    setIsBatchDeleteModalOpen(true);
  };

  const executeBatchDelete = async () => {
    if (selectedIds.length === 0) return;
    setIsBatchLoading(true);
    try {
      await api.post('/alunos/batch', {
        action: 'DELETE',
        alunoIds: selectedIds,
      });
      showToast('success', `${selectedIds.length} aluno(s) excluído(s) com sucesso.`);
      setSelectedIds([]);
      setIsBatchDeleteModalOpen(false);
      fetchAlunos();
    } catch (err: any) {
      showToast('error', err.response?.data?.message || 'Erro ao excluir alunos em lote.');
    } finally {
      setIsBatchLoading(false);
    }
  };

  const statusColors: Record<AlunoStatus, string> = {
    ATIVO: 'bg-emerald-100 text-emerald-800 border-emerald-300',
    INATIVO: 'bg-slate-100 text-slate-700 border-slate-300',
    CONCLUÍDO: 'bg-blue-100 text-blue-800 border-blue-300',
    SUSPENSO: 'bg-amber-100 text-amber-800 border-amber-300',
  };

  // Passagem Status Quadradinho Config
  const getPassagemSquare = (aluno: Aluno) => {
    const status: PassagemStatus = aluno.passagemStatusManual || dashboardStatusMap[aluno.id] || 'NO_PRAZO';

    switch (status) {
      case 'COMPRADO':
        return {
          sigla: 'C',
          label: 'Comprado',
          className: 'bg-emerald-500 text-white border-emerald-600 ring-emerald-300',
        };
      case 'EM_RISCO':
        return {
          sigla: 'ER',
          label: 'Em Risco (Faltando 1 Mês)',
          className: 'bg-amber-400 text-slate-950 font-black border-amber-500 ring-amber-300',
        };
      case 'URGENCIA':
        return {
          sigla: 'U',
          label: 'Urgente (Mês Limite - Contatar Imediatamente!)',
          className: 'bg-rose-600 text-white border-rose-700 ring-rose-300 animate-pulse',
        };
      case 'NO_PRAZO':
      default:
        return {
          sigla: 'NP',
          label: 'No Prazo',
          className: 'bg-blue-500 text-white border-blue-600 ring-blue-300',
        };
    }
  };

  const filteredAlunos = alunos.filter((aluno) => {
    if (!selectedPassagemStatus) return true;
    const currentStatus = aluno.passagemStatusManual || dashboardStatusMap[aluno.id] || 'NO_PRAZO';
    return currentStatus === selectedPassagemStatus;
  });

  return (
    <div className="space-y-6">
      {/* Toast alert */}
      {toastMessage && (
        <div
          className={`fixed top-4 right-4 z-50 flex items-center gap-2 px-4 py-3 rounded-xl shadow-lg text-sm font-semibold transition ${
            toastMessage.type === 'success' ? 'bg-emerald-700 text-white' : 'bg-rose-700 text-white'
          }`}
        >
          {toastMessage.type === 'success' ? (
            <CheckCircle className="w-5 h-5 flex-shrink-0" />
          ) : (
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
          )}
          <span>{toastMessage.text}</span>
        </div>
      )}

      {/* Header with Military Theme and Cover Image touch */}
      <div className="rounded-2xl bg-gradient-to-r from-[#213827] via-[#2a4632] to-[#1c3022] p-5 sm:p-6 text-white border border-[#3b5943] shadow-md flex flex-col md:flex-row md:items-center justify-between gap-4 relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-72 opacity-25 pointer-events-none hidden md:block">
          <img
            src={BRAND_ASSETS.coverImage}
            alt="Mission Movement"
            className="w-full h-full object-cover object-center"
          />
        </div>
        <div className="relative z-10">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-[#132218]/80 text-[#cae2cd] text-[10px] font-bold uppercase tracking-wider mb-2 border border-[#3b5d44]">
            <Sparkles className="w-3 h-3 text-[#9cc79f]" />
            <span>Mission Movement • Cadastro de Alunos</span>
          </div>
          <h1 className="text-2xl font-black text-white tracking-tight flex items-center gap-2.5">
            <Users className="w-6 h-6 text-[#9cc79f]" />
            <span>Gestão de Alunos</span>
          </h1>
          <p className="text-xs sm:text-sm text-[#c7dcc9] mt-0.5 max-w-xl">
            Rastreio com status visual de passagens [C, ER, U, NP] e suporte a múltiplos obreiros responsáveis.
          </p>
        </div>

        {canEdit && (
          <div className="flex flex-wrap items-center gap-2.5 relative z-10">
            {/* Auto Import from Document button */}
            <button
              onClick={() => {
                setImportText('');
                setImportError(null);
                setIsImportModalOpen(true);
              }}
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#17271c] hover:bg-[#111e15] text-[#d6e7d8] font-bold rounded-xl text-xs transition border border-[#3c5d45] shadow-xs active:scale-95 cursor-pointer"
            >
              <Upload className="w-3.5 h-3.5 text-[#9cc79f]" />
              <span>Ler Documento / Lista</span>
            </button>

            {/* New Student button */}
            <button
              onClick={handleOpenCreateModal}
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#ffffff] hover:bg-[#edf5ee] text-[#1b2c1f] font-bold rounded-xl text-xs transition shadow-md active:scale-95 cursor-pointer"
            >
              <UserPlus className="w-3.5 h-3.5 text-[#2b4b34]" />
              <span>+ Novo aluno</span>
            </button>
          </div>
        )}
      </div>

      {/* Status Legend Bar */}
      <div className="bg-white p-3.5 rounded-2xl border border-slate-200/80 shadow-2xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <span className="font-bold text-slate-700 flex items-center gap-1.5">
          <Sparkles className="w-4 h-4 text-emerald-600" />
          <span>Legenda dos Status de Passagem:</span>
        </span>

        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="w-5 h-5 rounded-md bg-emerald-500 text-white font-black text-[11px] flex items-center justify-center border border-emerald-600">
              C
            </span>
            <span className="font-medium text-slate-700">Comprado (Verde)</span>
          </div>

          <div className="flex items-center gap-2">
            <span className="w-5 h-5 rounded-md bg-amber-400 text-slate-950 font-black text-[11px] flex items-center justify-center border border-amber-500">
              ER
            </span>
            <span className="font-medium text-slate-700">Em Risco (Amarelo - 1 Mês)</span>
          </div>

          <div className="flex items-center gap-2">
            <span className="w-5 h-5 rounded-md bg-rose-600 text-white font-black text-[11px] flex items-center justify-center border border-rose-700">
              U
            </span>
            <span className="font-medium text-slate-700">Urgência (Vermelho - Mês Limite)</span>
          </div>

          <div className="flex items-center gap-2">
            <span className="w-5 h-5 rounded-md bg-blue-500 text-white font-black text-[11px] flex items-center justify-center border border-blue-600">
              NP
            </span>
            <span className="font-medium text-slate-700">No Prazo (Azul)</span>
          </div>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3 pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Pesquisar aluno pelo nome..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition"
          />
        </div>

        {/* Filters Group */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Status Passagem filter */}
          <select
            value={selectedPassagemStatus}
            onChange={(e) => setSelectedPassagemStatus(e.target.value)}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition"
          >
            <option value="">Status da Passagem (Todos)</option>
            <option value="COMPRADO">Comprado (C)</option>
            <option value="EM_RISCO">Em Risco (ER)</option>
            <option value="URGENCIA">Urgente (U)</option>
            <option value="NO_PRAZO">No Prazo (NP)</option>
          </select>

          {/* Obreiro filter */}
          <select
            value={selectedObreiro}
            onChange={(e) => setSelectedObreiro(e.target.value)}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition"
          >
            <option value="">Todos os obreiros</option>
            {obreiros.map((obr) => (
              <option key={obr.id} value={obr.id}>
                {obr.nome}
              </option>
            ))}
          </select>

          {/* Status filter */}
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition"
          >
            <option value="">Status de Matrícula</option>
            <option value="ATIVO">ATIVO</option>
            <option value="INATIVO">INATIVO</option>
            <option value="CONCLUÍDO">CONCLUÍDO</option>
            <option value="SUSPENSO">SUSPENSO</option>
          </select>

          {(search || selectedObreiro || selectedStatus || selectedPassagemStatus) && (
            <button
              onClick={() => {
                setSearch('');
                setSelectedObreiro('');
                setSelectedStatus('');
                setSelectedPassagemStatus('');
              }}
              className="text-xs text-rose-600 hover:text-rose-800 font-semibold px-2 py-1.5"
            >
              Limpar filtros
            </button>
          )}
        </div>
      </div>

      {/* Main Alunos Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                <th className="py-3.5 pl-6 pr-2 w-10">
                  <button
                    type="button"
                    onClick={handleSelectAll}
                    title={selectedIds.length === filteredAlunos.length && filteredAlunos.length > 0 ? "Desmarcar todos" : "Selecionar todos"}
                    className="text-slate-400 hover:text-emerald-700 transition flex items-center justify-center"
                  >
                    {selectedIds.length > 0 && selectedIds.length === filteredAlunos.length ? (
                      <CheckSquare className="w-4 h-4 text-emerald-700" />
                    ) : selectedIds.length > 0 ? (
                      <div className="w-4 h-4 rounded border-2 border-emerald-700 bg-emerald-100 flex items-center justify-center">
                        <div className="w-2 h-0.5 bg-emerald-800" />
                      </div>
                    ) : (
                      <Square className="w-4 h-4" />
                    )}
                  </button>
                </th>
                <th className="py-3.5 px-4">Aluno e Status da Passagem</th>
                <th className="py-3.5 px-6">Obreiro(s) Responsável(eis)</th>
                <th className="py-3.5 px-6 text-center">Matrícula</th>
                <th className="py-3.5 px-6 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {isLoading ? (
                [...Array(4)].map((_, i) => (
                  <tr key={i} className="animate-pulse">
                    <td className="py-4 pl-6 pr-2"><div className="h-4 bg-slate-200 rounded w-4"></div></td>
                    <td className="py-4 px-4"><div className="h-4 bg-slate-200 rounded-md w-48"></div></td>
                    <td className="py-4 px-6"><div className="h-4 bg-slate-200 rounded-md w-40"></div></td>
                    <td className="py-4 px-6"><div className="h-5 bg-slate-200 rounded-full w-16 mx-auto"></div></td>
                    <td className="py-4 px-6 text-right"><div className="h-8 bg-slate-200 rounded-lg w-20 ml-auto"></div></td>
                  </tr>
                ))
              ) : filteredAlunos.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-12 text-center text-slate-400">
                    <Users className="w-10 h-10 mx-auto text-slate-300 mb-2" />
                    <p className="font-semibold text-slate-700">Nenhum aluno encontrado</p>
                    <p className="text-xs text-slate-500 mt-1">
                      {search || selectedObreiro || selectedStatus || selectedPassagemStatus
                        ? 'Tente ajustar os filtros de busca.'
                        : 'Comece adicionando o primeiro aluno no botão acima ou leia um documento com a lista.'}
                    </p>
                  </td>
                </tr>
              ) : (
                filteredAlunos.map((aluno) => {
                  const square = getPassagemSquare(aluno);
                  const obreirosDisplay = aluno.obreiroNomes && aluno.obreiroNomes.length > 0
                    ? aluno.obreiroNomes.join(', ')
                    : aluno.obreiroNome || 'Não vinculado';
                  const isSelected = selectedIds.includes(aluno.id);

                  return (
                    <tr
                      key={aluno.id}
                      className={`hover:bg-slate-50/60 transition ${
                        isSelected ? 'bg-emerald-50/40' : ''
                      }`}
                    >
                      {/* Checkbox de seleção */}
                      <td className="py-4 pl-6 pr-2">
                        <button
                          type="button"
                          onClick={() => handleToggleSelect(aluno.id)}
                          className="text-slate-400 hover:text-emerald-700 transition flex items-center justify-center"
                        >
                          {isSelected ? (
                            <CheckSquare className="w-4 h-4 text-emerald-700" />
                          ) : (
                            <Square className="w-4 h-4 text-slate-300" />
                          )}
                        </button>
                      </td>

                      {/* Nome + Quadradinho de Passagem */}
                      <td className="py-4 px-4">
                        <div className="flex items-center gap-3">
                          {/* Quadradinho de Status da Passagem */}
                          <div className="relative group">
                            <button
                              type="button"
                              onClick={() => setStatusAlunoTarget(statusAlunoTarget?.id === aluno.id ? null : aluno)}
                              title={`Status da passagem: ${square.label} (Clique para alterar manualmente)`}
                              className={`w-7 h-7 rounded-lg flex items-center justify-center font-black text-xs border shadow-2xs transition active:scale-90 ${square.className}`}
                            >
                              {square.sigla}
                            </button>

                            {/* Dropdown de troca rápida de status */}
                            {statusAlunoTarget?.id === aluno.id && (
                              <div className="absolute left-0 top-9 z-30 w-52 bg-white rounded-xl shadow-xl border border-slate-200 p-2 space-y-1">
                                <p className="text-[10px] font-bold uppercase text-slate-400 px-2 py-1">
                                  Alterar Status da Passagem:
                                </p>
                                <button
                                  onClick={() => handleQuickUpdateStatus(aluno.id, 'COMPRADO')}
                                  className="w-full flex items-center gap-2 px-2 py-1.5 text-xs font-semibold rounded-lg hover:bg-emerald-50 text-emerald-800 text-left"
                                >
                                  <span className="w-5 h-5 rounded-md bg-emerald-500 text-white font-black text-[10px] flex items-center justify-center">C</span>
                                  <span>Comprado</span>
                                </button>
                                <button
                                  onClick={() => handleQuickUpdateStatus(aluno.id, 'EM_RISCO')}
                                  className="w-full flex items-center gap-2 px-2 py-1.5 text-xs font-semibold rounded-lg hover:bg-amber-50 text-amber-900 text-left"
                                >
                                  <span className="w-5 h-5 rounded-md bg-amber-400 text-slate-950 font-black text-[10px] flex items-center justify-center">ER</span>
                                  <span>Em Risco (1 Mês)</span>
                                </button>
                                <button
                                  onClick={() => handleQuickUpdateStatus(aluno.id, 'URGENCIA')}
                                  className="w-full flex items-center gap-2 px-2 py-1.5 text-xs font-semibold rounded-lg hover:bg-rose-50 text-rose-800 text-left"
                                >
                                  <span className="w-5 h-5 rounded-md bg-rose-600 text-white font-black text-[10px] flex items-center justify-center">U</span>
                                  <span>Urgência (Mês Limite)</span>
                                </button>
                                <button
                                  onClick={() => handleQuickUpdateStatus(aluno.id, 'NO_PRAZO')}
                                  className="w-full flex items-center gap-2 px-2 py-1.5 text-xs font-semibold rounded-lg hover:bg-blue-50 text-blue-800 text-left"
                                >
                                  <span className="w-5 h-5 rounded-md bg-blue-500 text-white font-black text-[10px] flex items-center justify-center">NP</span>
                                  <span>No Prazo (Inicial)</span>
                                </button>
                                <button
                                  onClick={() => handleQuickUpdateStatus(aluno.id, 'AUTO')}
                                  className="w-full text-center px-2 py-1 text-[11px] font-semibold text-slate-500 hover:text-slate-800 border-t border-slate-100 mt-1"
                                >
                                  Voltar ao Automático
                                </button>
                              </div>
                            )}
                          </div>

                          <div>
                            <Link
                              to={`/alunos/${aluno.id}`}
                              className="font-bold text-slate-900 hover:text-emerald-700 hover:underline block leading-tight"
                            >
                              {aluno.nome}
                            </Link>
                            <span className="text-[11px] text-slate-400 block mt-0.5">
                              Status: {square.label}
                            </span>
                          </div>
                        </div>
                      </td>

                      {/* Obreiro(s) Responsável(eis) */}
                      <td className="py-4 px-6">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-800 font-bold flex items-center justify-center text-xs flex-shrink-0">
                            {obreirosDisplay.charAt(0)}
                          </div>
                          <span className="font-semibold text-slate-800 text-xs sm:text-sm">
                            {obreirosDisplay}
                          </span>
                        </div>
                      </td>

                      {/* Status Matrícula */}
                      <td className="py-4 px-6 text-center">
                        <span
                          className={`inline-block text-[11px] font-bold px-2.5 py-0.5 rounded-full border tracking-wide uppercase ${
                            statusColors[aluno.status]
                          }`}
                        >
                          {aluno.status}
                        </span>
                      </td>

                      {/* Ações */}
                      <td className="py-4 px-6 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <Link
                            to={`/alunos/${aluno.id}`}
                            title="Visualizar perfil e viagens"
                            className="p-1.5 text-slate-500 hover:text-emerald-700 hover:bg-slate-100 rounded-lg transition"
                          >
                            <Eye className="w-4 h-4" />
                          </Link>

                          {canEdit && (
                            <button
                              onClick={() => handleOpenEditModal(aluno)}
                              title="Editar aluno"
                              className="p-1.5 text-slate-500 hover:text-blue-700 hover:bg-slate-100 rounded-lg transition"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                          )}

                          {canDelete && (
                            <button
                              onClick={() => {
                                setDeletingId(aluno.id);
                                setDeletingName(aluno.nome);
                              }}
                              title="Excluir aluno"
                              className="p-1.5 text-slate-500 hover:text-rose-700 hover:bg-slate-100 rounded-lg transition"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Floating Batch Action Bar (Feature 5) */}
      {selectedIds.length > 0 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 bg-slate-900 text-white px-5 py-3 rounded-2xl shadow-2xl border border-slate-700 flex flex-wrap items-center gap-3 animate-in fade-in slide-in-from-bottom-4 duration-200 max-w-[95vw]">
          <div className="flex items-center gap-2 pr-3 border-r border-slate-700">
            <span className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 font-bold text-xs flex items-center justify-center border border-emerald-500/30">
              {selectedIds.length}
            </span>
            <span className="text-xs font-semibold text-slate-200">
              {selectedIds.length === 1 ? '1 aluno selecionado' : `${selectedIds.length} alunos selecionados`}
            </span>
          </div>

          {/* Batch Passagem Status */}
          <div className="relative">
            <button
              type="button"
              disabled={isBatchLoading}
              onClick={() => setBatchActionMenuOpen(batchActionMenuOpen === 'passagem' ? null : 'passagem')}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs font-semibold rounded-xl border border-slate-700 flex items-center gap-1.5 transition active:scale-95"
            >
              <span>Status Passagem [C, ER, U, NP]</span>
            </button>

            {batchActionMenuOpen === 'passagem' && (
              <div className="absolute bottom-11 left-0 w-56 bg-white text-slate-800 rounded-xl shadow-2xl border border-slate-200 p-2 space-y-1 z-50">
                <p className="text-[10px] font-bold uppercase text-slate-400 px-2 py-1">Aplicar a todos selecionados:</p>
                <button
                  type="button"
                  onClick={() => handleBatchUpdatePassagem('COMPRADO')}
                  className="w-full flex items-center gap-2 px-2 py-1.5 text-xs font-semibold rounded-lg hover:bg-emerald-50 text-emerald-800 text-left"
                >
                  <span className="w-5 h-5 rounded-md bg-emerald-500 text-white font-black text-[10px] flex items-center justify-center">C</span>
                  <span>Comprado</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleBatchUpdatePassagem('EM_RISCO')}
                  className="w-full flex items-center gap-2 px-2 py-1.5 text-xs font-semibold rounded-lg hover:bg-amber-50 text-amber-900 text-left"
                >
                  <span className="w-5 h-5 rounded-md bg-amber-400 text-slate-950 font-black text-[10px] flex items-center justify-center">ER</span>
                  <span>Em Risco (1 Mês)</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleBatchUpdatePassagem('URGENCIA')}
                  className="w-full flex items-center gap-2 px-2 py-1.5 text-xs font-semibold rounded-lg hover:bg-rose-50 text-rose-800 text-left"
                >
                  <span className="w-5 h-5 rounded-md bg-rose-600 text-white font-black text-[10px] flex items-center justify-center">U</span>
                  <span>Urgência (Mês Limite)</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleBatchUpdatePassagem('NO_PRAZO')}
                  className="w-full flex items-center gap-2 px-2 py-1.5 text-xs font-semibold rounded-lg hover:bg-blue-50 text-blue-800 text-left"
                >
                  <span className="w-5 h-5 rounded-md bg-blue-500 text-white font-black text-[10px] flex items-center justify-center">NP</span>
                  <span>No Prazo</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleBatchUpdatePassagem('AUTO')}
                  className="w-full text-center px-2 py-1 text-[11px] font-semibold text-slate-500 hover:text-slate-800 border-t border-slate-100 mt-1"
                >
                  Voltar ao Automático
                </button>
              </div>
            )}
          </div>

          {/* Batch Assign Obreiros */}
          <button
            type="button"
            disabled={isBatchLoading}
            onClick={() => {
              setBatchTargetObreiroIds([]);
              setIsBatchObreiroModalOpen(true);
              setBatchActionMenuOpen(null);
            }}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs font-semibold rounded-xl border border-slate-700 flex items-center gap-1.5 transition active:scale-95"
          >
            <span>Vincular Obreiro(s)</span>
          </button>

          {/* Batch Enrollment Status */}
          <div className="relative">
            <button
              type="button"
              disabled={isBatchLoading}
              onClick={() => setBatchActionMenuOpen(batchActionMenuOpen === 'status' ? null : 'status')}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs font-semibold rounded-xl border border-slate-700 flex items-center gap-1.5 transition active:scale-95"
            >
              <span>Status Matrícula</span>
            </button>

            {batchActionMenuOpen === 'status' && (
              <div className="absolute bottom-11 left-0 w-44 bg-white text-slate-800 rounded-xl shadow-2xl border border-slate-200 p-2 space-y-1 z-50">
                <p className="text-[10px] font-bold uppercase text-slate-400 px-2 py-1">Alterar matrícula:</p>
                {(['ATIVO', 'CONCLUÍDO', 'SUSPENSO', 'INATIVO'] as AlunoStatus[]).map((st) => (
                  <button
                    key={st}
                    type="button"
                    onClick={() => handleBatchUpdateEnrollmentStatus(st)}
                    className="w-full text-left px-2.5 py-1.5 text-xs font-semibold rounded-lg hover:bg-slate-100 transition"
                  >
                    {st}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Batch Delete */}
          {canDelete && (
            <button
              type="button"
              disabled={isBatchLoading}
              onClick={handleBatchDelete}
              className="px-3 py-1.5 bg-rose-600/80 hover:bg-rose-600 text-rose-100 hover:text-white text-xs font-semibold rounded-xl border border-rose-500/40 flex items-center gap-1.5 transition active:scale-95"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Excluir ({selectedIds.length})</span>
            </button>
          )}

          {/* Deselect */}
          <button
            type="button"
            onClick={() => {
              setSelectedIds([]);
              setBatchActionMenuOpen(null);
            }}
            className="text-xs text-slate-400 hover:text-white pl-2 underline"
          >
            Desmarcar
          </button>
        </div>
      )}

      {/* MODAL: VINCULAR OBREIRO(S) EM LOTE */}
      {isBatchObreiroModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl overflow-hidden border border-slate-200">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-slate-900 text-base">
                  Vincular Obreiro(s) em Lote
                </h3>
                <p className="text-xs text-slate-500">
                  Defina o(s) obreiro(s) para os {selectedIds.length} aluno(s) selecionados.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsBatchObreiroModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                {obreiros.map((obr) => {
                  const isChecked = batchTargetObreiroIds.includes(obr.id);
                  return (
                    <label
                      key={obr.id}
                      className={`flex items-center gap-3 p-2.5 rounded-xl border cursor-pointer transition ${
                        isChecked
                          ? 'border-emerald-500 bg-emerald-50/50'
                          : 'border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={() => {
                          setBatchTargetObreiroIds((prev) =>
                            prev.includes(obr.id)
                              ? prev.filter((id) => id !== obr.id)
                              : [...prev, obr.id]
                          );
                        }}
                        className="rounded text-emerald-600 focus:ring-emerald-500"
                      />
                      <div className="min-w-0">
                        <span className="font-bold text-slate-800 text-sm block truncate">{obr.nome}</span>
                        <span className="text-[11px] text-slate-400 block truncate">{obr.funcao}</span>
                      </div>
                    </label>
                  );
                })}
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsBatchObreiroModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  disabled={isBatchLoading || batchTargetObreiroIds.length === 0}
                  onClick={handleBatchAssignObreiros}
                  className="px-5 py-2 text-xs font-bold bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl transition shadow-sm disabled:opacity-50"
                >
                  {isBatchLoading ? 'Salvando...' : 'Aplicar aos Selecionados'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: CRIAR / EDITAR ALUNO (Suporta Múltiplos Obreiros e Status Manual) */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl overflow-hidden border border-slate-200">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-slate-900 text-lg">
                  {editingAluno ? 'Editar Aluno' : 'Cadastrar Novo Aluno'}
                </h3>
                <p className="text-xs text-slate-500">
                  Preencha o nome e selecione um ou mais obreiros responsáveis.
                </p>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {formError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 flex-shrink-0 text-rose-600" />
                  <span>{formError}</span>
                </div>
              )}

              {/* 1. Nome do aluno */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Nome do Aluno <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formNome}
                  onChange={(e) => setFormNome(e.target.value)}
                  placeholder="Nome completo do aluno"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition"
                  autoFocus
                />
              </div>

              {/* 2. Múltiplos Obreiros Responsáveis */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Obreiro(s) Responsável(eis) <span className="text-rose-500">* (Selecione um ou mais)</span>
                </label>
                {obreiros.length === 0 ? (
                  <p className="text-xs text-amber-700 bg-amber-50 p-2.5 rounded-xl border border-amber-200">
                    Nenhum obreiro cadastrado.
                  </p>
                ) : (
                  <div className="max-h-40 overflow-y-auto p-2 bg-slate-50 border border-slate-200 rounded-xl space-y-1.5">
                    {obreiros.map((obr) => {
                      const isSelected = formObreiroIds.includes(obr.id);
                      return (
                        <div
                          key={obr.id}
                          onClick={() => toggleObreiroSelection(obr.id)}
                          className={`flex items-center justify-between p-2 rounded-lg cursor-pointer transition text-xs font-medium ${
                            isSelected
                              ? 'bg-emerald-100/70 text-emerald-900 border border-emerald-300'
                              : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200/60'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            {isSelected ? (
                              <CheckSquare className="w-4 h-4 text-emerald-700 flex-shrink-0" />
                            ) : (
                              <Square className="w-4 h-4 text-slate-400 flex-shrink-0" />
                            )}
                            <span className="font-semibold">{obr.nome}</span>
                          </div>
                          <span className="text-[10px] text-slate-500">{obr.funcao}</span>
                        </div>
                      );
                    })}
                  </div>
                )}
                <span className="text-[11px] text-slate-500 mt-1 block">
                  {formObreiroIds.length} obreiro(s) selecionado(s).
                </span>
              </div>

              {/* 3. Status de Passagem (Manual ou Automático) */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Status da Passagem
                </label>
                <select
                  value={formPassagemStatus}
                  onChange={(e) => setFormPassagemStatus(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="AUTO">Automático (Calculado pelo sistema e data limite)</option>
                  <option value="COMPRADO">Comprado (C - Verde)</option>
                  <option value="EM_RISCO">Em Risco (ER - Amarelo)</option>
                  <option value="URGENCIA">Urgência (U - Vermelho)</option>
                  <option value="NO_PRAZO">No Prazo (NP - Azul)</option>
                </select>
              </div>

              {/* 4. Status Matrícula */}
              {editingAluno && (
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Status da Matrícula
                  </label>
                  <select
                    value={formStatus}
                    onChange={(e) => setFormStatus(e.target.value as AlunoStatus)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition"
                  >
                    <option value="ATIVO">ATIVO</option>
                    <option value="INATIVO">INATIVO</option>
                    <option value="CONCLUÍDO">CONCLUÍDO</option>
                    <option value="SUSPENSO">SUSPENSO</option>
                  </select>
                </div>
              )}

              <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting || obreiros.length === 0}
                  className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-sm font-semibold rounded-xl transition shadow-sm disabled:opacity-50 flex items-center gap-2"
                >
                  {isSubmitting ? 'Salvando...' : editingAluno ? 'Salvar Alterações' : 'Cadastrar Aluno'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: LER DOCUMENTOS E ORGANIZAR LISTA AUTOMATICAMENTE */}
      {isImportModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full shadow-2xl overflow-hidden border border-slate-200">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-slate-900 text-lg flex items-center gap-2">
                  <FileText className="w-5 h-5 text-emerald-700" />
                  <span>Leitor e Organizador de Documentos / Lista</span>
                </h3>
                <p className="text-xs text-slate-500">
                  Carregue um arquivo (.txt/.csv) ou cole a lista. O sistema reconhece nomes e vincula os obreiros automaticamente.
                </p>
              </div>
              <button
                onClick={() => setIsImportModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleImportDocument} className="p-6 space-y-4">
              {importError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 flex-shrink-0 text-rose-600" />
                  <span>{importError}</span>
                </div>
              )}

              {/* File upload shortcut */}
              <div className="p-3 bg-slate-50 rounded-xl border border-dashed border-slate-300 flex items-center justify-between gap-3">
                <span className="text-xs text-slate-600 font-medium">Carregar arquivo com lista:</span>
                <input
                  type="file"
                  accept=".txt,.csv"
                  onChange={handleFileUpload}
                  className="text-xs text-slate-500 file:mr-2 file:py-1 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-emerald-50 file:text-emerald-700 hover:file:bg-emerald-100 cursor-pointer"
                />
              </div>

              {/* Text Area */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Conteúdo do Documento ou Lista (Cole aqui)
                </label>
                <textarea
                  rows={6}
                  value={importText}
                  onChange={(e) => setImportText(e.target.value)}
                  placeholder={`Exemplo de formato suportado:
1. Gabriel Pereira Rocha - João Silva
2. Beatriz Cristina Mendes - Marcos Oliveira
Matheuss Henrique Alves
Larissa Souza Lima - João Silva`}
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono focus:ring-2 focus:ring-emerald-500 focus:bg-white outline-none leading-relaxed"
                ></textarea>
                <p className="text-[11px] text-slate-400 mt-1">
                  Dica: Se a linha tiver "Nome do Aluno - Nome do Obreiro", ele já atribui o obreiro automaticamente!
                </p>
              </div>

              {/* Default Obreiro fallback */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Obreiro Padrão (para nomes que não tiverem obreiro especificado)
                </label>
                <select
                  value={importDefaultObreiroId}
                  onChange={(e) => setImportDefaultObreiroId(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  {obreiros.map((obr) => (
                    <option key={obr.id} value={obr.id}>
                      {obr.nome} ({obr.funcao})
                    </option>
                  ))}
                </select>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsImportModalOpen(false)}
                  className="px-4 py-2 text-sm text-slate-600 font-semibold"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isImporting || !importText.trim()}
                  className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-sm font-semibold transition disabled:opacity-50 flex items-center gap-2"
                >
                  {isImporting ? 'Processando Documento...' : 'Organizar e Cadastrar Alunos'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <ConfirmModal
        isOpen={!!deletingId}
        title="Excluir Aluno"
        message={`Tem certeza que deseja excluir o aluno "${deletingName}"? Esta ação removerá o aluno e suas referências permanentemente.`}
        confirmLabel="Sim, excluir aluno"
        isDestructive={true}
        isLoading={isDeleting}
        onConfirm={handleDelete}
        onCancel={() => setDeletingId(null)}
      />

      {/* Batch Delete Confirmation Modal */}
      <ConfirmModal
        isOpen={isBatchDeleteModalOpen}
        title="Excluir Alunos em Lote"
        message={`Tem certeza que deseja excluir os ${selectedIds.length} aluno(s) selecionados? Esta ação é irreversível e removerá as viagens e documentos associados a estes alunos.`}
        confirmLabel={`Sim, excluir ${selectedIds.length} aluno(s)`}
        isDestructive={true}
        isLoading={isBatchLoading}
        onConfirm={executeBatchDelete}
        onCancel={() => setIsBatchDeleteModalOpen(false)}
      />
    </div>
  );
};
