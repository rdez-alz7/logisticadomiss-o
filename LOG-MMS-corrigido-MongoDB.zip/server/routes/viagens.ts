import { Router, Request, Response } from 'express';
import { db } from '../db/database.js';
import { authenticateToken, requireRoles } from '../services/authService.js';
import { logAudit } from '../services/auditService.js';
import { Viagem, ViagemStatus } from '../types/index.js';

export const viagensRouter = Router();

// Helper function to auto-update viagem status based on current date & time
function computeAutoStatus(v: Viagem): ViagemStatus {
  if (v.status === 'CANCELADA') return 'CANCELADA';

  try {
    const now = new Date();
    const partida = new Date(`${v.dataSaida}T${v.horarioSaida || '00:00'}:00`);
    const chegada = new Date(`${v.dataChegada || v.dataSaida}T${v.horarioChegada || '23:59'}:00`);

    if (now < partida) {
      return 'PLANEJADA';
    } else if (now >= partida && now <= chegada) {
      return 'EM_ANDAMENTO';
    } else if (now > chegada) {
      return 'CONCLUÍDA';
    }
  } catch {}
  return v.status;
}

// GET /api/viagens
viagensRouter.get('/viagens', authenticateToken, async (req: Request, res: Response) => {
  try {
    const { alunoId, status, search, page = '1', limit = '50', sortBy = 'createdAt', sortOrder = 'desc' } = req.query;

    const filter = {
      alunoId: typeof alunoId === 'string' && alunoId ? alunoId : undefined,
      status: typeof status === 'string' && status ? status : undefined,
      search: typeof search === 'string' ? search : undefined,
    };

    let viagens = await db.viagens.find(filter);

    // Auto update status based on current hours
    for (const v of viagens) {
      const computed = computeAutoStatus(v);
      if (computed !== v.status && v.status !== 'CANCELADA') {
        v.status = computed;
        db.viagens.updateOne(v.id, { status: computed }).catch(() => {});
      }
    }

    // Sorting
    viagens.sort((a: any, b: any) => {
      const fieldA = a[sortBy as string] || '';
      const fieldB = b[sortBy as string] || '';
      if (sortOrder === 'asc') {
        return fieldA.localeCompare ? fieldA.localeCompare(fieldB) : fieldA > fieldB ? 1 : -1;
      }
      return fieldB.localeCompare ? fieldB.localeCompare(fieldA) : fieldB > fieldA ? 1 : -1;
    });

    // Pagination
    const pageNum = Math.max(1, parseInt(page as string, 10) || 1);
    const limitNum = Math.max(1, Math.min(100, parseInt(limit as string, 10) || 50));
    const total = viagens.length;
    const startIndex = (pageNum - 1) * limitNum;
    const paginated = viagens.slice(startIndex, startIndex + limitNum);

    res.json({
      items: paginated,
      total,
      page: pageNum,
      limit: limitNum,
      totalPages: Math.ceil(total / limitNum),
    });
  } catch (error: any) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: 'Erro ao buscar viagens.' });
  }
});

// GET /api/viagens/embarques - Painel de Embarques do Dia (Live Board)
viagensRouter.get('/viagens/embarques', authenticateToken, async (_req: Request, res: Response) => {
  try {
    const allViagens = await db.viagens.find();

    // Auto-update status based on current hours
    for (const v of allViagens) {
      const computed = computeAutoStatus(v);
      if (computed !== v.status && v.status !== 'CANCELADA') {
        v.status = computed;
        db.viagens.updateOne(v.id, { status: computed }).catch(() => {});
      }
    }

    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];

    const tomorrow = new Date(now.getTime() + 24 * 60 * 60 * 1000);
    const tomorrowStr = tomorrow.toISOString().split('T')[0];

    const in48h = new Date(now.getTime() + 48 * 60 * 60 * 1000);
    const in48hStr = in48h.toISOString().split('T')[0];

    // Filter categories
    const hoje = allViagens
      .filter((v) => v.dataSaida === todayStr || (v.dataSaida <= todayStr && (v.dataChegada || v.dataSaida) >= todayStr && v.status !== 'CONCLUÍDA'))
      .sort((a, b) => (a.horarioSaida || '').localeCompare(b.horarioSaida || ''));

    const amanha = allViagens
      .filter((v) => v.dataSaida === tomorrowStr)
      .sort((a, b) => (a.horarioSaida || '').localeCompare(b.horarioSaida || ''));

    const proximos48h = allViagens
      .filter((v) => v.dataSaida >= todayStr && v.dataSaida <= in48hStr)
      .sort((a, b) => `${a.dataSaida} ${a.horarioSaida}`.localeCompare(`${b.dataSaida} ${b.horarioSaida}`));

    const emTransito = allViagens.filter((v) => v.status === 'EM_ANDAMENTO');

    const concluidasHoje = allViagens.filter(
      (v) => (v.dataChegada === todayStr || v.dataSaida === todayStr) && v.status === 'CONCLUÍDA'
    );

    const pendentesEmbarqueHoje = hoje.filter((v) => v.status === 'PLANEJADA');

    res.json({
      todayStr,
      tomorrowStr,
      stats: {
        totalHoje: hoje.length,
        emTransito: emTransito.length,
        concluidasHoje: concluidasHoje.length,
        pendentesHoje: pendentesEmbarqueHoje.length,
        amanhaTotal: amanha.length,
        totalProximos48h: proximos48h.length,
      },
      hoje,
      amanha,
      proximos48h,
      emTransito,
      allUpcoming: allViagens
        .filter((v) => v.dataSaida >= todayStr || v.status === 'EM_ANDAMENTO')
        .sort((a, b) => `${a.dataSaida} ${a.horarioSaida}`.localeCompare(`${b.dataSaida} ${b.horarioSaida}`)),
    });
  } catch (error: any) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: 'Erro ao carregar painel de embarques.' });
  }
});

// PUT /api/viagens/:id/quick-status
viagensRouter.put(
  '/viagens/:id/quick-status',
  authenticateToken,
  requireRoles('ADMIN_HOST', 'ADMIN', 'GESTOR'),
  async (req: Request, res: Response) => {
    try {
      const { status } = req.body;
      const validStatus: ViagemStatus[] = ['PLANEJADA', 'EM_ANDAMENTO', 'CONCLUÍDA', 'CANCELADA'];
      if (!status || !validStatus.includes(status)) {
        res.status(400).json({ error: 'BAD_REQUEST', message: 'Status de viagem inválido.' });
        return;
      }

      const existing = await db.viagens.findById(req.params.id);
      if (!existing) {
        res.status(404).json({ error: 'NOT_FOUND', message: 'Viagem não encontrada.' });
        return;
      }

      const updated = await db.viagens.updateOne(req.params.id, { status });

      await logAudit(req, {
        acao: 'STATUS_EMBARQUE_VIAGEM',
        entidade: 'Viagem',
        entidadeId: existing.id,
        detalhes: `Status de embarque alterado para ${status}: ${existing.alunoNome} (${existing.origem} -> ${existing.destino})`,
      });

      res.json(updated);
    } catch (error: any) {
      res.status(500).json({ error: 'INTERNAL_ERROR', message: 'Erro ao atualizar status do embarque.' });
    }
  }
);

// GET /api/viagens/:id
viagensRouter.get('/viagens/:id', authenticateToken, async (req: Request, res: Response) => {
  try {
    const viagem = await db.viagens.findById(req.params.id);
    if (!viagem) {
      res.status(404).json({ error: 'NOT_FOUND', message: 'Viagem não encontrada.' });
      return;
    }
    const computed = computeAutoStatus(viagem);
    if (computed !== viagem.status && viagem.status !== 'CANCELADA') {
      viagem.status = computed;
      await db.viagens.updateOne(viagem.id, { status: computed });
    }
    res.json(viagem);
  } catch (error: any) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: 'Erro ao buscar detalhes da viagem.' });
  }
});

// POST /api/viagens (supports cadastrar ida e volta juntos)
viagensRouter.post(
  '/viagens',
  authenticateToken,
  requireRoles('ADMIN_HOST', 'ADMIN', 'GESTOR'),
  async (req: Request, res: Response) => {
    try {
      const {
        alunoId,
        meioTransporte,
        origem,
        destino,
        dataSaida,
        horarioSaida,
        dataChegada,
        horarioChegada,
        empresa,
        numeroLocalizador,
        localEmbarque,
        localDesembarque,
        status,
        observacoes,
        cadastrarVolta, // boolean
        voltaDataSaida,
        voltaHorarioSaida,
        voltaDataChegada,
        voltaHorarioChegada,
        voltaEmpresa,
        voltaNumeroLocalizador,
        voltaLocalEmbarque,
        voltaLocalDesembarque,
        voltaMeioTransporte,
      } = req.body;

      if (!alunoId) {
        res.status(400).json({ error: 'BAD_REQUEST', message: 'Selecione o aluno da viagem.' });
        return;
      }

      if (!origem || !destino) {
        res.status(400).json({ error: 'BAD_REQUEST', message: 'Origem e destino são obrigatórios.' });
        return;
      }

      const aluno = await db.alunos.findById(alunoId);
      if (!aluno) {
        res.status(400).json({ error: 'BAD_REQUEST', message: 'Aluno selecionado não foi encontrado.' });
        return;
      }

      const validStatus: ViagemStatus[] = ['PLANEJADA', 'EM_ANDAMENTO', 'CONCLUÍDA', 'CANCELADA'];
      let vStatus: ViagemStatus = validStatus.includes(status) ? status : 'PLANEJADA';

      const idaId = `vgm_${Date.now()}_ida_${Math.random().toString(36).substring(2, 6)}`;
      const voltaId = cadastrarVolta ? `vgm_${Date.now()}_vlt_${Math.random().toString(36).substring(2, 6)}` : undefined;

      const newViagemIda: Viagem = {
        id: idaId,
        alunoId: aluno.id,
        alunoNome: aluno.nome,
        obreiroNome: aluno.obreiroNome || '',
        tipo: cadastrarVolta ? 'IDA' : 'UNICA',
        viagemParceiraId: voltaId,
        meioTransporte: meioTransporte || 'ONIBUS',
        origem: origem.trim(),
        destino: destino.trim(),
        dataSaida: dataSaida || new Date().toISOString().split('T')[0],
        horarioSaida: horarioSaida || '00:00',
        dataChegada: dataChegada || dataSaida || new Date().toISOString().split('T')[0],
        horarioChegada: horarioChegada || '00:00',
        empresa: empresa?.trim() || '',
        numeroLocalizador: numeroLocalizador?.trim() || '',
        localEmbarque: localEmbarque?.trim() || '',
        localDesembarque: localDesembarque?.trim() || '',
        status: vStatus,
        observacoes: observacoes?.trim() || '',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      newViagemIda.status = computeAutoStatus(newViagemIda);
      await db.viagens.insertOne(newViagemIda);

      let newViagemVolta: Viagem | null = null;
      if (cadastrarVolta && voltaId) {
        newViagemVolta = {
          id: voltaId,
          alunoId: aluno.id,
          alunoNome: aluno.nome,
          obreiroNome: aluno.obreiroNome || '',
          tipo: 'VOLTA',
          viagemParceiraId: idaId,
          meioTransporte: voltaMeioTransporte || meioTransporte || 'ONIBUS',
          origem: destino.trim(), // Volta: destino vira origem
          destino: origem.trim(), // Volta: origem vira destino
          dataSaida: voltaDataSaida || dataChegada || dataSaida,
          horarioSaida: voltaHorarioSaida || '00:00',
          dataChegada: voltaDataChegada || voltaDataSaida || dataChegada || dataSaida,
          horarioChegada: voltaHorarioChegada || '00:00',
          empresa: (voltaEmpresa || empresa || '').trim(),
          numeroLocalizador: (voltaNumeroLocalizador || '').trim(),
          localEmbarque: (voltaLocalEmbarque || localDesembarque || '').trim(),
          localDesembarque: (voltaLocalDesembarque || localEmbarque || '').trim(),
          status: 'PLANEJADA',
          observacoes: observacoes ? `Retorno: ${observacoes.trim()}` : 'Viagem de retorno.',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        newViagemVolta.status = computeAutoStatus(newViagemVolta);
        await db.viagens.insertOne(newViagemVolta);
      }

      await logAudit(req, {
        acao: 'CRIACAO_VIAGEM',
        entidade: 'Viagem',
        entidadeId: newViagemIda.id,
        detalhes: `Viagem (${newViagemIda.meioTransporte}) cadastrada para ${aluno.nome}: ${newViagemIda.origem} -> ${newViagemIda.destino}${cadastrarVolta ? ' (Com volta incluída)' : ''}`,
      });

      res.status(201).json({
        viagemIda: newViagemIda,
        viagemVolta: newViagemVolta,
        message: cadastrarVolta ? 'Ida e volta cadastradas com sucesso!' : 'Viagem cadastrada com sucesso!',
      });
    } catch (error: any) {
      res.status(500).json({ error: 'INTERNAL_ERROR', message: 'Erro ao cadastrar viagem.' });
    }
  }
);

// PUT /api/viagens/:id
viagensRouter.put(
  '/viagens/:id',
  authenticateToken,
  requireRoles('ADMIN_HOST', 'ADMIN', 'GESTOR'),
  async (req: Request, res: Response) => {
    try {
      const existing = await db.viagens.findById(req.params.id);
      if (!existing) {
        res.status(404).json({ error: 'NOT_FOUND', message: 'Viagem não encontrada.' });
        return;
      }

      const updates: Partial<Viagem> = {};
      const {
        alunoId,
        origem,
        destino,
        dataSaida,
        horarioSaida,
        dataChegada,
        horarioChegada,
        empresa,
        numeroLocalizador,
        localEmbarque,
        localDesembarque,
        status,
        observacoes,
      } = req.body;

      if (alunoId && alunoId !== existing.alunoId) {
        const aluno = await db.alunos.findById(alunoId);
        if (aluno) {
          updates.alunoId = aluno.id;
          updates.alunoNome = aluno.nome;
          updates.obreiroNome = aluno.obreiroNome;
        }
      }

      if (origem !== undefined) updates.origem = origem.trim();
      if (destino !== undefined) updates.destino = destino.trim();
      if (dataSaida !== undefined) updates.dataSaida = dataSaida;
      if (horarioSaida !== undefined) updates.horarioSaida = horarioSaida;
      if (dataChegada !== undefined) updates.dataChegada = dataChegada;
      if (horarioChegada !== undefined) updates.horarioChegada = horarioChegada;
      if (empresa !== undefined) updates.empresa = empresa.trim();
      if (numeroLocalizador !== undefined) updates.numeroLocalizador = numeroLocalizador.trim();
      if (localEmbarque !== undefined) updates.localEmbarque = localEmbarque.trim();
      if (localDesembarque !== undefined) updates.localDesembarque = localDesembarque.trim();
      if (observacoes !== undefined) updates.observacoes = observacoes.trim();

      const validStatus: ViagemStatus[] = ['PLANEJADA', 'EM_ANDAMENTO', 'CONCLUÍDA', 'CANCELADA'];
      if (status && validStatus.includes(status)) {
        updates.status = status;
      }

      const updated = await db.viagens.updateOne(req.params.id, updates);

      await logAudit(req, {
        acao: 'EDICAO_VIAGEM',
        entidade: 'Viagem',
        entidadeId: existing.id,
        detalhes: `Viagem atualizada: ${existing.alunoNome} (${updates.origem || existing.origem} -> ${updates.destino || existing.destino})`,
      });

      res.json(updated);
    } catch (error: any) {
      res.status(500).json({ error: 'INTERNAL_ERROR', message: 'Erro ao atualizar viagem.' });
    }
  }
);

// DELETE /api/viagens/:id
viagensRouter.delete(
  '/viagens/:id',
  authenticateToken,
  requireRoles('ADMIN_HOST', 'ADMIN'),
  async (req: Request, res: Response) => {
    try {
      const existing = await db.viagens.findById(req.params.id);
      if (!existing) {
        res.status(404).json({ error: 'NOT_FOUND', message: 'Viagem não encontrada.' });
        return;
      }

      await db.viagens.deleteOne(req.params.id);

      await logAudit(req, {
        acao: 'EXCLUSAO_VIAGEM',
        entidade: 'Viagem',
        entidadeId: existing.id,
        detalhes: `Viagem excluída: ${existing.alunoNome} (${existing.origem} -> ${existing.destino})`,
      });

      res.json({ message: 'Viagem excluída com sucesso.' });
    } catch (error: any) {
      res.status(500).json({ error: 'INTERNAL_ERROR', message: 'Erro ao excluir viagem.' });
    }
  }
);
