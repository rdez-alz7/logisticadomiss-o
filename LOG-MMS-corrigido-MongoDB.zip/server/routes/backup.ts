import { Router, Request, Response } from 'express';
import { db, saveLocalFile, syncFromDiskIfNeeded } from '../db/database.js';
import { authenticateToken, requireRoles } from '../services/authService.js';
import { logAudit } from '../services/auditService.js';

export const backupRouter = Router();

// GET /api/backup - Download complete backup JSON
backupRouter.get('/backup', authenticateToken, async (req: Request, res: Response) => {
  try {
    syncFromDiskIfNeeded();
    const [users, alunos, obreiros, viagens, documentos, user_invitations, auditoria] =
      await Promise.all([
        db.users.find(),
        db.alunos.find(),
        db.obreiros.find(),
        db.viagens.find(),
        db.documentos.find(),
        db.user_invitations.find(),
        db.auditoria.find(1000),
      ]);

    const backup = {
      timestamp: new Date().toISOString(),
      version: '1.0',
      data: {
        users: users.map(({ passwordHash, ...rest }) => rest), // don't expose password hashes in general download
        alunos,
        obreiros,
        viagens,
        documentos: documentos.map(({ dataBase64, ...rest }) => rest),
        user_invitations,
        auditoria,
      },
    };

    res.setHeader('Content-Type', 'application/json');
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="LOG_MMS_Backup_${new Date().toISOString().split('T')[0]}.json"`
    );
    res.send(JSON.stringify(backup, null, 2));
  } catch (error: any) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: 'Erro ao gerar backup.' });
  }
});

// POST /api/backup/sync - Sync client localStorage backup with server database
backupRouter.post('/backup/sync', authenticateToken, async (req: Request, res: Response) => {
  try {
    const { alunos: clientAlunos, viagens: clientViagens, obreiros: clientObreiros, settings: clientSettings } = req.body;
    syncFromDiskIfNeeded();

    let addedAlunos = 0;
    let updatedAlunos = 0;
    if (Array.isArray(clientAlunos)) {
      const serverAlunos = await db.alunos.find();
      for (const ca of clientAlunos) {
        if (!ca.id) continue;
        const existing = serverAlunos.find((sa) => sa.id === ca.id);
        if (!existing) {
          await db.alunos.insertOne(ca);
          addedAlunos++;
        } else if (ca.updatedAt && existing.updatedAt && new Date(ca.updatedAt) > new Date(existing.updatedAt)) {
          await db.alunos.updateOne(ca.id, ca);
          updatedAlunos++;
        }
      }
    }

    let addedViagens = 0;
    let updatedViagens = 0;
    if (Array.isArray(clientViagens)) {
      const serverViagens = await db.viagens.find();
      for (const cv of clientViagens) {
        if (!cv.id) continue;
        const existing = serverViagens.find((sv) => sv.id === cv.id);
        if (!existing) {
          await db.viagens.insertOne(cv);
          addedViagens++;
        } else if (cv.updatedAt && existing.updatedAt && new Date(cv.updatedAt) > new Date(existing.updatedAt)) {
          await db.viagens.updateOne(cv.id, cv);
          updatedViagens++;
        }
      }
    }

    let addedObreiros = 0;
    let updatedObreiros = 0;
    if (Array.isArray(clientObreiros)) {
      const serverObreiros = await db.obreiros.find();
      for (const co of clientObreiros) {
        if (!co.id) continue;
        const existing = serverObreiros.find((so) => so.id === co.id);
        if (!existing) {
          await db.obreiros.insertOne(co);
          addedObreiros++;
        } else if (co.updatedAt && existing.updatedAt && new Date(co.updatedAt) > new Date(existing.updatedAt)) {
          await db.obreiros.updateOne(co.id, co);
          updatedObreiros++;
        }
      }
    }

    if (clientSettings && clientSettings.dataLimitePassagem) {
      const current = await db.settings.get();
      if (!current.updatedAt || (clientSettings.updatedAt && new Date(clientSettings.updatedAt) > new Date(current.updatedAt))) {
        await db.settings.update(clientSettings.dataLimitePassagem);
      }
    }

    saveLocalFile();

    res.json({
      success: true,
      restored: {
        alunos: addedAlunos + updatedAlunos,
        viagens: addedViagens + updatedViagens,
        obreiros: addedObreiros + updatedObreiros,
      },
    });
  } catch (error: any) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: 'Erro ao sincronizar backup.' });
  }
});

// POST /api/backup/restore - Full restore
backupRouter.post(
  '/backup/restore',
  authenticateToken,
  requireRoles('ADMIN_HOST', 'ADMIN'),
  async (req: Request, res: Response) => {
    try {
      const { backupData } = req.body;
      if (!backupData || typeof backupData !== 'object') {
        res.status(400).json({ error: 'BAD_REQUEST', message: 'Dados de backup inválidos.' });
        return;
      }

      const payload = backupData.data || backupData;

      if (Array.isArray(payload.alunos)) {
        for (const a of payload.alunos) {
          if (!a.id) continue;
          const existing = await db.alunos.findById(a.id);
          if (!existing) {
            await db.alunos.insertOne(a);
          } else {
            await db.alunos.updateOne(a.id, a);
          }
        }
      }

      if (Array.isArray(payload.obreiros)) {
        for (const o of payload.obreiros) {
          if (!o.id) continue;
          const existing = await db.obreiros.findById(o.id);
          if (!existing) {
            await db.obreiros.insertOne(o);
          } else {
            await db.obreiros.updateOne(o.id, o);
          }
        }
      }

      if (Array.isArray(payload.viagens)) {
        for (const v of payload.viagens) {
          if (!v.id) continue;
          const existing = await db.viagens.findById(v.id);
          if (!existing) {
            await db.viagens.insertOne(v);
          } else {
            await db.viagens.updateOne(v.id, v);
          }
        }
      }

      if (payload.settings?.dataLimitePassagem) {
        await db.settings.update(payload.settings.dataLimitePassagem);
      }

      saveLocalFile();

      await logAudit(req, {
        acao: 'RESTAURACAO_BACKUP',
        entidade: 'Database',
        detalhes: 'Backup restaurado com sucesso.',
      });

      res.json({ message: 'Backup restaurado com sucesso!' });
    } catch (error: any) {
      res.status(500).json({ error: 'INTERNAL_ERROR', message: 'Erro ao restaurar dados.' });
    }
  }
);
